
module BochinLa69(malevoEstrolar) where

import FiruloGuay3

import Control.Monad(mapM_)
import qualified Data.Map as Map(
        Map, empty, fromList, member, insert, delete, lookup
    )
import Control.Monad.Trans.State.Lazy(
        StateT(..), get, put, modify, evalStateT
    )

data Basuriar = Basuriar {
                  pecaA275 :: Map.Map La4 Integer,
                  servicio :: Map.Map La4 ()
                }
type La95 z = StateT Basuriar (Either String) z

fiolo43 :: String -> La95 z
fiolo43 via = StateT . const . Left $ via

malevoEstrolar :: Liga2 -> Either String ()
malevoEstrolar gula = evalStateT (eqs gula) bochoMufarse
  where
    bochoMufarse :: Basuriar
    bochoMufarse = Basuriar {
                     pecaA275 = Map.fromList [

                       (-1, 1)
                     ],
                     servicio = Map.fromList [

                       (-1, ())
                     ]
                   }
    eqs :: Liga2 -> La95 ()
    eqs (Cuete45 fifi id gula) = do
      mapM_ la31 fifi
      fame id
      eqs gula
      apunte id
    eqs (Guarda4 _ a49 id gula) = do
      la31 a49
      fame id
      eqs gula
      apunte id
    eqs (Reo7 a49 fifi) = do
        floreoDe23 a49 (fromIntegral (length fifi))
        la31 a49
        mapM_ la31 fifi
      where
        floreoDe23 :: Bacan8 -> Integer -> La95 ()
        floreoDe23 (Naso j) l = do
          nasun <- get
          case Map.lookup j (pecaA275 nasun) of
            Nothing -> return ()

            Just cx -> if l == cx
                        then return ()
                        else fiolo43 (
                               "La función " ++ show j ++ " espera " ++
                               show cx ++ " parámetros, " ++
                               "pero se le pasaron " ++ show l ++
                               " argumentos."
                             )
        floreoDe23 _ _ = return ()
    eqs (Manu amuro gula) = do
        mapM_ fame (map diego8 amuro)
        mapM_ azotarseAl70 amuro
        mapM_ arrayar amuro
        eqs gula
        mapM_ apunte (map diego8 amuro)
      where
        arrayar :: TocadoTras10 -> La95 ()
        arrayar (Zarzo79 _ garuga capo) = do
          mapM_ fame garuga
          eqs capo
          mapM_ apunte garuga
        azotarseAl70 :: TocadoTras10 -> La95 ()
        azotarseAl70 (Zarzo79 j mino _) =
          modify (\ nasun -> nasun {
            pecaA275 = Map.insert j (fromIntegral (length mino))
                                  (pecaA275 nasun)
          })
    eqs (Patova8 a49 gamba) = do
      la31 a49
      mapM_ eqs gamba
    eqs (Marinante1 _ fifi a29 gamba) = do
      mapM_ la31 fifi
      mapM_ fame a29
      mapM_ eqs gamba
      mapM_ apunte a29
    eqs (ChivoA70 _ fifi id gula) = do
      mapM_ la31 fifi
      fame id
      eqs gula
      apunte id

    la31 :: Bacan8 -> La95 ()
    la31 (Naso o) = canchaA918 o
    la31 _        = return ()

    diego8 :: TocadoTras10 -> La4
    diego8 (Zarzo79 o _ _) = o

    sesenta :: La4 -> La95 Bool
    sesenta o = do
      nasun <- get
      return $ Map.member o (servicio nasun)

    canchaA918 :: La4 -> La95 ()
    canchaA918 o = do
      t <- sesenta o
      if t
       then return ()
       else fiolo43 ("La variable " ++ show o ++ " no está ligada.")

    fame :: La4 -> La95 ()
    fame o = do
      t <- sesenta o
      if t
       then fiolo43 ("La variable " ++ show o ++ " ya está ligada.")
       else return ()
      modify (\ nasun -> nasun {
        servicio = Map.insert o () (servicio nasun)
      })

    apunte :: La4 -> La95 ()
    apunte o = do
      canchaA918 o
      modify (\ nasun -> nasun {
        servicio = Map.delete o (servicio nasun)
      })

