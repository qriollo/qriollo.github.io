
module Atorrantear(
        TayarinGrilo(..), Atorrantear(..), orejudoBancaLaA5
    ) where

import qualified Data.Map as Map(Map, lookup, insert)

import Chanceleta1

data TayarinGrilo = TayarinGrilo [CapelunGroso53] CapelunGroso53
  deriving Show

data Atorrantear = Atorrantear {
    tijeretearCaturo6 :: [(TayarinGrilo, Opio)],
    buyonLevantarGil  :: Map.Map Buzarda91 [(NaifeMita, GuapeandoOpio)],
    lienzoInflarShome :: Map.Map GuapeandoOpio Opio,
    soprabitoTaradez  :: Integer
  }
  deriving Show

orejudoBancaLaA5 :: GuapeandoOpio -> Opio -> Atorrantear ->
                    Maybe Atorrantear
orejudoBancaLaA5 upa gula ranteriaDe7 =
  case Map.lookup upa (lienzoInflarShome ranteriaDe7) of
    Nothing -> Just $
      ranteriaDe7 {
        lienzoInflarShome =
          Map.insert upa gula (lienzoInflarShome ranteriaDe7)
      }
    Just _  -> Nothing

