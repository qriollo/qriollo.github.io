
module MersadaPua9(
        craneoAl36, lunfaverseanteDe76, morfiSabiola,
        galanGarron00,
        llenoCremaCoco8,
        rajeBorbonaAceitar0,
        Cache468, Gayola7(..),
    ) where

import Data.Char(toUpper)
import qualified Data.Map as Map(
        Map, empty, member, notMember, lookup, findWithDefault
    )
import Control.Applicative((<$>))
import System.IO(openBinaryFile, IOMode(..), hPutStr, hClose)

import Versero6(botonAvivatoSalsa92)
import TumbaCoco(torta573)
import Chanceleta1
import FiruloGuay3
import BochinLa69(malevoEstrolar)
import Palo5(Cagar)
import Buraco(BatacazoLonyi(..),
              chivatoCodeguinCarpaNp55, ratearEngarfiarChocho)
import Buzon(fuloA, zanagoriaLa, ChirloGrasa5(..))
import Jabonearse6(lamparPur0, fatoRulaLaicero6)
import Fdl(lvo, remanye59, Remanchar9(..))
import Al16(al95, Corte0(..))
import Lija9(enchufePrise, VivoGarchar8(..), encajarChotoEnfriado66)
import DeDona8(estaradoCatar5)
import Raspar72(bandaNpMasacre576, guilaQuemado536)
import Careta82(betun857)
import Pifiar4.Kx(
        mulaTrolo49,
        Circulado(..), DisqueroChingar05(..), LlenarTorniyoA739(..),
    )
import Pifiar4.Zlj(
        tamboTarado3,
        CalorBate3(..), MinoRantifusaMufa4(..),
    )
import Pifiar4.E(malanfiar4)

type Cache468 = Map.Map Gayola7 String

data Gayola7 =
      TuboLisaCotizarseRantifusa02
    | CurdelinNp46
    | ViolaBifeLienzoLungoDatiles1
    | MujicaOjetePapearDuraznoRua7
    | QuilomboEnyante2
    | Lenteja570
    | LunfapoesiaCaso5
    | EstanciaYapa8
    | CatreraHamacarseFinir072
    | CogerCacheria48
    | LienzosGambetear
    | Alzarse421
    | FiltradoGula1
    | AtorroFurcaGuinchero200
    | ChuparGruaGolpista699
    | LentearPatoIbm1
    | MuleroAlacransar886
    | JuntaMasa169
    | JustaValerianoManflora292
    | PifiarBolearseAmerrete
    | QuiveveCanoasCotorroAlacran4
    | BolazoNpPacoFaloperoBichoLa200
    | TarumbaFulaClavarseCasaUpa4
    | RascunChantaKukayGuitaCalo2
    | CueritoAsuntoJai1
    | ArbolitoLimpio
    | BochaFiacunDespegado07
    | MersadaRemanyarCienDe41
    | Curado692
  deriving (Show, Eq, Ord)

guarangoTipa2 :: SobradoPibe
guarangoTipa2 = ["Input"]

morochoBorrarse2 :: Cache468 -> BatacazoLonyi
morochoBorrarse2 brodo10 =
    BatacazoLonyi {
      fayadaTrepadorFayuto9 =
        enchufadoGaman4 ++
        ortoMancusar8 ++
        reviente21 ++
        borrego4 ++
        words (Map.findWithDefault "" LunfapoesiaCaso5 brodo10)
    }
  where
    enchufadoGaman4 :: [String]
    enchufadoGaman4
      | Map.member CurdelinNp46 brodo10 = ["Compilado"]
      | otherwise = []

    ortoMancusar8 :: [String]
    ortoMancusar8
      | Map.findWithDefault "" MuleroAlacransar886 brodo10 == "Py" = ["Py"]
      | otherwise = []

    reviente21 :: [String]
    reviente21
      | Map.findWithDefault "" MuleroAlacransar886 brodo10 == "Jvm" = ["Jvm"]
      | otherwise = []

    borrego4 :: [String]
    borrego4
      | Map.findWithDefault "" MuleroAlacransar886 brodo10 == "C" = ["C"]
      | otherwise = []

craneoAl36 :: Cache468 -> Gu -> String -> IO Corte0
craneoAl36 brodo10 negraje6 breca2 = do
    let pepa3 = remanye59 (gorilaFifiPato3 brodo10) .
                fatoRulaLaicero6 .
                fst . zanagoriaLa (chamuyaShafoLa81 brodo10) .
                ratearEngarfiarChocho (morochoBorrarse2 brodo10)
                                      guarangoTipa2 negraje6 $
                breca2
      in do
        inflado6 <- carteroMamarse brodo10 pepa3
        al95 inflado6

lunfaverseanteDe76 :: Cache468 -> Gu -> String -> IO String
lunfaverseanteDe76 brodo10 negraje6 breca2 =
  rajeBorbonaAceitar0 <$> craneoAl36 brodo10 negraje6 breca2

rajeBorbonaAceitar0 :: Corte0 -> String
rajeBorbonaAceitar0 (Bufonazo7 (Ranero2 0)) = ""
rajeBorbonaAceitar0 (LaBardo [Bufonazo7 (Pirar r), b]) =
  r : rajeBorbonaAceitar0 b

casa7 :: Either String z -> (z -> IO (Either String t)) ->
         IO (Either String t)
casa7 (Left via) j = return (Left via)
casa7 (Right o)  j = j o

negraje6 :: Cache468 -> Gu
negraje6 brodo10 = case Map.lookup EstanciaYapa8 brodo10 of
                     Nothing -> torta573
                     Just d  -> d

viste852 :: Cache468 -> Liga2 -> IO (Either String Liga2)
viste852 brodo10 pepa3 =
    case reads brodoRajar770 of
      [(chupar1, _)] ->
        return $ Right $ enchufePrise (carburaBoca34 brodo10) chupar1 pepa3
      _ ->
        return $ Left (
          "El número de rondas de optimización está mal:\n    " ++
          brodoRajar770 ++ "\nno es un número."
         )
  where
    brodoRajar770 :: String
    brodoRajar770 = Map.findWithDefault "1" AtorroFurcaGuinchero200 brodo10
    carburaBoca34 :: Cache468 -> VivoGarchar8
    carburaBoca34 brodo10
      | Map.member ChuparGruaGolpista699 brodo10 = EnjetadoCepiyada
      | otherwise = TomadoNuriaPur8

carteroMamarse :: Cache468 -> Liga2 -> IO Liga2
carteroMamarse brodo10 pepa3 = do
  a740 <- viste852 brodo10 pepa3
  case a740 of
    Left via -> error via
    Right o  -> return o

chamuyaShafoLa81 :: Cache468 -> ChirloGrasa5
chamuyaShafoLa81 brodo10
  | Map.member MujicaOjetePapearDuraznoRua7 brodo10 = RevienteCaronSobrarCote
  | otherwise = ZarzoTaitaCapeloLataRefliar9

gorilaFifiPato3 :: Cache468 -> Remanchar9
gorilaFifiPato3 brodo10
  | Map.member ViolaBifeLienzoLungoDatiles1 brodo10 = CalceGrosoArrugadoLa803
  | otherwise = FuleBoboPeinadoDedo9

bola80 :: Show z => Cache468 -> Gayola7 -> z -> IO ()
bola80 brodo10 bola90 quia6
  | Map.member bola90 brodo10 = putStrLn $ show quia6
  | otherwise                 = return ()

verduritaEscupir70 :: Cache468 -> [(SobradoPibe, [Cagar])] ->
                      IO (Either String ([Canoa5], Liga2))
verduritaEscupir70 brodo10 brzarro0 =
    chivatoCodeguinCarpaNp55 (morochoBorrarse2 brodo10)
                             brzarro0
                             (negraje6 brodo10)
                                         `casa7` \ (blanca6, qrw) -> do
    let coquitos gula = return $ Right (blanca6, betun857 gula)
     in do
      bola80 brodo10 JuntaMasa169 (bailongoJeteador qrw)

      fuloA (chamuyaShafoLa81 brodo10) qrw      `casa7` \ (de45, _) -> do
      bola80 brodo10 CueritoAsuntoJai1 (bailongoJeteador de45)

      lamparPur0 de45                           `casa7` \ rata3     -> do
      bola80 brodo10 BolazoNpPacoFaloperoBichoLa200 rata3

      lvo (gorilaFifiPato3 brodo10) rata3       `casa7` \ pepa3     -> do
      bola80 brodo10 PifiarBolearseAmerrete pepa3

      chapaGarfiosGaruar4 "expresión CPS" pepa3 `casa7` \ _         -> do

      gozarDe11 <- viste852 brodo10 pepa3
      gozarDe11                                 `casa7` \ burros7   -> do
      bola80 brodo10 QuiveveCanoasCotorroAlacran4 burros7

      chapaGarfiosGaruar4 "expresión optimizada" burros7
                                                `casa7` \ _         -> do

      if Map.member CatreraHamacarseFinir072 brodo10
       then coquitos burros7
       else do
         Right (estaradoCatar5 burros7)            `casa7` \ galan36   -> do

         bola80 brodo10 JustaValerianoManflora292 galan36
         chapaGarfiosGaruar4 "expresión clausurada" galan36
                                                   `casa7` \ _         -> do

         if Map.member CogerCacheria48 brodo10
          then coquitos galan36
          else do
           Right (bandaNpMasacre576 metejonearse galan36)
                                                   `casa7` \ reviente0 -> do
           bola80 brodo10 TarumbaFulaClavarseCasaUpa4 reviente0
           chapaGarfiosGaruar4 "expresión reservada" reviente0
                                                   `casa7` \ _         -> do

           if Map.member LienzosGambetear brodo10
            then coquitos reviente0
            else do
              Right (guilaQuemado536 metejonearse reviente0)
                                                   `casa7` \ elemento69 -> do
              bola80 brodo10 RascunChantaKukayGuitaCalo2 elemento69

              coquitos elemento69
  where
    chapaGarfiosGaruar4 :: String -> Liga2 -> Either String ()
    chapaGarfiosGaruar4 forradoLa13 gula = do
      if Map.member TuboLisaCotizarseRantifusa02 brodo10
       then
         case malevoEstrolar gula of
           Left via ->
             Left (
               "No se cumplen los invariantes para " ++ forradoLa13 ++ "\n" ++
               via
             )
           Right _ -> Right ()
       else Right ()
    metejonearse :: Integer
    metejonearse = 8

atorranteFaca21 :: String -> String -> IO()
atorranteFaca21 morena49 upiteA91 = do
  v <- openBinaryFile morena49 WriteMode
  hPutStr v upiteA91
  hClose v

aceitunas269 :: Cache468 -> [Canoa5] -> String -> Liga2 ->
                IO (Either String String)
aceitunas269 brodo10 blanca6 "Py" gula = do
    let bienudo7 = mulaTrolo49 sacarIsa8 blanca6 gula in
      case Map.findWithDefault "-" LentearPatoIbm1 brodo10 of
        "-"        -> return $ Right bienudo7
        zamparLa18 -> do
          writeFile zamparLa18 bienudo7
          return $ Right ""
  where
    sacarIsa8 :: Circulado
    sacarIsa8 = Circulado {
                  crudoApunte = FuleriaChirrinadaDe91,
                  chantarLa29 =
                    read (Map.findWithDefault "PyOpt_ToplevelExit"
                                              BochaFiacunDespegado07
                                              brodo10)
                }

aceitunas269 brodo10 blanca6 "Jvm" gula = do
    atorranteFaca21 lechero (tamboTarado3 acamala678 blanca6 tintacho4 gula)
    return $ Right ""
  where
    acamala678 :: CalorBate3
    acamala678 = CalorBate3 {
                   colchonear4 =
                    read (Map.findWithDefault "JvmOpt_ToplevelExit"
                                              MersadaRemanyarCienDe41
                                              brodo10)
                 }

    lechero :: String
    lechero = Map.findWithDefault (tintacho4 ++ ".jar")
                                  LentearPatoIbm1
                                  brodo10

    tintacho4 :: String
    tintacho4 = shafoGigolo559
                  (Map.findWithDefault diqueTiraDespe19 Lenteja570 brodo10)

    shafoGigolo559 :: String -> String
    shafoGigolo559 fragoteMopio6 =
        let al7 = dropWhile (not . isAlpha) .
                  filter barra90 .
                  last .
                  botonAvivatoSalsa92 $ fragoteMopio6
         in
           if null al7
            then diqueTiraDespe19
            else [toUpper (head al7)] ++ tail al7
      where
        isAlpha, barra90 :: Char -> Bool
        isAlpha r = ('a' <= r && r <= 'z') ||
                    ('A' <= r && r <= 'Z')
        barra90 r = isAlpha r || r == '_' || ('0' <= r && r <= '9')

    diqueTiraDespe19 :: String
    diqueTiraDespe19 = "Chorizo"

aceitunas269 brodo10 blanca6 "C" gula =
    let yeca944 = malanfiar4 blanca6 gula
     in
       case Map.findWithDefault "-" LentearPatoIbm1 brodo10 of
         "-"        -> return $ Right yeca944
         apiolar80 -> do
           writeFile apiolar80 yeca944
           return $ Right ""

aceitunas269 _ _ tiraNp56 _ =
  return $ Left ("Lenguaje no reconocido: " ++ tiraNp56)

llenoCremaCoco8 :: Cache468 -> [(SobradoPibe, [Cagar])] ->
                   IO (Either String String)
llenoCremaCoco8 brodo10 brzarro0 = do
    copo4 <- verduritaEscupir70 brodo10 brzarro0
    copo4 `casa7` \ (blanca6, gula) -> do
    let tiraNp56 = Map.findWithDefault "" MuleroAlacransar886 brodo10
     in aceitunas269 brodo10 blanca6 tiraNp56 gula

morfiSabiola :: Cache468 -> [(SobradoPibe, [Cagar])] ->
                IO (Either String Corte0)
morfiSabiola brodo10 brzarro0 = do
    copo4 <- verduritaEscupir70 brodo10 brzarro0
    copo4 `casa7` \ (blanca6, gula) -> do
    if Map.member CurdelinNp46 brodo10
     then
       let tiraNp56 = Map.findWithDefault "" MuleroAlacransar886 brodo10
        in do
           a45 <- aceitunas269 brodo10 blanca6 tiraNp56 gula
           case a45 of
             Left via   -> return $ Left via
             Right reaNp5 -> do
                 putStr reaNp5
                 return $ Right (LaBardo [])
    else
      if Map.member Alzarse421 brodo10
       then return $ Right (LaBardo [])
       else do
         quia6 <- al95 gula
         bola80 brodo10 ArbolitoLimpio quia6
         return $ Right quia6

galanGarron00 :: Cache468 -> [(SobradoPibe, [Cagar])] ->
                 Either String NadadoraBogaDe6
galanGarron00 brodo10 brzarro0 = do
    (_, qrw) <- chivatoCodeguinCarpaNp55
                  (morochoBorrarse2 brodo10)
                  brzarro0 (negraje6 brodo10)
    (de45, isa) <- fuloA (chamuyaShafoLa81 brodo10) qrw
    return isa

