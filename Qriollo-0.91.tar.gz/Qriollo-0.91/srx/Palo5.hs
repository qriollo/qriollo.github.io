
module Palo5(
        chiquilin6,
        Cagar(..),
        Quilombo9(..),
        shacar88,
        esquinazoGuiyado5,
    ) where

import Control.Monad.Trans.State.Lazy(
        StateT(..), get, modify, evalStateT,
    )
import Data.Char

import Chanceleta1(SobradoPibe, Gu, Regalado(..), creparChina)
import Versero6(Versero6(..), fifarEncanastado, sotanaAfilarA2, sobradoMateA03)

chiquilin6 :: Regalado -> SobradoPibe
chiquilin6 (Regalado birra64 pedo3) = birra64 ++ [pedo3]

data Quilombo9 = Gil31
               | AtorroA98 SobradoPibe Gu
               | DroguiA97 SobradoPibe Gu
               | TimbaGevon SobradoPibe Gu
               | Titear52 Integer
               | LaJai1 Char
               | Merluza04 Integer
               | Cafetear String

               | Raje69
               | SireSanata1
               | SequeiraA05
               | Funda5
               | Ranterio
               | GuardaChuza6
               | Pavo1
               | Barra0
               | Afano
               | FilarSensa
               | Aceite
               | Gil7
               | Ranada
               | Ragu
               | Jamar25
               | Pua6
               | RefilarA96
               | RajarSolfa
               | Azotarse18
               | Gay2
               | BebePan8
               | Rifado0
               | Yiro23
               | Linusa
               | Bogolico
               | Barra
               | Cola
               | Alfajia
               | Np09

               | Guarango
               | Shacar12
               | Upa0

               | ViaSolfa
               | Escabiar
               | ChabonAve9
               | Milanesa83
               | Asunto46
               | BomboA08
               | Pechar5

               | BoletoA05 SobradoPibe
               | ManducarMono
  deriving (Show, Eq)

esquinazoGuiyado5 :: Quilombo9 -> String
esquinazoGuiyado5 Gil31 = "el final del archivo"
esquinazoGuiyado5 (AtorroA98 bagayo5 id) =
  "un identificador con minúscula (" ++ show (Regalado bagayo5 id) ++ ")"
esquinazoGuiyado5 (DroguiA97 bagayo5 id) =
  "un identificador con mayúscula (" ++ show (Regalado bagayo5 id) ++ ")"
esquinazoGuiyado5 (TimbaGevon bagayo5 id) =
  "un chirimbolo (" ++ show (Regalado bagayo5 id) ++ ")"
esquinazoGuiyado5 (Titear52 l) =
  "un numerito (" ++ show l ++ "#)"
esquinazoGuiyado5 (LaJai1 r) =
  "una letra (" ++ show r ++ ")"
esquinazoGuiyado5 (Merluza04 l) =
  "un número (" ++ show l ++ ")"
esquinazoGuiyado5 (Cafetear b) =
  "un texto (" ++ show b ++ ")"
esquinazoGuiyado5 Raje69        = "'ante'"
esquinazoGuiyado5 SireSanata1   = "un artículo determinado ('el', 'la', ...)"
esquinazoGuiyado5 SequeiraA05   = "un artículo indeterminado ('un', 'una', ...)"
esquinazoGuiyado5 Funda5        = "'bien'"
esquinazoGuiyado5 Ranterio      = "una puteada ('boludo')"
esquinazoGuiyado5 GuardaChuza6  = "'chirimbolo'"
esquinazoGuiyado5 Pavo1         = "un vocativo ('che')"
esquinazoGuiyado5 Barra0        = "'como'"
esquinazoGuiyado5 Afano         = "'con'"
esquinazoGuiyado5 FilarSensa    = "'cualidad'"
esquinazoGuiyado5 Aceite        = "'cuyo'"
esquinazoGuiyado5 Gil7          = "'da'"
esquinazoGuiyado5 Ranada        = "'dado'"
esquinazoGuiyado5 Ragu          = "'dado'"
esquinazoGuiyado5 Jamar25       = "'donde'"
esquinazoGuiyado5 Pua6          = "'en'"
esquinazoGuiyado5 RefilarA96    = "'encarnar'"
esquinazoGuiyado5 RajarSolfa    = "'enchufar'"
esquinazoGuiyado5 Azotarse18    = "'entregar'"
esquinazoGuiyado5 Gay2          = "una cópula ('es', 'son')"
esquinazoGuiyado5 BebePan8      = "'gringo'"
esquinazoGuiyado5 Rifado0       = "'mirar'"
esquinazoGuiyado5 Yiro23        = "'para'"
esquinazoGuiyado5 Linusa        = "'pero'"
esquinazoGuiyado5 Bogolico      = "'ponele'"
esquinazoGuiyado5 Barra         = "'que'"
esquinazoGuiyado5 Cola          = "'si'"
esquinazoGuiyado5 Alfajia       = "'tiene'"
esquinazoGuiyado5 Np09          = "'no'"
esquinazoGuiyado5 Upa0          = "'SI'"
esquinazoGuiyado5 Guarango      = "'BOLUDO'"
esquinazoGuiyado5 ViaSolfa      = "un paréntesis '('"
esquinazoGuiyado5 Escabiar      = "un paréntesis ')'"
esquinazoGuiyado5 ChabonAve9    = "un corchete '['"
esquinazoGuiyado5 Milanesa83    = "un corchete ']'"
esquinazoGuiyado5 Asunto46      = "una llave '{'"
esquinazoGuiyado5 BomboA08      = "una llave '}'"
esquinazoGuiyado5 Pechar5       = "una coma ','"
esquinazoGuiyado5 (BoletoA05 m) = "el inicio del paquete " ++ creparChina m
esquinazoGuiyado5 ManducarMono  = "el final del archivo"

data Cagar = Cagar Quilombo9 Versero6
  deriving Show

joda314, minaje9 :: Char -> Bool
joda314 r = isAlpha r || isDigit r || r == '_'
minaje9 r = r == ' ' || r == '\t' || r == '\n' || r == '\r'
reventar31 r = r `elem` [
    '!', '#', '$', '%',
    '&', '*', '+', '.',
    '/', '<', '=', '>',
    '?', '@', ':', '^',
    '|', '-', '~', '\\',
    ';', '`'
 ]

conga498 :: [(Gu, Quilombo9)]
conga498 = [
    ("ante", Raje69),
    ("bien", Funda5),
    ("boludo", Ranterio), ("boluda", Ranterio),
    ("chirimbolo", GuardaChuza6),
    ("che", Pavo1),
    ("como", Barra0),
    ("con", Afano),
    ("cualidad", FilarSensa),
    ("cuyo", Aceite), ("cuya", Aceite),
                      ("cuyos", Aceite),
                      ("cuyas", Aceite),
    ("da", Gil7),
    ("dado", Ranada), ("dada", Ranada),
                      ("dados", Ranada),
                      ("dadas", Ranada),
    ("de", Ragu),
    ("donde", Jamar25),
    ("el", SireSanata1), ("la", SireSanata1),
                         ("las", SireSanata1),
                         ("los", SireSanata1),
    ("en", Pua6),
    ("encarnar", RefilarA96),
    ("enchufar", RajarSolfa),
    ("entregar", Azotarse18),
    ("es", Gay2), ("son", Gay2),
    ("gringo", BebePan8), ("gringa", BebePan8),
                          ("gringos", BebePan8),
                          ("gringas", BebePan8),
    ("mirar", Rifado0),
    ("no", Np09),
    ("para", Yiro23),
    ("pero", Linusa),
    ("ponele", Bogolico),
    ("que", Barra),
    ("si", Cola),
    ("tiene", Alfajia), ("tienen", Alfajia),
    ("un", SequeiraA05), ("una", SequeiraA05),
                         ("unas", SequeiraA05),
                         ("unos", SequeiraA05)
 ]

melonazoMangruyos767 :: [(Gu, Quilombo9)]
melonazoMangruyos767 = [
    ("SI", Upa0),
    ("BOLUDO", Guarango), ("BOLUDA", Guarango),

    ("GRINGO", Shacar12), ("GRINGA", Shacar12),
                          ("GRINGOS", Shacar12),
                          ("GRINGAS", Shacar12)
 ]

type Curro7 z = StateT Versero6 (Either String) z

espamento :: SobradoPibe -> String -> Curro7 z -> Either String z
espamento bagayo5 upiteA91 d =
  evalStateT d (Versero6 bagayo5 upiteA91 1 1)

trancaEncajetadoReo9 :: String -> Curro7 ()
trancaEncajetadoReo9 breca2 = modify (sobradoMateA03 breca2)

vamoBola4 :: String -> Versero6 -> Curro7 z
vamoBola4 via al0 = StateT . const . Left $ (
    via ++ "\n" ++
    "\nCerquita de: " ++ fifarEncanastado al0 ++ ".\n" ++
    "----\n" ++ sotanaAfilarA2 al0 ++ "\n----\n"
  )

felpa190 :: String -> Curro7 (String, Char, String)
felpa190 ('\\' : 'a' : uh)  = return ("\\a", '\a', uh)
felpa190 ('\\' : 'b' : uh)  = return ("\\b", '\b', uh)
felpa190 ('\\' : 'f' : uh)  = return ("\\f", '\f', uh)
felpa190 ('\\' : 'n' : uh)  = return ("\\n", '\n', uh)
felpa190 ('\\' : 'r' : uh)  = return ("\\r", '\r', uh)
felpa190 ('\\' : 't' : uh)  = return ("\\t", '\t', uh)
felpa190 ('\\' : 'v' : uh)  = return ("\\v", '\v', uh)
felpa190 ('\\' : '\\' : uh) = return ("\\\\", '\\', uh)
felpa190 ('\\' : '\'' : uh) = return ("\\\'", '\'', uh)
felpa190 ('\\' : '"' : uh)  = return ("\\\"", '"', uh)
felpa190 (r : uh)           = return ([r], r, uh)
felpa190 "" = do
  al0 <- get
  vamoBola4 (
     "Recatate.\n" ++
     "La entrada terminó antes de tiempo."
   )
   al0

shacar88 :: SobradoPibe -> String -> Either String [Cagar]
shacar88 bagayo5 upiteA91 =
    espamento bagayo5 upiteA91 (al4 upiteA91)
  where
    al4 :: String -> Curro7 [Cagar]
    al4 "" = do
      al0 <- get
      return [Cagar Gil31 al0]
    al4 ('O' : 'J' : 'O' : '.' : uh) =

      let (grasa49, np81) = span (/= '\n') uh in do
        trancaEncajetadoReo9 ("OJO." ++ grasa49)
        al4 np81
    al4 ('(' : uh) = gavilan4 "(" (Cagar ViaSolfa) uh
    al4 (')' : uh) = gavilan4 ")" (Cagar Escabiar) uh
    al4 ('[' : uh) = gavilan4 "[" (Cagar ChabonAve9) uh
    al4 (']' : uh) = gavilan4 "]" (Cagar Milanesa83) uh
    al4 ('{' : uh) = gavilan4 "{" (Cagar Asunto46) uh
    al4 ('}' : uh) = gavilan4 "}" (Cagar BomboA08) uh
    al4 (',' : uh) = gavilan4 "," (Cagar Pechar5) uh
    al4 ('\'' : uh) = do
        (x, chr, qqt) <- felpa190 uh
        case qqt of
          '\'' : pua6 -> gavilan4 x (Cagar (LaJai1 chr)) pua6
          _           -> do
            al0 <- get
            vamoBola4 (
                "¿Qué onda?\n" ++
                "Esperaba otra comilla (\') para delimitar la letra."
              )
              al0
    al4 ('"' : uh) = do
        (x, b, qqt) <- faseando52 uh
        gavilan4 x (Cagar (Cafetear b)) qqt
      where
        faseando52 :: String -> Curro7 (String, String, String)
        faseando52 ('"' : uh) = return ("\"", [], uh)
        faseando52 uh         = do
          (lf, chr, qqt)  <- felpa190 uh
          (bh, a39, pua6) <- faseando52 qqt
          return ("\"" ++ lf ++ bh, chr : a39, pua6)
    al4 (r : uh) | minaje9 r = do
      trancaEncajetadoReo9 (r : [])
      al4 uh
    al4 (r : uh) | isDigit r =
      let (pedo3, tail) = span isDigit (r : uh) in
        case tail of
          '#' : capo0 -> gavilan4 pedo3 (Cagar $ Titear52 $ read pedo3) capo0
          _ -> gavilan4 pedo3 (Cagar $ Merluza04 $ read pedo3) tail

    al4 uh = mono85 [] uh

    mono85 :: SobradoPibe -> String -> Curro7 [Cagar]
    mono85 bagayo5 (r : uh) | isUpper r =
      let (pedo3, tail) = span joda314 (r : uh)
       in case tail of
            '.' : capo0 -> do
              trancaEncajetadoReo9 (pedo3 ++ ".")
              mono85 (bagayo5 ++ [pedo3]) capo0
            _ -> case lookup pedo3 melonazoMangruyos767 of
                   Just isa ->
                     gavilan4 pedo3 (Cagar isa) tail
                   _        ->
                     gavilan4 pedo3 (Cagar $ DroguiA97 bagayo5 pedo3) tail
    mono85 bagayo5 uh  = abotonadoGay1 bagayo5 uh

    abotonadoGay1 :: SobradoPibe -> String -> Curro7 [Cagar]
    abotonadoGay1 camba4 (r : uh) | reventar31 r =
      let (pedo3, tail) = span reventar31 (r : uh)
       in gavilan4 pedo3 (Cagar (TimbaGevon camba4 pedo3)) tail
    abotonadoGay1 camba4 (r : uh) | joda314 r =
      let (pedo3, tail) = span joda314 (r : uh)
          melonazo9 = case lookup pedo3 conga498 of
                        Just isa            -> const isa
                        Nothing | isUpper r -> DroguiA97 camba4
                        Nothing             -> AtorroA98 camba4
       in gavilan4 pedo3 (Cagar $ melonazo9 pedo3) tail
    abotonadoGay1 camba4 _ = do
      al0 <- get
      vamoBola4 (
          "Flor de error de sintaxis.\n" ++
          "El símbolo es inválido."
        )
        al0

    gavilan4 :: String -> (Versero6 -> Cagar) -> String -> Curro7 [Cagar]
    gavilan4 a49 logi5 tail = do
      al0 <- get
      trancaEncajetadoReo9 a49
      np81 <- al4 tail
      return (logi5 al0 : np81)

minervaBolita9 :: SobradoPibe -> String -> [Cagar]
minervaBolita9 bagayo5 upiteA91 =
  case shacar88 bagayo5 upiteA91 of
    Left via -> error via
    Right o  -> o

