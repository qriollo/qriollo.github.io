
module Buraco(
        BatacazoLonyi(..),
        ViarazaHomo(..),
        PoligriyoMatonear(..),
        FumistaGaruarRaviol9(..),
        avivadoCiegoA33,
        ratearEngarfiarChocho,
        chivatoCodeguinCarpaNp55,
        chorroMasoca4,
        encoparseLargoGuiye,
    ) where

import Chanceleta1
import Control.Monad.Trans.State.Lazy(
        State, StateT(..), get, modify, evalState, runStateT,
    )
import Data.Maybe(fromJust)
import Data.List(sortBy, groupBy, nub)
import Data.Function(on)
import qualified Data.Map as Map(
        Map, empty, insert, lookup, findWithDefault, keys, fromList
    )

import TumbaCoco(
        tocadoTano9, envainarFija, caqueroMetido, ibmTarroAl,
        garuarA47, jamarToco59, cogoteJamon9, mulaTimbo8,
        embetunar77, justiniano61, tintachoChupe, tracaladaBombo,
        globoRufino20, faneChabonA14, petisa3, zapayero,
    )
import Versero6(Versero6(..), fifarEncanastado, sotanaAfilarA2)
import Palo5(chiquilin6, Cagar(..), Quilombo9(..), shacar88, esquinazoGuiyado5)

achaparradaChumboAl42 :: Gu -> Bool
achaparradaChumboAl42 id | last id == ':' = True
achaparradaChumboAl42 _                   = False

chivatazo :: Regalado -> Opio
chivatazo garchar2@(Regalado _ ancu)
  | not (null ancu) && achaparradaChumboAl42 ancu = conchaSobreA31 garchar2
  | otherwise                                     = fiaca9 garchar2

data CompadrearA58 = CocaFurca | Languido45 | GatoHembra5
  deriving (Show, Eq)
type Atorrante2 = Integer
data FlacaA59 = FlacaA59 { biyuyaEsputzaCatinga9 :: CompadrearA58,
                           enchastreCascara19 :: Atorrante2,
                           verdurita6 :: Regalado }
  deriving Show

yompaParalitico1 :: FlacaA59 -> Bool
yompaParalitico1 (FlacaA59 CocaFurca _ _)  = True
yompaParalitico1 (FlacaA59 Languido45 _ _) = True
yompaParalitico1 _                         = False

rabonaViolaIbm3 :: FlacaA59 -> Bool
rabonaViolaIbm3 (FlacaA59 GatoHembra5 _ _) = True
rabonaViolaIbm3 _                          = False

bramajeHumo :: FlacaA59 -> Bool
bramajeHumo (FlacaA59 CocaFurca _ _) = True
bramajeHumo _                        = False

data RabonaLiga3 = RabonaLiga3 {
                     burreroFachaPedo8 :: LlenarseAA60,
                     lolaCanoaGuapeadaViaraza0 :: AchuchadoGarabaAlca3,
                     acomodarRemancharYeta :: [SobradoPibe]
                   }
type LlenarseAA60 = Map.Map Gu Regalado
data AchuchadoGarabaAlca3 = CalceTungoPedo87 | BorrarseShucaPiba4 [Gu]

bifeCheto4 :: RabonaLiga3
bifeCheto4 = RabonaLiga3 {
               burreroFachaPedo8 =
                Map.fromList $
                map (\ id -> (id, Regalado tocadoTano9 id))
                    embetunar77,
               lolaCanoaGuapeadaViaraza0 = CalceTungoPedo87,
               acomodarRemancharYeta = [tocadoTano9]
             }

data FasearBoca9 = FasearBoca9 {
                     batataA25 :: BatacazoLonyi,
                     voraceroManu7 :: Integer,
                     trotera7 :: [Cagar],
                     pocilgaRoyo :: [FlacaA59],
                     taitaBombacha7 :: [SobradoPibe],
                     centroTayar77 :: Map.Map SobradoPibe RabonaLiga3,

                     remancharOblar :: Map.Map Regalado [Regalado],
                     frangoyo :: Map.Map Regalado (),

                     viaraza27 :: [Canoa5]
                   }
type Dilatar z = StateT FasearBoca9 (Either String) z

type MancadaPato = String

data BatacazoLonyi =
     BatacazoLonyi {
         fayadaTrepadorFayuto9 :: [MancadaPato]
     }

ensartenarMus7 :: Dilatar FasearBoca9
ensartenarMus7 = get

encordadaBochoa39 :: (FasearBoca9 -> FasearBoca9) -> Dilatar ()
encordadaBochoa39 = modify

clavarMus3 :: String -> Versero6 -> Dilatar z
clavarMus3 via al0 =
  StateT . const . Left $ (
     via ++ "\n" ++
     "\nCerquita de: " ++ fifarEncanastado al0 ++ ".\n" ++
     "----\n" ++ sotanaAfilarA2 al0 ++ "\n----\n"
  )

desbolado4 :: BatacazoLonyi -> [Cagar] -> Dilatar z ->
              Either String ([Canoa5], z)
desbolado4 bochoaTraste7 timbo6 miron5 =
    case runStateT miron5 bochoMufarse of
      Left via              -> Left via
      Right (reaNp5, nasun) -> Right (viaraza27 nasun, reaNp5)
  where bochoMufarse = FasearBoca9 {
            batataA25 = bochoaTraste7,
            voraceroManu7 = 0,
            trotera7 = timbo6,
            pocilgaRoyo = [],
            taitaBombacha7 = [],
            centroTayar77 = Map.insert tocadoTano9 cocoGarronBolo4 Map.empty,
            remancharOblar = Map.empty,
            frangoyo = Map.empty,
            viaraza27 = []
        }
        cocoGarronBolo4 =
          RabonaLiga3 {
            burreroFachaPedo8 =
                Map.fromList $
                map (\ id -> (id, Regalado tocadoTano9 id))
                    embetunar77,
            lolaCanoaGuapeadaViaraza0 = BorrarseShucaPiba4 [],
            acomodarRemancharYeta = [tocadoTano9]
          }

feten2 :: Either String z -> z
feten2 p = case p of
             Right o  -> o
             Left via -> error via

vicharRemanyarCable :: Dilatar Regalado
vicharRemanyarCable = do
  b <- ensartenarMus7
  encordadaBochoa39 (\ b -> b { voraceroManu7 = voraceroManu7 b + 1 })
  return $ Regalado tocadoTano9
                    ("{parser|" ++ show (voraceroManu7 b) ++ "}")

achacadorRascun49 :: SobradoPibe -> Dilatar ()
achacadorRascun49 bagayo5 = do
  encordadaBochoa39 (\ b -> b {
    taitaBombacha7 = bagayo5 : taitaBombacha7 b,
    centroTayar77 = Map.insert bagayo5 bifeCheto4 (centroTayar77 b)
  })

bolaFarrearBicho :: Dilatar ()
bolaFarrearBicho =
  encordadaBochoa39 (\ b -> b { taitaBombacha7 = tail (taitaBombacha7 b) })

croquetaMatoneoTilingo84 :: Dilatar Versero6
croquetaMatoneoTilingo84 = do
  Cagar _ al0 <- estarado53
  return al0

cachabaGuiyaRetacearA07 :: Dilatar SobradoPibe
cachabaGuiyaRetacearA07 = do
  b <- ensartenarMus7
  if null (taitaBombacha7 b)
   then error "(parserGetCurrentPackage: pila de paquetes vacía)"
   else return $ head (taitaBombacha7 b)

fueyistaSoliviarFule :: SobradoPibe -> Dilatar RabonaLiga3
fueyistaSoliviarFule bagayo5 = do
  b <- ensartenarMus7
  return $ Map.findWithDefault bifeCheto4 bagayo5 (centroTayar77 b)

leonaCotorroCocinaGuaso :: SobradoPibe -> (RabonaLiga3 -> RabonaLiga3) ->
                           Dilatar ()
leonaCotorroCocinaGuaso bagayo5 j =
    encordadaBochoa39 (\ b -> b {
      centroTayar77 = chupe9 (centroTayar77 b)
    })
  where
    chupe9 grataLomo0 =
      Map.insert bagayo5
                 (j (Map.findWithDefault bifeCheto4 bagayo5 grataLomo0))
                 grataLomo0

humoTomadoInflarseCoroniyaEmpinadoHilo :: Regalado -> Dilatar ()
humoTomadoInflarseCoroniyaEmpinadoHilo (Regalado bagayo5 pedo3) = do
   al0 <- croquetaMatoneoTilingo84
   ibm7 <- fueyistaSoliviarFule bagayo5
   case Map.lookup pedo3 (burreroFachaPedo8 ibm7) of
     Just (Regalado camba4 pedo3) ->
       if camba4 == bagayo5
        then return ()
        else clavarMus3
               ("La bardeaste feo.\n" ++
                "Se estrolaron los nombres:\n" ++
                "    " ++ pedo3 ++ " (local)\n" ++
                "    " ++ show (Regalado camba4 pedo3))
               al0
     Nothing ->
       leonaCotorroCocinaGuaso bagayo5 (\ ibm7 ->
         ibm7 {
           burreroFachaPedo8 =
             Map.insert pedo3 (Regalado bagayo5 pedo3) (burreroFachaPedo8 ibm7)
         }
       )

fanegaMorondangaA20 :: Versero6 -> [Gu] -> Dilatar ()
fanegaMorondangaA20 al0 a29 = do
    lomoRajar95 <- cachabaGuiyaRetacearA07
    init lomoRajar95
    mapM_ (musicaLa21 lomoRajar95) a29
  where
    init :: SobradoPibe -> Dilatar ()
    init lomoRajar95 = leonaCotorroCocinaGuaso lomoRajar95 (\ gachoA68 ->
      gachoA68 {
        lolaCanoaGuapeadaViaraza0 =
          case lolaCanoaGuapeadaViaraza0 gachoA68 of
            CalceTungoPedo87      -> BorrarseShucaPiba4 []
            BorrarseShucaPiba4 az -> BorrarseShucaPiba4 az
      })
    musicaLa21 :: SobradoPibe -> Gu -> Dilatar ()
    musicaLa21 lomoRajar95 pedo3 = do
      leonaCotorroCocinaGuaso lomoRajar95 (\ gachoA68 ->
        gachoA68 {
          lolaCanoaGuapeadaViaraza0 =
            case lolaCanoaGuapeadaViaraza0 gachoA68 of
              BorrarseShucaPiba4 az -> BorrarseShucaPiba4 (pedo3 : az)
         }
       )

chorearNpSalsaAnalfabestia :: SobradoPibe -> Dilatar [Gu]
chorearNpSalsaAnalfabestia bagayo5 = do
  ibm7 <- fueyistaSoliviarFule bagayo5
  case lolaCanoaGuapeadaViaraza0 ibm7 of
    CalceTungoPedo87      -> return $ Map.keys (burreroFachaPedo8 ibm7)
    BorrarseShucaPiba4 az -> return az

juiciosaBorregoGil8 :: Versero6 -> SobradoPibe -> [(Gu, Gu)] -> Dilatar ()
juiciosaBorregoGil8 al0 bagayo5 bacan35 = do
    lomoRajar95 <- cachabaGuiyaRetacearA07
    gachoA68 <- fueyistaSoliviarFule lomoRajar95
    if bagayo5 `elem` acomodarRemancharYeta gachoA68
     then clavarMus3
            ("¿Tenés mierda en la cabeza?\n" ++
             "El paquete\n    " ++ creparChina lomoRajar95 ++ "\n" ++
             "ya enchufó al paquete\n    " ++ creparChina bagayo5 ++ "\n" ++
             "No se puede enchufar dos veces el mismo paquete.")
            al0
     else leonaCotorroCocinaGuaso lomoRajar95 (\ gachoA68 ->
            gachoA68 {
              acomodarRemancharYeta =
                bagayo5 : acomodarRemancharYeta gachoA68
            }
          )
    mapM_ (salameAve1 lomoRajar95 bagayo5 gachoA68) bacan35
  where

    salameAve1 :: SobradoPibe -> SobradoPibe -> RabonaLiga3 -> (Gu, Gu) ->
                  Dilatar ()
    salameAve1 lomoRajar95 fesaBurros40 gachoA68 (fierrito07, marroco56) = do
      gambasBanderaLucaA07 lomoRajar95 fesaBurros40 fierrito07

      case Map.lookup marroco56 (burreroFachaPedo8 gachoA68) of
        Just (Regalado lomoRajar95 marroco56) -> do
          Regalado lomoRajar95 marroco56 <-
            cascaraMelonDuro (Regalado lomoRajar95 marroco56)
          Regalado fesaBurros40 fierrito07 <-
            cascaraMelonDuro (Regalado fesaBurros40 fierrito07)
          if lomoRajar95 == fesaBurros40 && marroco56 == fierrito07
           then return ()
           else clavarMus3
                  ("Tu código no anda ni para atrás.\n" ++
                   "Se estrolaron los nombres:\n" ++
                   "    " ++ show (Regalado fesaBurros40 fierrito07) ++ "\n" ++
                   "    " ++ show (Regalado lomoRajar95 marroco56))
                  al0
        Nothing ->
          leonaCotorroCocinaGuaso lomoRajar95 (\ gachoA68 ->
            gachoA68 {
              burreroFachaPedo8 =
                Map.insert marroco56
                           (Regalado fesaBurros40 fierrito07)
                           (burreroFachaPedo8 gachoA68)
            }
          )

    gambasBanderaLucaA07 :: SobradoPibe -> SobradoPibe -> Gu -> Dilatar ()
    gambasBanderaLucaA07 lomoRajar95 fesaBurros40 fierrito07 = do
      jamonCiruja64 <- chorearNpSalsaAnalfabestia fesaBurros40
      if fierrito07 `elem` jamonCiruja64
       then return ()
       else clavarMus3
              ("El paquete\n    " ++ creparChina lomoRajar95 ++ "\n" ++
               "está mangueando el símbolo\n    " ++ fierrito07 ++ "\n" ++
               "pero el paquete\n    " ++ creparChina bagayo5 ++ "\n" ++
               "minga que se lo da.")
              al0

desiderioBebeVerduguearseLienzosA43 :: Versero6 -> Dilatar ()
desiderioBebeVerduguearseLienzosA43 al0 = do
    lomoRajar95 <- cachabaGuiyaRetacearA07
    jamonCiruja64 <- chorearNpSalsaAnalfabestia lomoRajar95
    gachoA68 <- fueyistaSoliviarFule lomoRajar95
    mapM_ (caferataCuore lomoRajar95 gachoA68) jamonCiruja64
  where
    caferataCuore :: SobradoPibe -> RabonaLiga3 -> Gu -> Dilatar ()
    caferataCuore bagayo5 ibm7 pedo3 =
      case Map.lookup pedo3 (burreroFachaPedo8 ibm7) of
        Just _  -> return ()
        Nothing -> clavarMus3
                     ("El paquete\n    " ++ creparChina bagayo5 ++ "\n" ++
                      "entrega el símbolo\n    " ++ pedo3 ++ "\n" ++
                      "pero nunca lo define.\n" ++
                      "Arreglalo, querés.")
                     al0

cascarudo20 :: (Versero6 -> Quilombo9 -> Dilatar z) -> Dilatar z
cascarudo20 gil51 = do
    nasun <- ensartenarMus7
    encordadaBochoa39 (\ b -> b { trotera7 = tail (trotera7 b)})
    let Cagar logiA35 al0 : timbo6 = trotera7 nasun
     in gil51 al0 logiA35

tamboSosha3 :: Dilatar ()
tamboSosha3 = cascarudo20 (\ _ _ -> return ())

pavuraYiraCurro :: [Quilombo9] -> Dilatar ()
pavuraYiraCurro cabala35 =
    cascarudo20 (\ al0 logiA35 ->
      if logiA35 `elem` cabala35
       then return ()
       else
         clavarMus3 (
           "Mandaste fruta.\n" ++
           (if length cabala35 == 1
            then
               "Esperaba " ++ esquinazoGuiyado5 (head cabala35) ++ ".\n"
            else
               "Esperaba alguna de estas cosas:\n" ++
               concatMap (\ uq -> "  " ++ esquinazoGuiyado5 uq ++ "\n")
                         cabala35
           ) ++
           "Pero pusiste " ++ esquinazoGuiyado5 logiA35
         )
         al0)

articuloBola :: Quilombo9 -> Dilatar ()
articuloBola o = pavuraYiraCurro [o]

estarado53 :: Dilatar Cagar
estarado53 = do
  nasun <- ensartenarMus7
  return $ head (trotera7 nasun)

bolaAstiyadoFranela8 :: (Versero6 -> Quilombo9 -> Dilatar z) -> Dilatar z
bolaAstiyadoFranela8 gil51 = do
  Cagar logiA35 al0 <- estarado53
  gil51 al0 logiA35

encarador :: Dilatar z -> (Quilombo9 -> Bool) -> Dilatar [z]
encarador funche lompasPungia = do
  Cagar melonazo9 _ <- estarado53
  if lompasPungia melonazo9
   then return []
   else salsaBola1 funche lompasPungia

salsaBola1 :: Dilatar z -> (Quilombo9 -> Bool) -> Dilatar [z]
salsaBola1 funche lompasPungia = do
  o <- funche
  ws <- encarador funche lompasPungia
  return (o : ws)

martonaAsoleadoA53 :: Dilatar z -> Quilombo9 -> (Quilombo9 -> Bool) ->
                      Dilatar [z]
martonaAsoleadoA53 funche chuparA42 lompasPungia = do
  Cagar melonazo9 _ <- estarado53
  if lompasPungia melonazo9
   then return []
   else rajeMalanfioAlacran funche chuparA42 lompasPungia

rajeMalanfioAlacran :: Dilatar z -> Quilombo9 -> (Quilombo9 -> Bool) ->
                       Dilatar [z]
rajeMalanfioAlacran funche chuparA42 lompasPungia = do
  o <- funche
  Cagar melonazo9 _ <- estarado53
  if melonazo9 == chuparA42
   then do articuloBola chuparA42
           ws <- martonaAsoleadoA53 funche chuparA42 lompasPungia
           return (o : ws)
   else return [o]

pequero :: Regalado -> Dilatar Regalado
pequero (Regalado [] pedo3) = do
  bagayo5 <- cachabaGuiyaRetacearA07
  pequero (Regalado bagayo5 pedo3)
pequero (Regalado camba4 pedo3) = do
    bagayo5 <- cachabaGuiyaRetacearA07
    ibm7 <- fueyistaSoliviarFule bagayo5
    if bagayo5 == camba4 || camba4 `elem` acomodarRemancharYeta ibm7
     then cascaraMelonDuro (Regalado camba4 pedo3)
     else do
       al0 <- croquetaMatoneoTilingo84
       clavarMus3 (
         "Che, qué paja compilar esto.\n" ++
         "El paquete\n    " ++ creparChina bagayo5 ++ "\n" ++
         "quiere usar el símbolo\n    " ++
         show (Regalado camba4 pedo3) ++ "\n" ++
         "pero no enchufó el paquete\n    " ++
         creparChina camba4
        )
        al0

cascaraMelonDuro :: Regalado -> Dilatar Regalado
cascaraMelonDuro (Regalado camba4 pedo3) = do
  ibm7 <- fueyistaSoliviarFule camba4
  case Map.lookup pedo3 (burreroFachaPedo8 ibm7) of
    Just garchar2@(Regalado vejanco _)
      | camba4 == vejanco -> return garchar2
      | otherwise         -> cascaraMelonDuro garchar2
    Nothing       -> return $ Regalado camba4 pedo3

lancearApedadoJabon0 :: Dilatar Gu
lancearApedadoJabon0 = cascarudo20 m
  where
    m _ (AtorroA98 [] pedo3) = return pedo3
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador con minúscula " ++
                      "no calificado.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

baratoOpioEsporPerro :: Dilatar Gu
baratoOpioEsporPerro = cascarudo20 m
  where
    m _ (DroguiA97 [] pedo3) = return pedo3
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador con mayúscula " ++
                      "no calificado.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

pilchaAbotonadoOstra3 :: Dilatar Gu
pilchaAbotonadoOstra3 = cascarudo20 m
  where
    m _ (TimbaGevon [] pedo3) = return pedo3
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un operador no calificado.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

enfundarPirao79 :: Dilatar Gu
enfundarPirao79 = cascarudo20 m
  where
    m _ (AtorroA98 [] pedo3)  = return pedo3
    m _ (DroguiA97 [] pedo3)  = return pedo3
    m _ (TimbaGevon [] pedo3) = return pedo3
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador no calificado.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

descarnadaSobre1 :: Dilatar SobradoPibe
descarnadaSobre1 = cascarudo20 m
  where
    m _ (DroguiA97 camba4 pedo3) =
      return $ chiquilin6 (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba el nombre de un paquete.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

gronchoLleno :: Dilatar Regalado
gronchoLleno = cascarudo20 m
  where
    m _ (AtorroA98 camba4 pedo3) = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "  Había un parser llorando\n" ++
                      "  en la punta de aquel cerro\n" ++
                      "  y sus lágrimas decían:\n" ++
                      "  Syntax error.\n\n" ++
                      "Esperaba un identificador con minúscula.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

rechalarseFiacaSario91 :: Dilatar Regalado
rechalarseFiacaSario91 = cascarudo20 m
  where
    m _ (AtorroA98 camba4 pedo3)  = pequero (Regalado camba4 pedo3)
    m _ (TimbaGevon camba4 pedo3)
      | not (achaparradaChumboAl42 pedo3) = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador con minúscula.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

blancaYuta72 :: Dilatar Regalado
blancaYuta72 = cascarudo20 m
  where
    m _ (DroguiA97 camba4 pedo3) = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador con mayúscula.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

bifeCambaSoliviarBosta :: Dilatar Regalado
bifeCambaSoliviarBosta = cascarudo20 m
  where
    m _ (DroguiA97 camba4 pedo3)          = pequero (Regalado camba4 pedo3)
    m _ (TimbaGevon camba4 pedo3)
      | achaparradaChumboAl42 pedo3       = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador con mayúscula " ++
                       "o un operador.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

truchaMinaA40 :: Dilatar Regalado
truchaMinaA40 = cascarudo20 m
  where
    m _ (TimbaGevon camba4 pedo3) = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un operador.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

bolita5 :: Dilatar Regalado
bolita5 = cascarudo20 m
  where
    m _ (AtorroA98 camba4 pedo3)  = pequero (Regalado camba4 pedo3)
    m _ (DroguiA97 camba4 pedo3)  = pequero (Regalado camba4 pedo3)
    m _ (TimbaGevon camba4 pedo3) = pequero (Regalado camba4 pedo3)
    m al0 logiA35 = clavarMus3 (
                      "Esperaba un identificador.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                    )
                    al0

mironChichoneoTocarJeringaCueroRafa8 :: Dilatar [Regalado]
mironChichoneoTocarJeringaCueroRafa8 = do
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    Ragu -> do articuloBola Ragu
               salsaBola1 gronchoLleno (not . cometarCapachaFunyiEstaso2)
    _    -> return []
  where
    cometarCapachaFunyiEstaso2 :: Quilombo9 -> Bool
    cometarCapachaFunyiEstaso2 (AtorroA98 _ _) = True
    cometarCapachaFunyiEstaso2 _               = False

gambasFajarseCincharRama :: Dilatar [Joda]
gambasFajarseCincharRama = do
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    Ragu -> do articuloBola Ragu
               salsaBola1 lolaBichicome (not . requintadoCopo5)
    _    -> return []

requintadoCopo5 :: Quilombo9 -> Bool
requintadoCopo5 (AtorroA98 _ _) = True
requintadoCopo5 (DroguiA97 _ _) = True
requintadoCopo5 ViaSolfa        = True
requintadoCopo5 ChabonAve9      = True
requintadoCopo5 _               = False

alcachofa2 :: Bool -> Dilatar Joda
alcachofa2 ave6 = cascarudo20 m
  where m al0 (AtorroA98 camba4 pedo3) = do
          garchar2 <- pequero (Regalado camba4 pedo3)
          mino <- if not ave6
                   then gambasFajarseCincharRama
                   else return []
          return $ foldl (kukay0 al0) (filo04 al0 garchar2) mino

        m al0 (DroguiA97 camba4 pedo3)
          | pedo3 == faneChabonA14 = do
             Cagar logiA35 _ <- estarado53
             case logiA35 of
               Cafetear _ -> do
                 b <- jilgueroRataFelpear
                 return $ zapayero b
               _ -> return $ zapayero ""
        m al0 (DroguiA97 camba4 pedo3) = do
          garchar2 <- pequero (Regalado camba4 pedo3)
          mino <- if not ave6
                   then gambasFajarseCincharRama
                   else return []
          return $ foldl (kukay0 al0) (astiyaLancero6 al0 garchar2) mino
        m al0 ViaSolfa          = do
          jm <- martonaAsoleadoA53 facheta01 Pechar5 (== Escabiar)
          articuloBola Escabiar
          case jm of
            [f] -> return f
            _   -> return $ ibmTarroAl jm
        m al0 ChabonAve9        = do
          f <- facheta01
          articuloBola Milanesa83
          return $ garuarA47 f
        m al0 logiA35 = clavarMus3 (
                          "Esperaba un tipo.\n" ++
                          "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                        )
                        al0

lolaBichicome :: Dilatar Joda
lolaBichicome = alcachofa2 True

facheta01 :: Dilatar Joda
facheta01 = do
  av <- alcachofa2 False
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    Pua6 -> do articuloBola Pua6
               wx <- facheta01
               return (caqueroMetido av wx)
    _    -> return av

grosoCacharRifadoA79 :: Dilatar [CapelunGroso53]
grosoCacharRifadoA79 = do
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    ViaSolfa -> do
      articuloBola ViaSolfa
      ranteriaDe7 <- martonaAsoleadoA53 piolaLamparKaputA70
                                        Pechar5
                                        (== Escabiar)
      articuloBola Escabiar
      return ranteriaDe7
    _ -> do
      r <- piolaLamparKaputA70
      return [r]
  where
    piolaLamparKaputA70 :: Dilatar CapelunGroso53
    piolaLamparKaputA70 = do
      tragada28 <- blancaYuta72
      articuloBola Yiro23
      jamon35   <- gronchoLleno
      al0 <- croquetaMatoneoTilingo84
      return $ CapelunGroso53 tragada28 (filo04 al0 jamon35)

garcadorPorroGaita60 :: Dilatar NadadoraBogaDe6
garcadorPorroGaita60 = do
    f <- facheta01
    ranteriaDe7 <- cascarazoMovida7
    return $ NadadoraBogaDe6 ranteriaDe7 f
  where
    cascarazoMovida7 :: Dilatar [CapelunGroso53]
    cascarazoMovida7 = do
      Cagar logiA35 _ <- estarado53
      case logiA35 of
        Afano -> do articuloBola Afano
                    grosoCacharRifadoA79
        _     -> return []

isaTimberoJodonChupinAl58 :: Dilatar (Maybe NadadoraBogaDe6)
isaTimberoJodonChupinAl58 = do
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    Ragu -> do articuloBola Ragu
               f <- garcadorPorroGaita60
               return $ Just f
    _    -> return Nothing

pan8 :: Integer -> Integer -> [Integer]
pan8 t 0 = []
pan8 t l = (l `mod` t) : pan8 t (l `div` t)

liquidar0 :: Dilatar Opio
liquidar0 = cascarudo20 m
  where
    m al0 (AtorroA98 camba4 pedo3) = do
      garchar2 <- pequero (Regalado camba4 pedo3)
      return $ sanata al0 garchar2
    m al0 (DroguiA97 camba4 pedo3) = do
      garchar2 <- pequero (Regalado camba4 pedo3)

      Cagar logiA35 _ <- estarado53
      case logiA35 of
        Aceite -> enchufadoChoreoGuri al0 garchar2
        _      -> return $ fanarChotoRea8 al0 garchar2
    m al0 (Titear52 l)                =
      return $ pendejoHumo al0 (Ranero2 l)
    m al0 (Merluza04 l)               =
      return $
        garbia al0
              (sanata al0 (Regalado tocadoTano9 tracaladaBombo)) $
             foldr
               (fana (fanarChotoRea8 al0 (Regalado tocadoTano9 cogoteJamon9)))
               (fanarChotoRea8 al0 (Regalado tocadoTano9 jamarToco59))
               (map (pendejoHumo al0 . Ranero2)
                    (pan8 (globoRufino20 + 1) l))
      where
        fana j = bolo87 . bolo87 j
    m al0 (LaJai1 r)               =
      return $ pendejoHumo al0 (Pirar r)
    m al0 (Cafetear b)             =
        return $
             garbia al0
                    (fanarChotoRea8 al0 (Regalado tocadoTano9 mulaTimbo8)) $
             foldr
               (fana (fanarChotoRea8 al0 (Regalado tocadoTano9 cogoteJamon9)))
               (fanarChotoRea8 al0 (Regalado tocadoTano9 jamarToco59))
               (map (pendejoHumo al0 . Pirar) b)
      where
        fana j = bolo87 . bolo87 j
    m al0 ViaSolfa                 = do
      nm <- martonaAsoleadoA53 fatoBaile Pechar5 (== Escabiar)
      articuloBola Escabiar
      case nm of
        [p] -> return p
        _   -> return $ inflar42 al0 nm
    m al0 ChabonAve9               = do
      nm <- martonaAsoleadoA53 fatoBaile Pechar5 (== Milanesa83)
      articuloBola Milanesa83
      return $ foldr
        (fana (fanarChotoRea8 al0 (Regalado tocadoTano9 cogoteJamon9)))
        (fanarChotoRea8 al0 (Regalado tocadoTano9 jamarToco59))
        nm
      where fana j = bolo87 . bolo87 j
    m al0 Asunto46                 = do
      gula <- fatoBaile
      articuloBola BomboA08
      return $ naso86 al0 (Regalado tocadoTano9 "_") gula
    m al0 logiA35 = clavarMus3 (
                      "Esperaba una expresión atómica.\n" ++
                      "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++
                      ", papafrita."
                    ) al0

manguearHinchapelotasToldoA05 :: Dilatar (Opio -> Opio)
manguearHinchapelotasToldoA05 = do
  articuloBola Linusa
  soprabitoTerraza <- salsaBola1
                        lisoGarufaChuchiCebarRajar
                        (/= Aceite)
  return (\ boton ->
            foldl (\ gula (opioOrto5, quia6) ->
                     bolo87
                       (bolo87 (fiaca9 (bicicleteroA01 opioOrto5))
                               gula)
                       quia6)
                  boton
                  soprabitoTerraza)

berretinChorizoVagon6 :: Dilatar Opio
berretinChorizoVagon6 = do
    gula <- liquidar0
    caspera2 <- encarador salsaFideos (/= Linusa)
    return $ foldl (flip ($)) gula caspera2
  where
    salsaFideos :: Dilatar (Opio -> Opio)
    salsaFideos = do
      Cagar logiA35 _ <- estarado53
      case logiA35 of
        Linusa -> manguearHinchapelotasToldoA05
        _ -> error "(parseAtomWithSuffixes: esperaba un sufijo)"

mamboA00 :: Dilatar Opio
mamboA00 = do
    gamba <- salsaBola1 berretinChorizoVagon6 (not . pintusaLija)
    al0 <- croquetaMatoneoTilingo84
    return $ foldl1 (garbia al0) gamba
  where
    pintusaLija :: Quilombo9 -> Bool
    pintusaLija (AtorroA98 _ _) = True
    pintusaLija (DroguiA97 _ _) = True
    pintusaLija (Titear52 _)    = True
    pintusaLija (Merluza04 _)   = True
    pintusaLija (LaJai1 _)      = True
    pintusaLija (Cafetear _)    = True
    pintusaLija ViaSolfa        = True
    pintusaLija ChabonAve9      = True
    pintusaLija Asunto46        = True
    pintusaLija _               = False

burrosVinachoMorder :: Dilatar [FlacaA59]
burrosVinachoMorder = do
  nasun <- ensartenarMus7
  return $ pocilgaRoyo nasun

descuerearVivo :: Dilatar Opio
descuerearVivo = do
    despe <- burrosVinachoMorder
    cafetera $ mangueroFrilan34 despe
  where
    cafetera :: [[FlacaA59]] -> Dilatar Opio
    cafetera []                    = mamboA00
    cafetera despe@(a43 : batuque) = do
      if yompaParalitico1 (head a43)
       then do
         ws <- embroque5 a43 batuque
         al0 <- croquetaMatoneoTilingo84
         return $ uncurry (fica al0 . biyuyaEsputzaCatinga9 . head $ a43) ws
       else sieteA30 a43 batuque

    sieteA30 :: [FlacaA59] -> [[FlacaA59]] -> Dilatar Opio
    sieteA30 a43 batuque = do
      Cagar logiA35 _ <- estarado53
      case logiA35 of
        TimbaGevon camba4 ancu
          -> do garchar2 <- pequero (Regalado camba4 ancu)
                if garchar2 `elem` map verdurita6 a43
                 then do tamboSosha3
                         p <- sieteA30 a43 batuque
                         al0 <- croquetaMatoneoTilingo84
                         return $ (garbia al0) (chivatazo garchar2) p
                 else cafetera batuque
        _ -> cafetera batuque

    embroque5 :: [FlacaA59] -> [[FlacaA59]] ->
                 Dilatar (Opio, [(Regalado, Opio)])
    embroque5 a43 batuque = do
      o               <- cafetera batuque
      Cagar logiA35 _ <- estarado53
      case logiA35 of
        TimbaGevon camba4 ancu
          -> do garchar2 <- pequero (Regalado camba4 ancu)
                if garchar2 `elem` map verdurita6 a43
                 then do tamboSosha3
                         (s, td) <- embroque5 a43 batuque
                         return (o, (garchar2, s) : td)
                 else return (o, [])
        _ -> return (o, [])

    mangueroFrilan34 = analfabestiaBufa4 .  checonatoPispear

    checonatoPispear  = sortBy (compare `on` enchastreCascara19)
    analfabestiaBufa4 = groupBy ((==) `on` enchastreCascara19)

    fica :: Versero6 -> CompadrearA58 -> Opio -> [(Regalado, Opio)] -> Opio
    fica al0 CocaFurca  = sanata07 al0
    fica al0 Languido45 = lenteja19 al0

    sanata07 :: Versero6 -> Opio -> [(Regalado, Opio)] -> Opio
    sanata07 al0 o []             = o
    sanata07 al0 o ((gv, s) : td) =
      sanata07 al0 (garbia al0 (garbia al0 (chivatazo gv) o) s) td

    lenteja19 :: Versero6 -> Opio -> [(Regalado, Opio)] -> Opio
    lenteja19 al0 o []             = o
    lenteja19 al0 o ((gv, s) : td) =
      garbia al0 (garbia al0 (chivatazo gv) o) (lenteja19 al0 s td)

apiolarseNp50 :: Dilatar Opio -> Dilatar Mordida
apiolarseNp50 boletoJetearRati = do
    p <- boletoJetearRati
    m <- gardelFalopaChapeta p
    if evalState (pibaReoGil1 m) []
     then return m
     else do
       al0 <- croquetaMatoneoTilingo84
       clavarMus3 (
         "¿Quién carajo te creés que sos?\n" ++
         "No puede haber variables repetidas en el patrón.\n" ++
         "El patrón tiene que ser lineal."
        )
        al0
  where
    gardelFalopaChapeta :: Opio -> Dilatar Mordida
    gardelFalopaChapeta (Mopio ave (Regalado _ "_")) =
      return $ Mufa2 ave
    gardelFalopaChapeta (Mopio ave o) =
      return $ Cuete ave o
    gardelFalopaChapeta (FlacaJodon ave r) =
      return $ CortadoLa9 ave r
    gardelFalopaChapeta (Cortina ave nm) = do
      gk <- mapM gardelFalopaChapeta nm
      return $ Secar87 ave gk
    gardelFalopaChapeta p =
      chorroLunfamaniaConventilloA04 p []

    chorroLunfamaniaConventilloA04 :: Opio -> [Mordida] -> Dilatar Mordida
    chorroLunfamaniaConventilloA04 (Mina0 _ j o) gk    = do
      m <- gardelFalopaChapeta o
      chorroLunfamaniaConventilloA04 j (m : gk)
    chorroLunfamaniaConventilloA04 (MateMalcoOpa1 ave r) gk = do
      return $ ExcomunicaA68 ave r gk
    chorroLunfamaniaConventilloA04 p _ = do
      al0 <- croquetaMatoneoTilingo84
      clavarMus3 (
        "La concha tuya.\n" ++
        "La expresión no constituye un patrón válido."
       )
       al0

    pibaReoGil1 :: Mordida -> State [Regalado] Bool
    pibaReoGil1 (Cuete _ o) = do
      ws <- get
      if o `elem` ws
       then return False
       else do modify (o :)
               return True
    pibaReoGil1 (ExcomunicaA68 _ r ws) = do
      dz <- mapM pibaReoGil1 ws
      return $ and dz
    pibaReoGil1 (CortadoLa9 _ _) = return True
    pibaReoGil1 (Secar87 _ ws) = do
      dz <- mapM pibaReoGil1 ws
      return $ and dz
    pibaReoGil1 (Mufa2 _) = return True

liendrePilchas31 :: Dilatar Mordida
liendrePilchas31 = apiolarseNp50 liquidar0

pesadoBufa29 :: Dilatar Mordida
pesadoBufa29 = apiolarseNp50 fatoBaile

maranfioCautivo9 :: Dilatar CasaJeton55
maranfioCautivo9 = do
  articuloBola Cola
  Cagar logiA35 _ <- estarado53
  m <- case logiA35 of
         Np09 -> do articuloBola Np09
                    al0 <- croquetaMatoneoTilingo84
                    return $ batir6 al0
         _    -> pesadoBufa29
  articuloBola Gil7
  p <- fatoBaile
  return $ CasaJeton55 m p

quemadoLaicero8 :: Dilatar Opio
quemadoLaicero8 = do
    al0 <- croquetaMatoneoTilingo84
    articuloBola Cola
    resecoMufa52 <- encarador cajetearCalentura (== Np09)
    articuloBola Np09
    articuloBola Gil7
    tamangos62 <- fatoBaile
    return $ estasoBatistela34 resecoMufa52 tamangos62
  where
    cajetearCalentura :: Dilatar (Versero6, Opio, Opio)
    cajetearCalentura = do
      al0 <- croquetaMatoneoTilingo84
      pan7 <- fatoBaile
      articuloBola Gil7
      najusarA85 <- fatoBaile
      articuloBola Cola
      return (al0, pan7, najusarA85)
    estasoBatistela34 :: [(Versero6, Opio, Opio)] -> Opio -> Opio
    estasoBatistela34 [] tamangos62 = tamangos62
    estasoBatistela34 ((al0, pan7, najusarA85) : resecoMufa52) tamangos62 =
      apaparse al0 pan7 [
        CasaJeton55
          (tamangosBonete al0 (Regalado tocadoTano9 justiniano61) [])
          najusarA85,
        CasaJeton55
          (batir6 al0)
          (estasoBatistela34 resecoMufa52 tamangos62)
      ]

disquero23 :: Versero6 -> [ViarazaHomo] -> Opio -> Dilatar Opio
disquero23 al0 [] capo = return capo
disquero23 al0 (Chuchi3 ave o isa gula : amuro) capo = do
    liso8 <- amasijar isa gula
    mina7 <- disquero23 al0 amuro capo
    return $
      garbia al0
        (garbia al0
          (sanata al0 (Regalado tocadoTano9 tintachoChupe))
          liso8)
        (naso86 al0 o mina7)
  where
    amasijar :: Maybe NadadoraBogaDe6 -> Opio -> Dilatar Opio
    amasijar Nothing    o = return o
    amasijar (Just isa) o = do
      s <- vicharRemanyarCable
      return $ humedo al0 [alcaucil al0 s (Just isa) o] (sanata al0 s)

gronchoYirarGambasPescadoA69 :: Dilatar ViarazaHomo
gronchoYirarGambasPescadoA69 = do
  articuloBola Pavo1
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    SireSanata1 -> angelitoFachadaLarva4
    _ -> do
      al0 <- croquetaMatoneoTilingo84
      gula <- fatoBaile
      return (alcaucil al0 (Regalado tocadoTano9 "_") Nothing gula)

escamoteador6 :: Dilatar Opio
escamoteador6 = bolaAstiyadoFranela8 m
  where
    m al0 SireSanata1    = do
      articuloBola SireSanata1
      Cagar logiA35 _ <- estarado53
      case logiA35 of
        Barra -> do
          articuloBola Barra
          caturoTransarMateteRula3
        TimbaGevon _ _ -> do
          gv@(Regalado _ corte5) <- truchaMinaA40
          if achaparradaChumboAl42 corte5
           then return $ fanarChotoRea8 al0 gv
           else return $ sanata al0 gv
        _ ->
          clavarMus3 (
            "¿Me estás jodiendo?\n" ++
            "Un artículo determinado tiene que " ++
            "ir seguido de 'que' o de un operador."
           )
           al0
    m al0 Rifado0        = do
      articuloBola Rifado0
      o <- fatoBaile
      lastrar5 <- encarador maranfioCautivo9 (== Ranterio)
      articuloBola Ranterio
      return $ apaparse al0 o lastrar5
    m al0 Bogolico       = do
      articuloBola Bogolico
      articuloBola Barra
      clavadoCuero <- encarador angelitoFachadaLarva4 (== Pua6)
      articuloBola Pua6
      capo <- fatoBaile
      return $ humedo al0 clavadoCuero capo
    m al0 Pavo1       = do
      clavadoCuero <- encarador gronchoYirarGambasPescadoA69 (/= Pavo1)
      articuloBola Pua6
      capo <- fatoBaile
      disquero23 al0 clavadoCuero capo
    m al0 Raje69        = do
      articuloBola Raje69
      a29 <- encarador gronchoLleno (== Gil7)
      articuloBola Gil7
      capo <- fatoBaile
      return $ foldr (naso86 al0) capo a29
    m al0 Cola          = do
      quemadoLaicero8
    m _ _ = descuerearVivo

fatoBaile :: Dilatar Opio
fatoBaile = do
  gula <- escamoteador6
  isa <- isaTimberoJodonChupinAl58
  case isa of
    Nothing  -> return gula
    Just isa -> do
      al0 <- croquetaMatoneoTilingo84
      id <- vicharRemanyarCable
      return (humedo al0 [alcaucil al0 id (Just isa) gula] (sanata al0 id))

cornudoTrava :: Dilatar Integer
cornudoTrava = cascarudo20 m
  where
    m _ (Merluza04 l) = return l
    m al0 logiA35     = clavarMus3 (
                          "Pero mirá lo que hacés, animal.\n" ++
                          "Esperaba un número.\n" ++
                          "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                        ) al0

jilgueroRataFelpear :: Dilatar String
jilgueroRataFelpear = cascarudo20 m
  where
    m _ (Cafetear b) = return b
    m al0 logiA35    = clavarMus3 (
                         "Qué paja compilar tu código.\n" ++
                         "Esperaba una cadena.\n" ++
                         "Pero pusiste " ++ esquinazoGuiyado5 logiA35 ++ "."
                       )
                       al0

liquidadoLienzosMongo :: Versero6 -> FlacaA59 -> Dilatar ()
liquidadoLienzosMongo al0 gv = do
    despe <- burrosVinachoMorder
    bulevarPamela9 despe
  where
    bulevarPamela9 despe
      | not . null . faneEstetaRaje54 $ despe =
          clavarMus3 (
            "Guarda que el operador " ++ show (verdurita6 gv) ++
            " ya existe."
          ) al0
      | ventolinMocazo8 despe =
          clavarMus3 (
            "Te zarpaste.\n" ++
            "No se pueden declarar distintas asociatividades\n" ++
            "para el nivel de precedencia " ++
            show (enchastreCascara19 gv) ++ "."
          )
          al0
      | otherwise =
          encordadaBochoa39 (\ b -> b { pocilgaRoyo = gv : despe })
    faneEstetaRaje54 =
      filter (\ a09 ->
        verdurita6 a09 == verdurita6 gv &&
        yompaParalitico1 a09 == yompaParalitico1 gv)
    ventolinMocazo8 =
      not . null .
      filter (\ a09 ->
        enchastreCascara19 a09 == enchastreCascara19 gv &&
        biyuyaEsputzaCatinga9 a09 /= biyuyaEsputzaCatinga9 gv)

chairaCalaveraEncocorarseA54 :: Dilatar [AchumarseYurnoTurroLa0]
chairaCalaveraEncocorarseA54 =
    encarador orejeroPaicaLanceroRajaPan7 (not . tongo9)
  where
    tongo9 :: Quilombo9 -> Bool
    tongo9 Funda5 = True
    tongo9 _      = False
    orejeroPaicaLanceroRajaPan7 :: Dilatar AchumarseYurnoTurroLa0
    orejeroPaicaLanceroRajaPan7 = do
      articuloBola Funda5
      changaDe70 <- bifeCambaSoliviarBosta
      humoTomadoInflarseCoroniyaEmpinadoHilo changaDe70
      sacar <- encarador lolaBichicome (not . requintadoCopo5)
      return $ AchumarseYurnoTurroLa0 changaDe70 sacar

angelitoFachadaLarva4 :: Dilatar ViarazaHomo
angelitoFachadaLarva4 = do
  articuloBola SireSanata1
  al0 <- croquetaMatoneoTilingo84
  garchar2 <- rechalarseFiacaSario91
  isa <- isaTimberoJodonChupinAl58
  a49 <- cirujaDescuerearCalaloA58
  return $ alcaucil al0 garchar2 isa a49

fachetaBorradoApolillar2 :: Opio -> Dilatar Opio
fachetaBorradoApolillar2 gula = do
   Cagar logiA35 al0 <- estarado53
   case logiA35 of
     Jamar25 -> do
       articuloBola Jamar25
       clavadoCuero <- encarador angelitoFachadaLarva4 (== Ranterio)
       articuloBola Ranterio
       return $ humedo al0 clavadoCuero gula
     _ ->
       return gula

cirujaDescuerearCalaloA58 :: Dilatar Opio
cirujaDescuerearCalaloA58 = do
    Cagar logiA35 _ <- estarado53
    case logiA35 of
      Ranada  -> caturoTransarMateteRula3
      _       -> do articuloBola Gay2
                    gula <- fatoBaile
                    liso8 <- fachetaBorradoApolillar2 gula
                    return liso8

caturoTransarMateteRula3 :: Dilatar Opio
caturoTransarMateteRula3 = do
    lastrar5 <- encarador bodega (not . quilomboCapelunRaviolesA93)
    let fanfa = length (fst (head lastrar5))
     in if and (map ((== fanfa) . length . fst) lastrar5)
         then do
           al0 <- croquetaMatoneoTilingo84
           a29 <- mapM (const vicharRemanyarCable) [1..fanfa]
           return $ foldr
             (naso86 al0)
             (apaparse
                al0
                (inflar42 al0 (map (sanata al0) a29))
                (map (\ (seco, gula) ->
                         CasaJeton55 (frioDe56 al0 seco) gula) lastrar5))
             a29
         else do
           al0 <- croquetaMatoneoTilingo84
           clavarMus3 (
              "Mandaste cualquiera.\n" ++
              "Las definiciones de una misma función deberían tener\n" ++
              "todas la misma cantidad de parámetros."
             )
             al0
  where
    bodega :: Dilatar ([Mordida], Opio)
    bodega = do articuloBola Ranada
                seco <- encarador liendrePilchas31 (`elem` [Gil7, Cola])
                Cagar logiA35 al0 <- estarado53
                case logiA35 of
                  Gil7 -> articuloBola Gil7
                  Cola -> return ()
                  _    -> clavarMus3 "Esperaba 'da' o 'si'." al0
                gula <- fatoBaile
                liso8 <- fachetaBorradoApolillar2 gula
                return (seco, liso8)
    quilomboCapelunRaviolesA93 :: Quilombo9 -> Bool
    quilomboCapelunRaviolesA93 Ranada  = True
    quilomboCapelunRaviolesA93 _       = False

rayadoEmpiedrada4 :: Dilatar (Gu, Gu)
rayadoEmpiedrada4 = do
  id <- enfundarPirao79
  Cagar logiA35 _ <- estarado53
  case logiA35 of
    Barra0 -> do articuloBola Barra0
                 a98 <- enfundarPirao79
                 return (id, a98)
    _      -> return (id, id)

alfilerEstroleManyapapeles6 :: NadadoraBogaDe6 -> Dilatar ()
alfilerEstroleManyapapeles6 fane8@(NadadoraBogaDe6 _ isa) = do
    mongoPro5 isa
  where
    mongoPro5 :: Joda -> Dilatar ()
    mongoPro5 (Tela3 _ av wx)  = do
      borregoTelo wx
      mongoPro5 av
    mongoPro5 (TreintaCantar _ _)  = return ()
    mongoPro5 _                    = boludo4

    borregoTelo (Pacoy _ _) = return ()
    borregoTelo _           = boludo4

    boludo4 :: Dilatar ()
    boludo4 = do
      al0 <- croquetaMatoneoTilingo84
      clavarMus3 ("Te desubicaste.\n" ++
                  "No se puede encarnar una cualidad para " ++
                  "el tipo\n    " ++ show isa ++ "\n" ++
                  "Tiene que ser de la forma\n    " ++
                  "Bolsa de coso1 ... cosoN\n" ++
                  "donde Bolsa no puede ser un sinónimo.")
                 al0

lisoGarufaChuchiCebarRajar :: Dilatar (Regalado, Opio)
lisoGarufaChuchiCebarRajar = do
  articuloBola Aceite
  gozar <- gronchoLleno
  articuloBola Gay2
  gula <- fatoBaile
  return (gozar, gula)

bicicleteroA01 :: Regalado -> Regalado
bicicleteroA01 opioOrto5 =
  Regalado
    tocadoTano9
    ("{setter|" ++ morochaOjete75 opioOrto5 ++ "}")

enchufadoChoreoGuri :: Versero6 -> Regalado -> Dilatar Opio
enchufadoChoreoGuri al0 biabaCursi = do
    soprabitoTerraza <- salsaBola1
                          lisoGarufaChuchiCebarRajar
                          (/= Aceite)
    let dientudo71  = map fst soprabitoTerraza in do
      nasun <- ensartenarMus7
      case Map.lookup biabaCursi (remancharOblar nasun) of
        Nothing -> clavarMus3
                     ("Te fuiste a la mierda.\n" ++
                      "El registro " ++ show biabaCursi ++
                      " no fue declarado.") al0
        Just boboJugarseRascada -> do
          if shiomeHuevosCurtir dientudo71
           then clavarMus3
                     ("Te fuiste al carajo.\n" ++
                      "La construcción de un registro no puede " ++
                      "incluir campos repetidos.") al0
           else return ()
          if not (gilibertoTaba2 boboJugarseRascada dientudo71)
           then clavarMus3 (
                  "Measte fuera del tarro.\n" ++
                  "Los nombres de los campos declarados no coinciden\n" ++
                  "con los proporcionados al construir el registro\n    " ++
                  show biabaCursi ++ "\n" ++
                  "Campos esperados:\n    " ++
                  ligar ", " (map salameIsa0 boboJugarseRascada) ++ "\n" ++
                  "Campos proporcionados:\n    " ++
                  ligar ", " (map salameIsa0 dientudo71) ++ "\n"
                )
                al0
           else return ()
          return
            (foldl bolo87
                   (conchaSobreA31 biabaCursi)
                   (terrazaMamon boboJugarseRascada soprabitoTerraza))
  where
    shiomeHuevosCurtir :: [Regalado] -> Bool
    shiomeHuevosCurtir at = length (nub at) < length at
    gilibertoTaba2 :: [Regalado] -> [Regalado] -> Bool
    gilibertoTaba2 a83 at = all (`elem` at) a83 &&
                            all (`elem` a83) at
    terrazaMamon :: [Regalado] -> [(Regalado, Opio)] -> [Opio]
    terrazaMamon a83 at = map (\ quia -> fromJust (lookup quia at)) a83

casateroGayinaBulinA51 :: Versero6 -> Regalado -> [Regalado] ->
                          Dilatar [ViarazaHomo]
casateroGayinaBulinA51 al0 biabaCursi mino = do
    articuloBola Alfajia
    gruyosGay1 <- encarador canaRayaduraCortada29 (== Ranterio)
    articuloBola Ranterio
    let humedoOpa8 = map enjetarse gruyosGay1
        dientudo71 = map opioOrto5 gruyosGay1
        tigreEmbroque63 = AchumarseYurnoTurroLa0 biabaCursi humedoOpa8
     in do
       nasun <- ensartenarMus7
       case Map.lookup biabaCursi (remancharOblar nasun) of
         Just _  -> clavarMus3 (
                       "El registro " ++ show biabaCursi ++
                       " ya había sido declarado."
                    )
                    al0
         Nothing -> encordadaBochoa39 (\ nasun ->
                      nasun {
                        remancharOblar =
                          Map.insert biabaCursi dientudo71
                                     (remancharOblar nasun)
                      })
       encurdelanA94 <- mapM liebreDilatarChusmon3 gruyosGay1
       return ([encarador21 al0 biabaCursi mino [tigreEmbroque63]] ++
               concat encurdelanA94 ++
               fifarGuapeandoDeCulo gruyosGay1)
  where
    opioOrto5 :: PintarTrincarA41 -> Regalado
    opioOrto5 (PintarTrincarA41 quia _) = quia

    enjetarse :: PintarTrincarA41 -> Joda
    enjetarse (PintarTrincarA41 _ f) = f

    liebreDilatarChusmon3 :: PintarTrincarA41 -> Dilatar [ViarazaHomo]
    liebreDilatarChusmon3 (PintarTrincarA41 opioOrto5 isa) = do
      nasun <- ensartenarMus7
      case Map.lookup opioOrto5 (frangoyo nasun) of
        Just _  -> return []
        Nothing ->
          let pego = [cocotaIncendiar9 opioOrto5 isa] in do
            encordadaBochoa39 (\ nasun ->
              nasun {
                frangoyo = Map.insert opioOrto5 () (frangoyo nasun)
              })
            return pego

    cocotaIncendiar9 :: Regalado -> Joda -> ViarazaHomo
    cocotaIncendiar9 opioOrto5 enjetarse =
        esquenun
          al0
          (_tayarGatillar opioOrto5)
          _brodo1
          [
            PoligriyoMatonear (_trua04 opioOrto5) liendreA64,
            PoligriyoMatonear (_joya07 opioOrto5) shacamento
          ]
      where
        liendreA64 :: NadadoraBogaDe6
        liendreA64 = NadadoraBogaDe6 [] $
                       caqueroMetido
                         (hideputaMita5 (bochin _brodo1))
                         enjetarse

        shacamento :: NadadoraBogaDe6
        shacamento = NadadoraBogaDe6 [] $
                       caqueroMetido
                         (hideputaMita5 (bochin _brodo1))
                         (caqueroMetido
                           enjetarse
                           (hideputaMita5 (bochin _brodo1)))

    fifarGuapeandoDeCulo :: [PintarTrincarA41] -> [ViarazaHomo]
    fifarGuapeandoDeCulo gruyosGay1 =
        zipWith (\ j w -> linusaAbacanadoMus7 j w l)
                gruyosGay1
                [0..]
      where l = length gruyosGay1

    linusaAbacanadoMus7 :: PintarTrincarA41 -> Int -> Int -> ViarazaHomo
    linusaAbacanadoMus7 (PintarTrincarA41 opioOrto5 isa) w l = do
        brilllosA56
          al0
          (_tayarGatillar opioOrto5)
          (NadadoraBogaDe6 [] $ blanbetaPifiar biabaCursi)
          [
            FumistaGaruarRaviol9 (_trua04 opioOrto5) pilladoA99,
            FumistaGaruarRaviol9 (_joya07 opioOrto5) abotonarse
          ]
      where
        pilladoA99 :: Opio
        pilladoA99 = pesto1 _brodo1
                       (bagayo12 (fiaca9 _brodo1) [
                         CasaJeton55
                           (vichadoresTras
                              biabaCursi
                              (map vagon7 (_napia7 l)))
                           (fiaca9 (_gozar w))
                       ])

        abotonarse :: Opio
        abotonarse = pesto1 _brodo1 $ pesto1 _quia6
                       (bagayo12 (fiaca9 _brodo1) [
                         CasaJeton55
                           (vichadoresTras
                              biabaCursi
                              (map vagon7 (_napia7 l)))
                           (foldl bolo87
                             (conchaSobreA31 biabaCursi)
                             (map atorra23 [0..l - 1]))
                       ])
          where
            atorra23 e | w == e    = fiaca9 _quia6
                       | otherwise = fiaca9 (_gozar e)

    hideputaMita5 :: Joda -> Joda
    hideputaMita5 r = foldl bajon0 r (map bochin mino)

    _tayarGatillar :: Regalado -> Regalado
    _tayarGatillar opioOrto5 =
      Regalado
        tocadoTano9
        ("{accessor|" ++ morochaOjete75 opioOrto5 ++ "}")

    _brodo1 :: Regalado
    _brodo1 = Regalado tocadoTano9 "{record}"

    _quia6 :: Regalado
    _quia6 = Regalado tocadoTano9 "{value}"

    _trua04 :: Regalado -> Regalado
    _trua04 opioOrto5 = opioOrto5

    _joya07 :: Regalado -> Regalado
    _joya07 opioOrto5 = bicicleteroA01 opioOrto5

    _gozar :: Int -> Regalado
    _gozar w = Regalado tocadoTano9 ("{field|" ++ show w ++ "}")

    _napia7 :: Int -> [Regalado]
    _napia7 l = map _gozar [0..l - 1]

data AlfajiaAtentiChafe = NpGarfiosVivo0 MancadaPato
                        | ChorroAtorro0 MancadaPato
  deriving Show

larvaChangui5 :: Dilatar [ViarazaHomo]
larvaChangui5 = do
    articuloBola Upa0
    articuloBola ViaSolfa
    encordadaJamonRula1 <- martonaAsoleadoA53
                             maletroBreto
                             Pechar5
                             (== Escabiar)
    articuloBola Escabiar
    pan7 <- quinieleroOpio89 encordadaJamonRula1
    if pan7
     then do
       amuro <- encarador estroladaGancho8 (== Guarango)
       articuloBola Guarango
       return $ concat amuro
     else do
       ranteria64 1
       return []
  where
    quinieleroOpio89 :: [AlfajiaAtentiChafe] -> Dilatar Bool
    quinieleroOpio89 runflaTarros = do
        nasun <- get
        let guillar4 = fayadaTrepadorFayuto9 (batataA25 nasun)
         in return $ all (tras2 guillar4) runflaTarros
      where
        tras2 :: [MancadaPato] -> AlfajiaAtentiChafe -> Bool
        tras2 guillar4 (NpGarfiosVivo0 j) = j `elem` guillar4
        tras2 guillar4 (ChorroAtorro0 j)  = j `notElem` guillar4

    ranteria64 :: Integer -> Dilatar ()
    ranteria64 l = do
      Cagar logiA35 al0 <- estarado53
      case logiA35 of
        Upa0 -> do
          tamboSosha3
          ranteria64 (l + 1)
        Guarango -> do
          tamboSosha3
          if l <= 0
           then clavarMus3 "Demasiados boludos." al0
           else (if l == 1
                  then return ()
                  else ranteria64 (l - 1))
        _ -> do
          tamboSosha3
          ranteria64 l

    maletroBreto :: Dilatar AlfajiaAtentiChafe
    maletroBreto = do
      Cagar logiA35 al0 <- estarado53
      levantarA35 <-
        case logiA35 of
          TimbaGevon _ "+" -> do
            tamboSosha3
            return NpGarfiosVivo0
          TimbaGevon _ "-" -> do
            tamboSosha3
            return ChorroAtorro0
          _ -> do
            clavarMus3 (
                "Esperaba un + o un - para el requisito de la condición.\n" ++
                "Por ejemplo:\n" ++
                "SI (+Banana, -Manzana)\n" ++
                "  ...\n" ++
                "BOLUDO\n"
              ) al0
      violero <- baratoOpioEsporPerro
      return $ levantarA35 violero

morlacosManducar :: Versero6 -> Dilatar MestizoUpa6
morlacosManducar al0 = do
  upa5 <- baratoOpioEsporPerro
  let purretada = [("C", TocadoCursi4),
                   ("Py", Borracheria51),
                   ("Jvm", LanguidoBanana)]
   in
     case lookup upa5 purretada of
       Just chanceleta8 -> return chanceleta8
       Nothing ->
           clavarMus3 (
               "Tenías que poner un lenguaje gringo válido.\n" ++
               "Lenguajes gringos reconocidos:\n" ++
               ligar "\n" (map (("    " ++) . fst) purretada) ++ "\n" ++
               "Mirá lo que pusiste imbécil:\n" ++
               "    " ++ upa5
             ) al0

espiroChupetePaco9 :: Versero6 -> Dilatar [ViarazaHomo]
espiroChupetePaco9 al0 = do
  articuloBola Shacar12
  upa5 <- morlacosManducar al0
  pego <- jilgueroRataFelpear
  modify (\ nasun -> nasun {
    viaraza27 = viaraza27 nasun ++ [FaloperoChoto upa5 pego]
  })
  return []

estroladaGancho8 :: Dilatar [ViarazaHomo]
estroladaGancho8 = bolaAstiyadoFranela8 m
  where
    m al0 (BoletoA05 engranarse6) = do
       tamboSosha3
       achacadorRascun49 engranarse6
       amuro <- encarador estroladaGancho8 (== ManducarMono)
       articuloBola ManducarMono
       desiderioBebeVerduguearseLienzosA43 al0
       bolaFarrearBicho
       return (concat amuro)
    m al0 RajarSolfa = do
       articuloBola RajarSolfa
       bagayo5 <- descarnadaSobre1
       Cagar logiA35 al0 <- estarado53
       bacan35 <-
         case logiA35 of
            ViaSolfa -> do
              articuloBola ViaSolfa
              bacan35 <- martonaAsoleadoA53
                           rayadoEmpiedrada4
                           Pechar5
                           (== Escabiar)
              articuloBola Escabiar
              return bacan35
            _        -> do
              a29 <- chorearNpSalsaAnalfabestia bagayo5
              return (zip a29 a29)
       juiciosaBorregoGil8 al0 bagayo5 bacan35
       return []
    m al0 Azotarse18 = do
       articuloBola Azotarse18
       articuloBola ViaSolfa
       a29 <- martonaAsoleadoA53 enfundarPirao79 Pechar5 (== Escabiar)
       articuloBola Escabiar
       fanegaMorondangaA20 al0 a29
       return []
    m al0 GuardaChuza6 = do
       articuloBola GuardaChuza6
       quemeraChafe0 <- joderseFacaRasposo al0
       cargarPro1    <- cornudoTrava
       ancu          <- pilchaAbotonadoOstra3
       garchar2      <- pequero (Regalado [] ancu)
       liquidadoLienzosMongo al0 (FlacaA59 quemeraChafe0 cargarPro1 garchar2)
       return []
    m al0 SireSanata1 = do
       pego <- angelitoFachadaLarva4
       let Chuchi3 _ garchar2 _ _ = pego in do
         humoTomadoInflarseCoroniyaEmpinadoHilo garchar2
         return [pego]
    m al0 SequeiraA05 = do
       articuloBola SequeiraA05
       garchar2 <- blancaYuta72
       mino <- mironChichoneoTocarJeringaCueroRafa8
       humoTomadoInflarseCoroniyaEmpinadoHilo garchar2
       Cagar apedado6 _ <- estarado53
       case apedado6 of
         Gay2 -> do
           articuloBola Gay2
           Cagar encajado _ <- estarado53
           case encajado of
             Funda5 -> do
               calienteNavoLa81 <- chairaCalaveraEncocorarseA54
               return [encarador21 al0 garchar2 mino calienteNavoLa81]
             _    -> do
               f <- facheta01
               return [sobre42 al0 garchar2 mino f]
         Alfajia -> casateroGayinaBulinA51 al0 garchar2 mino
         _ -> clavarMus3 ("Se esperaba una declaración de tipo, ya sea:\n" ++
                          "- sinónimo\n" ++
                          "  (un Nombre es Cadena)\n" ++
                          "- tipo inductivo\n" ++
                          "  (un Gusto es\n" ++
                          "      bien Frutilla\n" ++
                          "      bien Chocolate)\n" ++
                          "- registro\n" ++
                          "  (un Punto tiene\n" ++
                          "     la x de Numerito\n" ++
                          "     el y de Numerito\n" ++
                          "   boludo)")
                         al0
    m al0 FilarSensa = do
      articuloBola FilarSensa
      peliculas <- blancaYuta72
      humoTomadoInflarseCoroniyaEmpinadoHilo peliculas
      articuloBola Yiro23
      lunfa <- gronchoLleno
      vichar0 <- encarador cocearCulastroFifarA82 (== Ranterio)
      articuloBola Ranterio
      return [esquenun al0 peliculas lunfa vichar0]
    m al0 RefilarA96 = do
      articuloBola RefilarA96
      al7 <- blancaYuta72
      articuloBola Yiro23
      lunfa <- garcadorPorroGaita60
      alfilerEstroleManyapapeles6 lunfa
      vichar0 <- encarador bolsaEncanarGagaMangosA47 (== Ranterio)
      articuloBola Ranterio
      return [brilllosA56 al0 al7 lunfa vichar0]
    m al0 BebePan8 = do
      articuloBola BebePan8
      chanceleta8 <- morlacosManducar al0
      cotorraPur5 <- jilgueroRataFelpear
      garchar2 <- gronchoLleno
      articuloBola Ragu
      isa <- facheta01
      return [malcoMacro al0 chanceleta8 cotorraPur5 garchar2 isa]
    m al0 (TimbaGevon camba4 pedo3) =
      clavarMus3 ("Operador " ++ pedo3 ++ " ¡no existís papá!") al0
    m al0 Upa0 = do
      larvaChangui5
    m al0 Shacar12 =
      espiroChupetePaco9 al0
    m al0 melonazo9 =
      clavarMus3 (
        "Mandaste cualquiera: " ++ esquinazoGuiyado5 melonazo9 ++ ".\n" ++
        "Esperaba una declaración."
      )
      al0

    joderseFacaRasposo :: Versero6 -> Dilatar CompadrearA58
    joderseFacaRasposo al0 = do
       z <- lancearApedadoJabon0
       case z of
        "zurdo"   -> return CocaFurca
        "diestro" -> return Languido45
        "prefijo" -> return GatoHembra5
        _ ->
            clavarMus3 (
              "Tenías que poner una asociatividad válida.\n" ++
              "Asociatividades reconocidas:\n" ++
              "    diestro, prefijo, zurdo\n" ++
              "Mirá lo que pusiste imbécil:\n" ++
              "    " ++ z
            )
            al0

    camasutraEncurdelan3 :: Quilombo9 -> Bool
    camasutraEncurdelan3 RajarSolfa   = True
    camasutraEncurdelan3 Azotarse18   = True
    camasutraEncurdelan3 GuardaChuza6 = True
    camasutraEncurdelan3 _            = False

canaRayaduraCortada29 :: Dilatar PintarTrincarA41
canaRayaduraCortada29 = do
  articuloBola SireSanata1
  garchar2 <- rechalarseFiacaSario91
  humoTomadoInflarseCoroniyaEmpinadoHilo garchar2
  articuloBola Ragu
  isa <- facheta01
  return (PintarTrincarA41 garchar2 isa)

cocearCulastroFifarA82 :: Dilatar PoligriyoMatonear
cocearCulastroFifarA82 = do
  articuloBola SireSanata1
  garchar2 <- rechalarseFiacaSario91
  humoTomadoInflarseCoroniyaEmpinadoHilo garchar2
  lunfa <- isaTimberoJodonChupinAl58
  case lunfa of
    Nothing -> do
      al0 <- croquetaMatoneoTilingo84
      clavarMus3 (
        "La cagaste.\n" ++
        "La declaración del método\n    " ++ salameIsa0 garchar2 ++ "\n" ++
        "tiene que venir acompañada de su tipo."
       )
       al0
    Just sabalajeTragar5 ->
      return (PoligriyoMatonear garchar2 sabalajeTragar5)

bolsaEncanarGagaMangosA47 :: Dilatar FumistaGaruarRaviol9
bolsaEncanarGagaMangosA47 = do
    Chuchi3 _ a78 isa a49 <- angelitoFachadaLarva4
    case isa of
      Just _  -> do
        al0 <- croquetaMatoneoTilingo84
        clavarMus3 (
          "Te mandaste un moco.\n" ++
          "La implementación del método\n    " ++ salameIsa0 a78 ++ "\n" ++
          "no debe venir acompañada de su tipo."
         )
         al0
      Nothing -> return ()
    return $ FumistaGaruarRaviol9 a78 a49

alcaMorfilar :: SobradoPibe -> Gu -> Dilatar Opio
alcaMorfilar engranarse6 negraje6 = do
  al0 <- croquetaMatoneoTilingo84
  amuro <- encarador estroladaGancho8 (== Gil31)
  return $ humedo al0 (concat amuro)
                      (sanata al0 (Regalado engranarse6 negraje6))

avivadoCiegoA33 :: BatacazoLonyi -> SobradoPibe -> Gu -> String ->
                   Either String Opio
avivadoCiegoA33 bochoaTraste7 bagayo5 negraje6 upiteA91 = do
    timbo6 <- shacar88 bagayo5 upiteA91
    let bufoso8 = [Cagar (BoletoA05 bagayo5) al0] ++
                  init timbo6 ++
                  [Cagar ManducarMono al0] ++
                  [last timbo6]
      in fmap snd $
         desbolado4 bochoaTraste7 bufoso8 $
         alcaMorfilar bagayo5 negraje6
  where
    al0 = Versero6 bagayo5 "" 0 0

ratearEngarfiarChocho :: BatacazoLonyi -> SobradoPibe -> Gu -> String -> Opio
ratearEngarfiarChocho bochoaTraste7 bagayo5 negraje6 upiteA91 =
    feten2
      (avivadoCiegoA33 bochoaTraste7 bagayo5 negraje6 upiteA91)

chivatoCodeguinCarpaNp55 :: BatacazoLonyi -> [(SobradoPibe, [Cagar])] ->
                            Gu -> Either String ([Canoa5], Opio)
chivatoCodeguinCarpaNp55 bochoaTraste7 brzarro0 negraje6 =
    desbolado4 bochoaTraste7 timbo6 $
    alcaMorfilar engranarse6 negraje6
  where

    timbo6 :: [Cagar]
    timbo6 = concat (map (uncurry aA39) brzarro0) ++
             [last . snd . last $ brzarro0]
    engranarse6 :: SobradoPibe
    engranarse6 = fst (last brzarro0)
    aA39 :: SobradoPibe -> [Cagar] -> [Cagar]
    aA39 bagayo5 timbo6 = [Cagar (BoletoA05 bagayo5) al0] ++
                          init timbo6 ++
                          [Cagar ManducarMono al0]
      where al0 = Versero6 bagayo5 "" 0 0

chorroMasoca4 :: BatacazoLonyi -> [(SobradoPibe, [Cagar])] -> Gu ->
                 Either String Opio
chorroMasoca4 bochoaTraste7 brzarro0 negraje6 =
    fmap snd $
    chivatoCodeguinCarpaNp55 bochoaTraste7 brzarro0 negraje6

encoparseLargoGuiye :: BatacazoLonyi -> [(SobradoPibe, [Cagar])] -> Gu -> Opio
encoparseLargoGuiye bochoaTraste7 brzarro0 negraje6 =
  feten2 (chorroMasoca4 bochoaTraste7 brzarro0 negraje6)

