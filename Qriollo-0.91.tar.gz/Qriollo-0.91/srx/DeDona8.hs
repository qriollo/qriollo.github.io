
module DeDona8(
        estaradoCatar5, cascarrientoCiruja4, cadeneroTragar2
    ) where

import Control.Applicative((<$>))
import Control.Monad(mapM_, filterM, zipWithM_)
import Control.Monad.Trans.State.Lazy(
        State, get, modify, evalState, runState, execState
    )
import qualified Data.Map as Map(
        Map, empty, insert, delete, lookup, member, keys, findWithDefault,
        fromList, toList,
    )
import Data.Maybe(fromJust)
import Data.List(union, (\\), sort, intersect)
import Via2(EncufarDe4(..), verseroAceite10)
import Mus(
        Mus,
        grilloA2, pestoJamonNp, napiunTole4, fumanteA4, coceo2,
        grosoClaraboyasRata,
    )
import Lija9(encajarChotoEnfriado66)

import FiruloGuay3

data Tachometro25 = Tachometro25 {
    jugadoChubasco :: Integer,

    encanutarFifar7 :: Map.Map La4 TocadoTras10,

    chinchudoCarozos509 :: Map.Map La4 [La4],

    torniyo6 :: Map.Map La4 (),

    cocaEspamentoso1 :: Map.Map La4 [La4],

    yiraTostero :: Map.Map La4 (),

    formadorCandidatoRama7 :: Map.Map La4 [La4],

    hembraAzotarse27 :: Map.Map La4 (La4, La4),

    batilio56 :: Mus La4 Bacan8,

    forrarseShushetaEncanutar607 :: Map.Map La4 ()
  }

type Brodo995 = State Tachometro25

biabaLa5 :: Eq t => (z -> [t]) -> [z] -> [t]
biabaLa5 j = foldr union [] . map j

gilada394 :: (Eq t, Monad d) => (z -> d [t]) -> [z] -> d [t]
gilada394 j ws = do
  twb <- mapM j ws
  return $ foldr union [] twb

diego8 :: TocadoTras10 -> La4
diego8 (Zarzo79 o _ _) = o

secante30 :: Bacan8 -> [La4]
secante30 (Naso o) = [o]
secante30 _ = []

drogui86 :: Liga2 -> [La4]
drogui86 (Cuete45 fifi id gula) =
  biabaLa5 secante30 fifi `union` (drogui86 gula \\ [id])
drogui86 (Guarda4 _ a49 id gula) =
  secante30 a49 `union` (drogui86 gula \\ [id])
drogui86 (Reo7 a49 fifi) =
  secante30 a49 `union` biabaLa5 secante30 fifi
drogui86 (Manu amuro gula) =
   (biabaLa5 encordada585 amuro `union` drogui86 gula) \\ map diego8 amuro
 where
   encordada585 :: TocadoTras10 -> [La4]
   encordada585 (Zarzo79 _ garuga capo) = drogui86 capo \\ garuga
drogui86 (Patova8 a49 gamba) =
  secante30 a49 `union` biabaLa5 drogui86 gamba
drogui86 (Marinante1 _ fifi a29 gamba) =
  biabaLa5 secante30 fifi `union` (biabaLa5 drogui86 gamba \\ a29)
drogui86 (ChivoA70 _ fifi id gula) =
  biabaLa5 secante30 fifi `union` (drogui86 gula \\ [id])

mosquetaGrasun5 :: Liga2 -> [La4]
mosquetaGrasun5 (Cuete45 _ _ gula)       = mosquetaGrasun5 gula
mosquetaGrasun5 (Guarda4 _ _ _ gula)     = mosquetaGrasun5 gula
mosquetaGrasun5 (Reo7 a49 fifi)          = secante30 a49
mosquetaGrasun5 (Manu amuro gula)        =
    biabaLa5 carataChirolaCafua5 amuro `union` mosquetaGrasun5 gula
  where
    carataChirolaCafua5 :: TocadoTras10 -> [La4]
    carataChirolaCafua5 (Zarzo79 _ _ gula) = mosquetaGrasun5 gula
mosquetaGrasun5 (Patova8 _ gamba)        = biabaLa5 mosquetaGrasun5 gamba
mosquetaGrasun5 (Marinante1 _ _ _ gamba) = biabaLa5 mosquetaGrasun5 gamba
mosquetaGrasun5 (ChivoA70 _ _ _ gula)    = mosquetaGrasun5 gula

cascarrientoCiruja4 :: Liga2 -> Liga2
cascarrientoCiruja4 gula =
  evalState (mordidaMacroOrto91 gula) (bochoMufarse gula)

estaradoCatar5 :: Liga2 -> Liga2
estaradoCatar5 gula =
  let liso8 = evalState (mordidaMacroOrto91 gula) (bochoMufarse gula) in
    montotoMaletro828 . encajarChotoEnfriado66 $ liso8

bochoMufarse :: Liga2 -> Tachometro25
bochoMufarse gula =
   Tachometro25 {
     jugadoChubasco = maximum (onda49 gula) + 1,
     encanutarFifar7 = Map.fromList [

       (-1, Zarzo79 (-1) [] $ Reo7 (Naso (-1)) [])
     ],
     torniyo6 = Map.empty,
     cocaEspamentoso1 = Map.empty,
     chinchudoCarozos509 = Map.fromList [

       (-1, [])
     ],
     yiraTostero = Map.empty,
     formadorCandidatoRama7 = Map.empty,
     hembraAzotarse27 = Map.empty,
     batilio56 = grilloA2,
     forrarseShushetaEncanutar607 = Map.fromList [

       (-1, ())
     ]
   }

cadeneroTragar2 :: Liga2 -> [(La4, [La4])]
cadeneroTragar2 gula =
    let nasun = execState (treintaBodega6 gula) (bochoMufarse gula) in
      map (\ (j, nz) -> (j, sort nz)) $
      Map.toList (formadorCandidatoRama7 nasun)
  where
    treintaBodega6 :: Liga2 -> Brodo995 ()
    treintaBodega6 gula = do
      huevos1 gula
      meresunda12 gula
      pelpaAtorrantearLlantas399

mordidaMacroOrto91 :: Liga2 -> Brodo995 Liga2
mordidaMacroOrto91 gula = do
    let liso8 = sobradorPajerto1 gula in do

      huevos1 liso8
      meresunda12 liso8

      pelpaAtorrantearLlantas399

      truaA80 liso8
  where
    sobradorPajerto1 :: Liga2 -> Liga2
    sobradorPajerto1 (Cuete45 fifi id gula) =
      Cuete45 fifi id (sobradorPajerto1 gula)
    sobradorPajerto1 (Guarda4 l a49 id gula) =
      Guarda4 l a49 id (sobradorPajerto1 gula)
    sobradorPajerto1 (Reo7 a49 fifi) =
      Reo7 a49 fifi
    sobradorPajerto1 (Manu amuro gula) =
        foldr (\ (LaburarVamo amuro) ->
                 Manu (map alcahueteChicatoAve8 amuro))
              (sobradorPajerto1 gula)
              (verseroAceite10 amuro)
      where
        alcahueteChicatoAve8 :: TocadoTras10 -> TocadoTras10
        alcahueteChicatoAve8 (Zarzo79 o a29 gula) =
          Zarzo79 o a29 (sobradorPajerto1 gula)
    sobradorPajerto1 (Patova8 a49 gamba) =
      Patova8 a49 (map sobradorPajerto1 gamba)
    sobradorPajerto1 (Marinante1 m fifi a29 gamba) =
      Marinante1 m fifi a29 (map sobradorPajerto1 gamba)
    sobradorPajerto1 (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 fifi id (sobradorPajerto1 gula)

    abocarse61 :: La4 -> Brodo995 Bacan8
    abocarse61 o = do
      nasun <- get
      case coceo2 o (batilio56 nasun) of
        Nothing -> return $ Naso o
        Just h  ->
          if grosoClaraboyasRata o (batilio56 nasun)
           then return h
           else error ("(closureConvert: La variable " ++ show o ++
                       " no está definida localmente)")

    guapear6 :: Bacan8 -> Brodo995 Bacan8
    guapear6 (Naso o) = abocarse61 o
    guapear6 h        = return h

    aceitar5 :: Brodo995 La4
    aceitar5 = do
      nasun <- get
      modify (\ nasun -> nasun { jugadoChubasco = jugadoChubasco nasun + 1 })
      return $ jugadoChubasco nasun

    truaA80 :: Liga2 -> Brodo995 Liga2
    truaA80 (Cuete45 fifi id gula) = do
      rua79 <- mapM guapear6 fifi
      Cuete45 rua79 id <$> truaA80 gula
    truaA80 (Guarda4 l a49 id gula) = do
      via7 <- guapear6 a49
      Guarda4 l via7 id <$> truaA80 gula
    truaA80 (Reo7 a49 fifi) = do
      gilun <- bombonHocicarTigreHomoMixto a49
      if gilun
       then do
         rua79 <- mapM guapear6 fifi
         let Naso j = a49 in do
           de8   <- pavadasSemblantear1 j
           pro4  <- mapM abocarse61 de8
           return $ Reo7 a49 (rua79 ++ pro4)
       else do
         via7  <- guapear6 a49
         rua79 <- mapM guapear6 fifi
         cuore99 <- aceitar5
         return $ Guarda4 0 via7 cuore99
                    (Reo7 (Naso cuore99) (rua79 ++ [via7]))
    truaA80 (Manu amuro gula) = do
        espiroGuita3 amuro gula
      where
        espiroGuita3 :: [TocadoTras10] -> Liga2 -> Brodo995 Liga2
        espiroGuita3 [pego@(Zarzo79 jai5 _ _)] gula = do
          gilun <- bombonPavoCocoEstrilado474 jai5
          if gilun
           then bagayeroBombo532 pego gula
           else ensuciarComision066 [pego] gula
        espiroGuita3 amuro gula = do
          ensuciarComision066 amuro gula

        bagayeroBombo532 :: TocadoTras10 -> Liga2 -> Brodo995 Liga2
        bagayeroBombo532 (Zarzo79 jai5 garuga capo) gula = do
          de8 <- pavadasSemblantear1 jai5
          lurpiar6 <- mapM (const aceitar5) de8
          gruaAmarretear4
          zipWithM_ movidaMenega de8 (map Naso lurpiar6)
          mina7 <- truaA80 capo
          guachoAcamalar
          liso8 <- truaA80 gula
          return (
            Manu [Zarzo79 jai5 (garuga ++ lurpiar6) mina7]
                 liso8
           )

        ensuciarComision066 :: [TocadoTras10] -> Liga2 -> Brodo995 Liga2
        ensuciarComision066 amuro gula = do
          de8 <- gilada394 pavadasSemblantear1 (map diego8 amuro)
          mapM_ faneAcoyaradoManyin0 amuro
          alce76 <- mapM (masocaGarugaBife64 de8 amuro) amuro
          pro4 <- mapM abocarse61 de8
          liso8 <- truaA80 gula
          return $
            Manu alce76 $
              foldr (\ (jai5, bolacear) ->
                       Cuete45 (Naso bolacear : pro4) jai5)
                    liso8
                    (zip (map diego8 amuro)
                         (map diego8 alce76))

        masocaGarugaBife64 :: [La4] -> [TocadoTras10] ->
                              TocadoTras10 -> Brodo995 TocadoTras10
        masocaGarugaBife64 de8 amuro (Zarzo79 jai5 garuga capo) = do
          (bolacear, chucho99) <- enchufeHecho7 jai5
          lurpiar6  <- mapM (const aceitar5) de8
          gruaAmarretear4
          movidaMenega jai5 (Naso chucho99)

          let charleta = map diego8 amuro \\ [jai5]
           in do
             cartonGomaTute6 <-
                  mapM (cueteOlivettiEnsillar lurpiar6)
                       charleta
             zipWithM_ movidaMenega de8 (map Naso lurpiar6)
             mina7 <- truaA80 capo
             guachoAcamalar
             return (
               Zarzo79 bolacear (garuga ++ [chucho99]) $
                 foldr (\ (leones1, w) ->
                            Guarda4 w (Naso chucho99) leones1)
                       (foldr ($) mina7 cartonGomaTute6)
                       (zip lurpiar6 [1..])
              )

        cueteOlivettiEnsillar :: [La4] -> La4 -> Brodo995 (Liga2 -> Liga2)
        cueteOlivettiEnsillar lurpiar6 atorrar = do
          (lenguaraz13, _) <- enchufeHecho7 atorrar
          tintiyoLecheA284 <- aceitar5
          movidaMenega atorrar (Naso tintiyoLecheA284)
          return (
            Cuete45 (Naso lenguaraz13 : map Naso lurpiar6)
                    tintiyoLecheA284
           )

        faneAcoyaradoManyin0 :: TocadoTras10 -> Brodo995 ()
        faneAcoyaradoManyin0 (Zarzo79 jai5 _ _) = do
          bolacear <- aceitar5
          chucho99 <- aceitar5
          modify (\ nasun -> nasun {
            hembraAzotarse27 = Map.insert jai5 (bolacear, chucho99)
                                          (hembraAzotarse27 nasun)
          })

        enchufeHecho7 :: La4 -> Brodo995 (La4, La4)
        enchufeHecho7 jai5 = do
          nasun <- get
          return $ Map.findWithDefault (error "") jai5
                                       (hembraAzotarse27 nasun)

    truaA80 (Patova8 a49 gamba) = do
      via7 <- guapear6 a49
      Patova8 via7 <$> mapM truaA80 gamba
    truaA80 (Marinante1 m fifi a29 gamba) = do
      rua79 <- mapM guapear6 fifi
      Marinante1 m rua79 a29 <$> mapM truaA80 gamba
    truaA80 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM guapear6 fifi
      ChivoA70 a13 rua79 id <$> truaA80 gula

    gruaAmarretear4 :: Brodo995 ()
    gruaAmarretear4 = modify (\ nasun -> nasun {
      batilio56 = pestoJamonNp (batilio56 nasun)
    })

    movidaMenega :: La4 -> Bacan8 -> Brodo995 ()
    movidaMenega o h = do
      gilun <- bombonPavoCocoEstrilado474 o
      if gilun
       then error "(closureConvert: se redefine una función conocida)"
       else return ()
      modify (\ nasun -> nasun {
        batilio56 = fumanteA4 o h (batilio56 nasun)
      })

    guachoAcamalar :: Brodo995 ()
    guachoAcamalar = modify (\ nasun -> nasun {
      batilio56 = napiunTole4 (batilio56 nasun)
    })

    pavadasSemblantear1 :: La4 -> Brodo995 [La4]
    pavadasSemblantear1 j = do
      nasun <- get
      case Map.lookup j (formadorCandidatoRama7 nasun) of
        Just o  -> return o
        Nothing -> error "(closureConvert: la función no es conocida)"

rebajeCachoRea8 :: La4 -> Brodo995 TocadoTras10
rebajeCachoRea8 jai5 = do
  nasun <- get
  return $ Map.findWithDefault
             (error "(closureConversion: no es una función)")
             jai5 (encanutarFifar7 nasun)

conejaChamuyetaDrogui4 :: La4 -> Brodo995 [La4]
conejaChamuyetaDrogui4 jai5 = do
  nasun <- get
  return $ Map.findWithDefault [] jai5 (formadorCandidatoRama7 nasun)

coger1 :: La4 -> Brodo995 ()
coger1 o = modify (\ nasun -> nasun {
  yiraTostero = Map.insert o () (yiraTostero nasun)
})

border478 :: Bacan8 -> Brodo995 ()
border478 (Naso o) = coger1 o
border478 _        = return ()

fame :: La4 -> Brodo995 ()
fame o = modify (\ nasun -> nasun {
  torniyo6 = Map.insert o () (torniyo6 nasun)
})

apunte :: La4 -> Brodo995 ()
apunte o = modify (\ nasun -> nasun {
  torniyo6 = Map.delete o (torniyo6 nasun)
})

huevos1 :: Liga2 -> Brodo995 ()
huevos1 (Cuete45 fifi id gula) = do
  mapM_ border478 fifi
  huevos1 gula
huevos1 (Guarda4 _ a49 id gula) = do
  border478 a49
  huevos1 gula
huevos1 (Reo7 a49 fifi) = do

  mapM_ border478 fifi
huevos1 (Manu amuro gula) = do
    mapM_ pestoChivo1 amuro
    huevos1 gula
    case amuro of
      [Zarzo79 jai5 _ _] -> do
          tocado5 <- yugador314 jai5
          if tocado5
           then return ()
           else modify (\ nasun -> nasun {
                  forrarseShushetaEncanutar607 =
                    Map.insert jai5 () (forrarseShushetaEncanutar607 nasun)
                })
      _ -> return ()
  where
    pestoChivo1 :: TocadoTras10 -> Brodo995 ()
    pestoChivo1 pego@(Zarzo79 j _ capo) = do
      modify (\ nasun -> nasun {
        encanutarFifar7 =
          Map.insert j pego (encanutarFifar7 nasun)
      })
      huevos1 capo
huevos1 (Patova8 a49 gamba) = do
  border478 a49
  mapM_ huevos1 gamba
huevos1 (Marinante1 _ fifi a29 gamba) = do
  mapM_ border478 fifi
  mapM_ huevos1 gamba
huevos1 (ChivoA70 _ fifi id gula) = do
  mapM_ border478 fifi
  huevos1 gula

meresunda12 :: Liga2 -> Brodo995 ()
meresunda12 (Cuete45 fifi id gula) = do
  fame id
  meresunda12 gula
  apunte id
meresunda12 (Guarda4 _ a49 id gula) = do
  fame id
  meresunda12 gula
  apunte id
meresunda12 (Reo7 a49 fifi) = return ()
meresunda12 (Manu amuro gula) = do
    mapM_ fame (map diego8 amuro)
    mapM_ refalarPavaUpa1 amuro
    meresunda12 gula
    mapM_ apunte (map diego8 amuro)
  where
    refalarPavaUpa1 :: TocadoTras10 -> Brodo995 ()
    refalarPavaUpa1 (Zarzo79 j garuga capo) = do
      mapM_ fame garuga
      meresunda12 capo
      mapM_ apunte garuga
      nasun <- get
      let mangos663 = garuga `union`
                      map diego8 amuro `union`
                      Map.keys (forrarseShushetaEncanutar607 nasun)
       in do
         modify (\ nasun -> nasun {
           chinchudoCarozos509 =
             Map.insert j
                        (drogui86 capo \\ mangos663)
                        (chinchudoCarozos509 nasun),
           cocaEspamentoso1 =
             Map.insert j
                        (Map.keys (torniyo6 nasun) \\ map diego8 amuro)
                        (cocaEspamentoso1 nasun)
         })
meresunda12 (Patova8 a49 gamba) = do
  mapM_ meresunda12 gamba
meresunda12 (Marinante1 _ fifi a29 gamba) = do
  mapM_ fame a29
  mapM_ meresunda12 gamba
  mapM_ apunte a29
meresunda12 (ChivoA70 _ fifi id gula) = do
  fame id
  meresunda12 gula
  apunte id

yugador314 :: La4 -> Brodo995 Bool
yugador314 o = do
  nasun <- get
  case Map.lookup o (encanutarFifar7 nasun) of
    Just _  -> return $ Map.member o (yiraTostero nasun)
    Nothing -> return True

bombonPavoCocoEstrilado474 :: La4 -> Brodo995 Bool
bombonPavoCocoEstrilado474 o = do
  nasun <- get
  return $ Map.member o (forrarseShushetaEncanutar607 nasun)

bombonHocicarTigreHomoMixto :: Bacan8 -> Brodo995 Bool
bombonHocicarTigreHomoMixto (Naso o) = bombonPavoCocoEstrilado474 o
bombonHocicarTigreHomoMixto _        = return False

pelpaAtorrantearLlantas399 :: Brodo995 ()
pelpaAtorrantearLlantas399 = do
    init
    mostrador541
    guarangoAbricolaFingar
  where

    init :: Brodo995 ()
    init = modify (\ nasun -> nasun {
      formadorCandidatoRama7 = chinchudoCarozos509 nasun
    })

    mostrador541 :: Brodo995 ()
    mostrador541 = do
      nasun <- get
      madama <- arrugado1 (Map.keys (encanutarFifar7 nasun))
      if madama
       then mostrador541
       else return ()

    guarangoAbricolaFingar :: Brodo995 ()
    guarangoAbricolaFingar = do
        nasun <- get
        mapM_ mandamasMalevoFajado (Map.keys (encanutarFifar7 nasun))
      where
        mandamasMalevoFajado :: La4 -> Brodo995 ()
        mandamasMalevoFajado jai5 = do
          nasun <- get
          let formador430  = Map.findWithDefault
                               (error "") jai5
                               (formadorCandidatoRama7 nasun)
              bandeado1    = Map.findWithDefault
                               (error "") jai5
                               (cocaEspamentoso1 nasun)
              revesinaA407 = formador430 `intersect` bandeado1
           in modify (\ nasun -> nasun {
               formadorCandidatoRama7 =
                 Map.insert jai5 revesinaA407
                            (formadorCandidatoRama7 nasun)
              })

    arrugado1 :: [La4] -> Brodo995 Bool
    arrugado1 [] = return False
    arrugado1 (jai5 : orto0) = do
      t <- arrugado1 orto0
      taba16 <- conejaChamuyetaDrogui4 jai5
      goma64 <- farristaBananaMamao2 jai5
      if all (\ h -> h `elem` taba16) goma64
       then return t
       else do

         modify (\ nasun -> nasun {
           formadorCandidatoRama7 =
             Map.insert jai5
                        (taba16 `union` goma64)
                        (formadorCandidatoRama7 nasun)
         })
         return True

    farristaBananaMamao2 :: La4 -> Brodo995 [La4]
    farristaBananaMamao2 jai5 = do
      Zarzo79 _ garuga capo <- rebajeCachoRea8 jai5
      let peluca = mosquetaGrasun5 capo in do
        casaGuri332 <- filterM bombonPavoCocoEstrilado474 peluca
        vkf <- gilada394 conejaChamuyetaDrogui4 casaGuri332
        return vkf

type Pescado28 = Map.Map La4 TocadoTras10
type Yapa1 = State Pescado28

montotoMaletro828 :: Liga2 -> Liga2
montotoMaletro828 gula =
    let (liso8, nasun) = runState (la45 gula) Map.empty in
      Manu (map snd (Map.toList nasun)) liso8
  where
    la45 :: Liga2 -> Yapa1 Liga2
    la45 (Cuete45 fifi id gula) = do
      rua79 <- mapM pepa9 fifi
      Cuete45 rua79 id <$> la45 gula
    la45 (Guarda4 l a49 id gula) = do
      via7 <- pepa9 a49
      Guarda4 l via7 id <$> la45 gula
    la45 (Reo7 a49 fifi) = do
      via7  <- pepa9 a49
      rua79 <- mapM pepa9 fifi
      return $ Reo7 via7 rua79
    la45 (Manu amuro gula) = do
        mapM_ royoYigolo5 amuro
        mapM_ chivo113 amuro
        la45 gula
      where
        royoYigolo5 :: TocadoTras10 -> Yapa1 ()
        royoYigolo5 (Zarzo79 o _ _) = do
          modify (Map.insert o (error ""))
        chivo113 :: TocadoTras10 -> Yapa1 ()
        chivo113 (Zarzo79 o garuga gula) = do
          liso8 <- la45 gula
          modify (Map.insert o (Zarzo79 o garuga liso8))
    la45 (Patova8 a49 gamba) = do
      via7 <- pepa9 a49
      Patova8 via7 <$> mapM la45 gamba
    la45 (Marinante1 m fifi a29 gamba) = do
      rua79 <- mapM pepa9 fifi
      Marinante1 m rua79 a29 <$> mapM la45 gamba
    la45 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM pepa9 fifi
      ChivoA70 a13 rua79 id <$> la45 gula

    pepa9 :: Bacan8 -> Yapa1 Bacan8
    pepa9 (Naso (-1)) = return $ Pingo7 (-1)
    pepa9 (Naso o) = do
      nasun <- get
      case Map.lookup o nasun of
        Nothing -> return $ Naso o
        Just _  -> return $ Pingo7 o
    pepa9 h = return h

