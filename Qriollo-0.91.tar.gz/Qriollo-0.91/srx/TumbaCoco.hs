
module TumbaCoco(
        tocadoTano9,

        resecoLa48, ventolinGrela, globoRufino20,
        metido03,
        mulaTimbo8,
        envainarFija,
        afanar683,
        rafaMamadero9,
        amuebladaRefilar, tintachoTruaCalo42, loraFuncarSalirLa77,
        balconearLacra6,

        diqueoFusilado39,
        cagarseMufarseChantar9, postaLaAbricolaOlfa33,

        madama93, jamarToco59, cogoteJamon9,
        mufarse9, justiniano61, macheteTrava7,
        barato353, maquinaTilingo76, mamaoLora32,

        carbura94, tintachoChupe, lastreAlfiler53,
        telefunken1, tracaladaBombo, empaquetado7,

        berretin721,

        babosoRama577, embetunarChe8, embolsicar13, fatoFanfa036,
        lanceAmurado9, lentazoCalle5, baileDiego769,
        mancarChafe6, fosforera741, formarVento9, ortoPapaLa76,
        barbaroFanarNp63, esgunfiarChaira6,
        bombearJamon4, fachatostaAl21, aceitePalmera4, bocadoZampar57,

        lofiarZurdo, agrampar660, entripaoBetun9,

        crostaCaron,
        bisagraLa,
        untarMina9,
        tarugo253,
        zapayero,
        caqueroMetido,
        calotearRabona138,
        ibmTarroAl,
        trepadorTras97,
        ranterio140,
        esputza993,

        garuarA47, jeteador825, madrugadoSequia24,
        faneChabonA14, petisa3, afrechudo5, bodegaBolaCalalo97,

        purriaAbaragar7, bolillaTrenzada7, bombachaEntubado,

        torta573, embetunar77, cachadorToco,
    ) where

import Chanceleta1

tocadoTano9 :: SobradoPibe
tocadoTano9 = ["PRIM"]

envainarFija :: Gu
envainarFija = "Función"

resecoLa48 :: Gu
resecoLa48 = "Numerito"

ventolinGrela :: Integer
ventolinGrela = 0

globoRufino20 :: Integer
globoRufino20 = 2 ^ 32 - 1

metido03 :: Gu
metido03 = "Letra"

mufarse9 :: Gu
mufarse9 = "Posta"

justiniano61 :: Gu
justiniano61 = "Sí"

macheteTrava7 :: Gu
macheteTrava7 = "No"

barato353 :: Gu
barato353 = "Falible"

mamaoLora32 :: Gu
mamaoLora32 = "Joya"

maquinaTilingo76 :: Gu
maquinaTilingo76 = "Cagó"

mulaTimbo8 :: Gu
mulaTimbo8 = "Texto"

opiarse23 :: Gu
opiarse23 = "Flotante"

faneChabonA14 :: String
faneChabonA14 = "Pendorcho"

petisa3 :: String -> Gu
petisa3 b = faneChabonA14 ++ " " ++ b

afrechudo5 :: Joda -> Bool
afrechudo5 (TreintaCantar _ (Regalado camba4 id)) =
  camba4 == tocadoTano9 &&
  take (length faneChabonA14 + 1) id == faneChabonA14 ++ " "
afrechudo5 _ = False

bodegaBolaCalalo97 :: Joda -> String
bodegaBolaCalalo97 (TreintaCantar _ (Regalado _ id)) =
  drop (length faneChabonA14 + 1) id

carbura94 :: Gu
carbura94 = "Mónada"

tintachoChupe :: Gu
tintachoChupe = ">>="

lastreAlfiler53 :: Gu
lastreAlfiler53 = "fija"

engraneMiron4 :: Gu
engraneMiron4 = "crepar"

telefunken1 :: Gu
telefunken1 = "Digital"

tracaladaBombo :: Gu
tracaladaBombo = "levantar_dígitos"

empaquetado7 :: Gu
empaquetado7 = "digitalizar"

afanar683 :: Int -> Gu
afanar683 l = "Tupla" ++ show l

rafaMamadero9 :: Gu
rafaMamadero9 = "Ref"

amuebladaRefilar :: Gu
amuebladaRefilar = "Ref"

tintachoTruaCalo42 :: Gu
tintachoTruaCalo42 = "desref"

loraFuncarSalirLa77 :: Gu
loraFuncarSalirLa77 = "asignar"

balconearLacra6 :: Gu
balconearLacra6 = "igual_ref"

diqueoFusilado39 :: Gu
diqueoFusilado39 = "Cont"

cagarseMufarseChantar9 :: Gu
cagarseMufarseChantar9 = "ccc"

postaLaAbricolaOlfa33 :: Gu
postaLaAbricolaOlfa33 = "invocar"

babosoRama577 :: Gu
babosoRama577 = "sumar_numerito"

embetunarChe8 :: Gu
embetunarChe8 = "restar_numerito"

embolsicar13 :: Gu
embolsicar13 = "igual_numerito"

fatoFanfa036 :: Gu
fatoFanfa036 = "menor_o_igual_numerito"

lanceAmurado9 :: Gu
lanceAmurado9 = "multiplicar_numerito"

lentazoCalle5 :: Gu
lentazoCalle5 = "dividir_numerito"

baileDiego769 :: Gu
baileDiego769 = "resto_numerito"

mancarChafe6 :: Gu
mancarChafe6 = "distinto_numerito"

fosforera741 :: Gu
fosforera741 = "menor_numerito"

formarVento9 :: Gu
formarVento9 = "mayor_o_igual_numerito"

ortoPapaLa76 :: Gu
ortoPapaLa76 = "mayor_numerito"

barbaroFanarNp63 :: Gu
barbaroFanarNp63 = "mover_izq_numerito"

esgunfiarChaira6 :: Gu
esgunfiarChaira6 = "mover_der_numerito"

bombearJamon4 :: Gu
bombearJamon4 = "o_numerito"

fachatostaAl21 :: Gu
fachatostaAl21 = "y_numerito"

aceitePalmera4 :: Gu
aceitePalmera4 = "xor_numerito"

bocadoZampar57 :: Gu
bocadoZampar57 = "no_numerito"

lofiarZurdo :: Gu
lofiarZurdo = "letra_a_numerito"

agrampar660 :: Gu
agrampar660 = "numerito_a_letra"

entripaoBetun9 :: Gu
entripaoBetun9 = "espichar"

madama93 :: Gu
madama93 = "Lista"

jamarToco59 :: Gu
jamarToco59 = "Vacía"

cogoteJamon9 :: Gu
cogoteJamon9 = ":"

berretin721 :: Gu
berretin721 = "escupir_letra"

caqueroMetido :: Joda -> Joda -> Joda
caqueroMetido z t = (la0 `bajon0` z) `bajon0` t
  where la0 = blanbetaPifiar (Regalado tocadoTano9 envainarFija)

ibmTarroAl :: [Joda] -> Joda
ibmTarroAl jm = foldl bajon0 la0 jm
  where la0 = blanbetaPifiar (Regalado tocadoTano9 (afanar683 (length jm)))

crostaCaron :: Joda
crostaCaron = blanbetaPifiar (Regalado tocadoTano9 resecoLa48)

bisagraLa :: Joda
bisagraLa = blanbetaPifiar (Regalado tocadoTano9 metido03)

ranterio140 :: Joda
ranterio140 = blanbetaPifiar (Regalado tocadoTano9 mulaTimbo8)

tarugo253 :: Joda
tarugo253 = blanbetaPifiar (Regalado tocadoTano9 mufarse9)

untarMina9 :: Joda
untarMina9 = blanbetaPifiar (Regalado tocadoTano9 opiarse23)

zapayero :: String -> Joda
zapayero b = blanbetaPifiar (Regalado tocadoTano9 (petisa3 b))

trepadorTras97 :: Joda -> Joda
trepadorTras97 f =
  bajon0
    (blanbetaPifiar (Regalado tocadoTano9 rafaMamadero9))
    f

calotearRabona138 :: Joda -> Joda
calotearRabona138 f =
  bajon0
    (blanbetaPifiar (Regalado tocadoTano9 diqueoFusilado39))
    f

garuarA47 :: Joda -> Joda
garuarA47 f =
  bajon0
    (blanbetaPifiar (Regalado tocadoTano9 madama93))
    f

jeteador825 :: Joda -> Bool
jeteador825 (Tela3 _ (TreintaCantar _ r) _) =
    r == Regalado tocadoTano9 madama93
jeteador825 _ = False

madrugadoSequia24 :: Joda -> Joda
madrugadoSequia24 (Tela3 _ _ f) = f

esputza993 :: Joda -> Joda
esputza993 f =
  bajon0
    (blanbetaPifiar (Regalado tocadoTano9 barato353))
    f

torta573 :: Gu
torta573 = "programa"

embetunar77 :: [Gu]
embetunar77 = [
    envainarFija,
    resecoLa48,
    metido03,
    mulaTimbo8,
    opiarse23,
    rafaMamadero9,
    diqueoFusilado39,
    mufarse9,
    justiniano61,
    macheteTrava7,
    madama93,
    jamarToco59,
    cogoteJamon9,
    barato353,
    maquinaTilingo76,
    mamaoLora32,
    carbura94,
    tintachoChupe,
    lastreAlfiler53,
    engraneMiron4,
    telefunken1,
    tracaladaBombo,
    empaquetado7
  ]

cachadorToco :: [(Regalado, FlacaLoro2)]
cachadorToco = [

    (k babosoRama577,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k embetunarChe8,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k embolsicar13,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),
    (k fatoFanfa036,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),

    (k lanceAmurado9,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k lentazoCalle5,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k baileDiego769,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),

    (k mancarChafe6,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),
    (k fosforera741,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),
    (k formarVento9,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),
    (k ortoPapaLa76,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron tarugo253)),

    (k barbaroFanarNp63,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k esgunfiarChaira6,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k bombearJamon4,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k fachatostaAl21,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k aceitePalmera4,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (caqueroMetido crostaCaron crostaCaron)),
    (k bocadoZampar57,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron crostaCaron),

    (k lofiarZurdo,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido bisagraLa crostaCaron),
    (k agrampar660,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron bisagraLa),

    (k entripaoBetun9,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido crostaCaron (batimento2 qb)),

    (k cagarseMufarseChantar9,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (caqueroMetido
                       (calotearRabona138 (batimento2 qb))
                       (batimento2 qb))
                   (batimento2 qb)),
    (k postaLaAbricolaOlfa33,
     Funshe0 [qb, av] $ NadadoraBogaDe6 [] $
     caqueroMetido (calotearRabona138 (batimento2 qb))
                   (caqueroMetido
                       (batimento2 qb)
                       (batimento2 av))),

    (k amuebladaRefilar,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (batimento2 qb)
                   (trepadorTras97 (batimento2 qb))),
    (k balconearLacra6,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (trepadorTras97 (batimento2 qb))
                   (caqueroMetido (trepadorTras97 (batimento2 qb))
                                  tarugo253)),
    (k tintachoTruaCalo42,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (trepadorTras97 (batimento2 qb)) (batimento2 qb)),
    (k loraFuncarSalirLa77,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (trepadorTras97 (batimento2 qb))
                   (caqueroMetido (batimento2 qb)
                                  (ibmTarroAl []))),

    (k berretin721,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido bisagraLa (ibmTarroAl [])),

    (k mulaTimbo8,
     Funshe0 [] $ NadadoraBogaDe6 [] $
     caqueroMetido (garuarA47 bisagraLa) ranterio140),
    (k maquinaTilingo76,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido ranterio140 (esputza993 (batimento2 qb))),
    (k mamaoLora32,
     Funshe0 [qb] $ NadadoraBogaDe6 [] $
     caqueroMetido (batimento2 qb) (esputza993 (batimento2 qb)))
  ]
  where
    k  = Regalado tocadoTano9
    qb = -1
    av = -2

purriaAbaragar7 :: Joda -> Bool
purriaAbaragar7 (Tela3 _ (Tela3 _ (TreintaCantar _ r) _) _) =
  r == Regalado tocadoTano9 envainarFija
purriaAbaragar7 _ = False

bolillaTrenzada7 :: Joda -> Joda
bolillaTrenzada7 (Tela3 _ (Tela3 _ _ f) _) = f

bombachaEntubado :: Joda -> Joda
bombachaEntubado (Tela3 _ (Tela3 _ _ _) f) = f

