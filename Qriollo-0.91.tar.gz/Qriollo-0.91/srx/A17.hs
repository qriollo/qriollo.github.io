
module A17(
        Gu,
        SobradoPibe,
        Regalado(..),
        Mersun99(..),
        NaifeMita,
        Buzarda91,
        GuapeandoOpio,
        MestizoUpa6(..),
        Canoa5(..),
        AmarretismoPan2(..),
        EnsartarDesprendido(..),
        CocineroJuntaLimado8(..),
        RevirarseQuilomboBocinaA596(..),
        CreparCotorraCartabon0(..),
        DescuidistaEspiche587(..),
        JirafaGrelaArrebezarse284(..),
        Guarda564(..),
        ChipolaQuemo(..),
        MorderRegalado20(..),
        AbanicarZapayo32(..),
        Shomeria5(..),
        relojeadoAracaNp63,
        creparChina,
        salameIsa0,
    ) where

import Data.Map as Map(Map, lookup)

type Gu = String

type SobradoPibe = [String]

creparChina :: SobradoPibe -> String
creparChina [] = "[]"
creparChina m  = ligar "." m

ligar :: String -> [String] -> String
ligar a32 []   = ""
ligar a32 depa = foldr1 (\ o x -> o ++ a32 ++ x) depa

data Regalado = Regalado SobradoPibe Gu
  deriving (Eq, Ord)

instance Show Regalado where
  show (Regalado bagayo5 id) = ligar "." (bagayo5 ++ [id])

salameIsa0 :: Regalado -> String
salameIsa0 (Regalado _ id) = id

data Mersun99 = Ranero2 Integer
              | Pirar Char
  deriving (Show, Eq, Ord)

type NaifeMita = Regalado

data AmarretismoPan2 z = Funshe0 [Buzarda91] (CocineroJuntaLimado8 z)
  deriving Show

data MestizoUpa6 = TocadoCursi4
                 | Borracheria51
                 | LanguidoBanana
  deriving (Show, Eq, Ord)

data Canoa5 = FaloperoChoto MestizoUpa6 String
  deriving Show

data EnsartarDesprendido z = CapelunGroso53 NaifeMita (Guarda564 z)
  deriving Eq

instance Show (EnsartarDesprendido z) where
  show (CapelunGroso53 al7 isa) = salameIsa0 al7 ++ " para " ++ show isa

data CocineroJuntaLimado8 z =
     NadadoraBogaDe6 [EnsartarDesprendido z] (Guarda564 z)
  deriving Eq

instance Show (CocineroJuntaLimado8 z) where
  show (NadadoraBogaDe6 [] isa) = show isa
  show (NadadoraBogaDe6 [dragonear9] isa) =
    show isa ++ " con " ++ show dragonear9
  show (NadadoraBogaDe6 ranteriaDe7 isa) =
    show isa ++ " con (" ++ ligar ", " (map show ranteriaDe7) ++ ")"

data RevirarseQuilomboBocinaA596 z =
     AchumarseYurnoTurroLa0 Regalado [Guarda564 z]
  deriving (Show, Eq)

data DescuidistaEspiche587 z =
     PintarTrincarA41 Regalado (Guarda564 z)
  deriving (Show, Eq)

data CreparCotorraCartabon0 z =
     PoligriyoMatonear Regalado (CocineroJuntaLimado8 z)
  deriving (Show, Eq)

data JirafaGrelaArrebezarse284 z =
     FumistaGaruarRaviol9 Regalado (Shomeria5 z)
  deriving (Show, Eq)

data AbanicarZapayo32 z =
      Chuchi3    z Regalado (Maybe (CocineroJuntaLimado8 z)) (Shomeria5 z)
    | Funyi1     z Regalado [Regalado] (Guarda564 z)
    | CraneoMusa z Regalado
                   [Regalado]
                   [RevirarseQuilomboBocinaA596 z]
    | VoviPro    z NaifeMita
                   Regalado
                   [CreparCotorraCartabon0 z]
    | BirraViste z NaifeMita
                   (CocineroJuntaLimado8 z)
                   [JirafaGrelaArrebezarse284 z]
    | Pavadas77 z MestizoUpa6
                  String
                  Regalado
                  (Guarda564 z)
  deriving (Show, Eq)

data MorderRegalado20 z = CasaJeton55 (ChipolaQuemo z) (Shomeria5 z)
  deriving (Show, Eq)

type GuapeandoOpio = Integer

data Shomeria5 z = Mopio         z Regalado
                 | MateMalcoOpa1 z Regalado
                 | FlacaJodon    z Mersun99
                 | Copo5         z Regalado (Shomeria5 z)
                 | Mina0         z (Shomeria5 z) (Shomeria5 z)
                 | Tocar         z [AbanicarZapayo32 z] (Shomeria5 z)
                 | Abanico       z (Shomeria5 z) [MorderRegalado20 z]
                 | Cortina       z [Shomeria5 z]
                 | AcamalaCheDe4 z GuapeandoOpio
    deriving (Show, Eq)

data ChipolaQuemo z = Cuete         z Regalado
                    | ExcomunicaA68 z Regalado [ChipolaQuemo z]
                    | CortadoLa9    z Mersun99
                    | Mufa2         z
                    | Secar87       z [ChipolaQuemo z]
  deriving (Show, Eq)

type Buzarda91 = Integer

data Guarda564 z = Pacoy         z Regalado
                 | TreintaCantar z Regalado
                 | Tela3         z (Guarda564 z) (Guarda564 z)
                 | Malanfio0     z Buzarda91
  deriving Eq

instance Show (Guarda564 z) where
  show (Pacoy _ (Regalado _ id))         = id
  show (TreintaCantar _ (Regalado ["PRIM"] "Tupla0")) = "()"
  show (TreintaCantar _ (Regalado _ id)) = id
  show f@(Tela3 _ _ _)
    | caloRaja71 ow pv =
      let [hb, rk] = pv in
        cola1 hb ++ " en " ++ show rk
    | junar66 ow pv && length pv == 1 =
      show (head pv)
    | junar66 ow pv =
      "(" ++ ligar ", " (map show pv) ++ ")"
    | grasa9 ow pv =
      let [z] = pv in
        "[" ++ show z ++ "]"
    | otherwise =
      show (ragu1 f) ++ " de " ++ ligar " " (map cola1 (humo2 f))
    where
      ow = ragu1 f
      pv = humo2 f
      ragu1 (Tela3 _ f _)   = ragu1 f
      ragu1 f               = f
      humo2 (Tela3 _ av wx) = humo2 av ++ [wx]
      humo2 f               = []

      cola1 f@(Tela3 _ _ _)
        | junar66 (ragu1 f) (humo2 f) = show f
        | grasa9 (ragu1 f) (humo2 f)  = show f
        | otherwise                   = "(" ++ show f ++ ")"
      cola1 f               = show f

      caloRaja71 (TreintaCantar _ (Regalado ["PRIM"] "Función")) [_, _] = True
      caloRaja71 _ _ = False

      junar66 (TreintaCantar _ (Regalado ["PRIM"] la0)) mino =
        la0 == "Tupla" ++ show (length mino)
      junar66 _ _ = False

      grasa9 (TreintaCantar _ (Regalado ["PRIM"] "Lista")) [_] = True
      grasa9 _ _ = False

  show (Malanfio0 _ d)      = "?" ++ show d

instance Functor AmarretismoPan2 where
  fmap j (Funshe0 nz f) = Funshe0 nz (fmap j f)

instance Functor EnsartarDesprendido where
  fmap j (CapelunGroso53 al7 f) = CapelunGroso53 al7 (fmap j f)

instance Functor CocineroJuntaLimado8 where
  fmap j (NadadoraBogaDe6 uh f) = NadadoraBogaDe6 (map (fmap j) uh) (fmap j f)

instance Functor RevirarseQuilomboBocinaA596 where
  fmap j (AchumarseYurnoTurroLa0 pedo3 jm) =
   AchumarseYurnoTurroLa0 pedo3 (map (fmap j) jm)

instance Functor CreparCotorraCartabon0 where
  fmap j (PoligriyoMatonear pedo3 f) = PoligriyoMatonear pedo3 (fmap j f)

instance Functor JirafaGrelaArrebezarse284 where
  fmap j (FumistaGaruarRaviol9 pedo3 gula) =
   FumistaGaruarRaviol9 pedo3 (fmap j gula)

instance Functor AbanicarZapayo32 where
  fmap j (Chuchi3 ave pedo3 gula0 gula)   =
         Chuchi3    (j ave) pedo3 (fmap (fmap j) gula0) (fmap j gula)
  fmap j (Funyi1 ave pedo3 a29 f)         =
         Funyi1     (j ave) pedo3 a29 (fmap j f)
  fmap j (CraneoMusa ave pedo3 a29 la42)  =
         CraneoMusa (j ave) pedo3 a29 (map (fmap j) la42)
  fmap j (VoviPro ave al7 pedo3 faso2)    =
         VoviPro    (j ave) al7 pedo3 (map (fmap j) faso2)
  fmap j (BirraViste ave al7 f faso2)     =
         BirraViste (j ave) al7 (fmap j f) (map (fmap j) faso2)
  fmap j (Pavadas77 ave qu sq pedo3 isa)  =
         Pavadas77 (j ave) qu sq pedo3 (fmap j isa)

instance Functor MorderRegalado20 where
  fmap j (CasaJeton55 al9 ymp) = CasaJeton55 (fmap j al9) (fmap j ymp)

instance Functor Shomeria5 where
  fmap j (Mopio         ave pedo3)        =
         Mopio         (j ave) pedo3
  fmap j (MateMalcoOpa1 ave pedo3)        =
         MateMalcoOpa1 (j ave) pedo3
  fmap j (FlacaJodon    ave const)        =
         FlacaJodon    (j ave) const
  fmap j (Copo5         ave pedo3 ymp)    =
         Copo5         (j ave) pedo3 (fmap j ymp)
  fmap j (Mina0         ave gp oy)        =
         Mina0         (j ave) (fmap j gp) (fmap j oy)
  fmap j (Tocar         ave amuro ymp)    =
         Tocar         (j ave) (map (fmap j) amuro) (fmap j ymp)
  fmap j (Abanico       ave ymp lastrar5) =
         Abanico       (j ave) (fmap j ymp) (map (fmap j) lastrar5)
  fmap j (Cortina       ave soga)         =
         Cortina       (j ave) (map (fmap j) soga)
  fmap j (AcamalaCheDe4 ave m)            =
         AcamalaCheDe4 (j ave) m

instance Functor ChipolaQuemo where
  fmap j (Cuete         ave pedo3)        =
         Cuete         (j ave) pedo3
  fmap j (ExcomunicaA68 ave pedo3 seco)   =
         ExcomunicaA68 (j ave) pedo3 (map (fmap j) seco)
  fmap j (CortadoLa9    ave const)        =
         CortadoLa9    (j ave) const
  fmap j (Mufa2         ave)              =
         Mufa2         (j ave)
  fmap j (Secar87       ave seco)         =
         Secar87       (j ave) (map (fmap j) seco)

instance Functor Guarda564 where
  fmap j (Pacoy         ave pedo3)        =
         Pacoy         (j ave) pedo3
  fmap j (TreintaCantar ave pedo3)        =
         TreintaCantar (j ave) pedo3
  fmap j (Tela3         ave av wx)        =
         Tela3         (j ave) (fmap j av) (fmap j wx)
  fmap j (Malanfio0     ave h)            =
         Malanfio0     (j ave) h

class Maquina458 j where
  relojeadoAracaNp63 :: Map GuapeandoOpio (Shomeria5 estarado14) ->
                        j estarado14 -> j estarado14

instance Maquina458 JirafaGrelaArrebezarse284 where
  relojeadoAracaNp63 culo (FumistaGaruarRaviol9 pedo3 gula) =
    FumistaGaruarRaviol9 pedo3 (relojeadoAracaNp63 culo gula)

instance Maquina458 AbanicarZapayo32 where
  relojeadoAracaNp63 culo (Chuchi3 ave pedo3 gula0 gula)    =
         Chuchi3    ave pedo3 gula0
                    (relojeadoAracaNp63 culo gula)
  relojeadoAracaNp63 culo (Funyi1 ave pedo3 a29 f)          =
         Funyi1     ave pedo3 a29 f
  relojeadoAracaNp63 culo (CraneoMusa ave pedo3 a29 la42)   =
         CraneoMusa ave pedo3 a29 la42
  relojeadoAracaNp63 culo (VoviPro ave al7 pedo3 zarzoRua1) =
         VoviPro    ave al7 pedo3 zarzoRua1
  relojeadoAracaNp63 culo (BirraViste ave al7 f lapicero1)  =
         BirraViste ave al7 f (map (relojeadoAracaNp63 culo) lapicero1)
  relojeadoAracaNp63 culo (Pavadas77 ave qu sq pedo3 isa)   =
         Pavadas77 ave qu sq pedo3 isa

instance Maquina458 MorderRegalado20 where
  relojeadoAracaNp63 culo (CasaJeton55 al9 ymp) =
    CasaJeton55 al9
                (relojeadoAracaNp63 culo ymp)

instance Maquina458 Shomeria5 where
  relojeadoAracaNp63 culo (Mopio         ave pedo3)        =
         Mopio         ave pedo3
  relojeadoAracaNp63 culo (MateMalcoOpa1 ave pedo3)        =
         MateMalcoOpa1 ave pedo3
  relojeadoAracaNp63 culo (FlacaJodon    ave const)        =
         FlacaJodon    ave const
  relojeadoAracaNp63 culo (Copo5         ave pedo3 ymp)    =
         Copo5         ave pedo3 (relojeadoAracaNp63 culo ymp)
  relojeadoAracaNp63 culo (Mina0         ave gp oy)        =
         Mina0         ave (relojeadoAracaNp63 culo gp)
                           (relojeadoAracaNp63 culo oy)
  relojeadoAracaNp63 culo (Tocar         ave amuro ymp)    =
         Tocar         ave (map (relojeadoAracaNp63 culo) amuro)
                           (relojeadoAracaNp63 culo ymp)
  relojeadoAracaNp63 culo (Abanico       ave ymp lastrar5) =
         Abanico       ave (relojeadoAracaNp63 culo ymp)
                           (map (relojeadoAracaNp63 culo) lastrar5)
  relojeadoAracaNp63 culo (Cortina       ave soga)         =
         Cortina       ave (map (relojeadoAracaNp63 culo) soga)
  relojeadoAracaNp63 culo (AcamalaCheDe4 ave m)            =
         case Map.lookup m culo of
           Nothing  -> AcamalaCheDe4 ave m
           Just ymp -> relojeadoAracaNp63 culo ymp

