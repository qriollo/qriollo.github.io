
module Careta82(betun857) where

import Control.Monad.Trans.State.Lazy(State, get, modify, runState)
import qualified Data.Map as Map(Map, empty, insert, lookup)
import Control.Applicative((<$>))

import FiruloGuay3

data GarronCocina0 = GarronCocina0 {
                       nuriaVia74 :: Integer,
                       bombear1 :: Map.Map ([La4], Liga2) La4,
                       biografoZafar03 :: Map.Map La4 La4
                     }
type TaitaAl38 = State GarronCocina0

betun857 :: Liga2 -> Liga2
betun857 gula = encajarTarugo218 gula
  where
    encajarTarugo218 :: Liga2 -> Liga2
    encajarTarugo218 gula = do
      let (liso8, nasun) = runState (pilladoPan59 gula) bochoMufarse
       in
         if nuriaVia74 nasun == 0
          then gula
          else encajarTarugo218 liso8

    bochoMufarse :: GarronCocina0
    bochoMufarse = GarronCocina0 {
                     nuriaVia74 = 0,
                     bombear1 = Map.empty,
                     biografoZafar03 = Map.empty
                   }

    pilladoPan59 :: Liga2 -> TaitaAl38 Liga2
    pilladoPan59 (Manu amuro gula) = do
      alce76  <- despiolado925 amuro
      grua441 <- mapM tungoPajero152 alce76
      liso8   <- boleadoBuque2 gula
      return $ Manu grua441 liso8
    pilladoPan59 gula = return gula

    despiolado925 :: [TocadoTras10] -> TaitaAl38 [TocadoTras10]
    despiolado925 amuro = do
      serruchar <- mapM viniyoAraca8 amuro
      return $ concat serruchar

    de371 :: TaitaAl38 ()
    de371 = modify (\ nasun -> nasun {
              nuriaVia74 = nuriaVia74 nasun + 1
            })

    viniyoAraca8 :: TocadoTras10 -> TaitaAl38 [TocadoTras10]
    viniyoAraca8 pego@(Zarzo79 id mino gula) = do
      nasun <- get
      case Map.lookup (mino, gula) (bombear1 nasun) of
        Just mvz -> do
          de371
          modify (\ nasun -> nasun {
            biografoZafar03 = Map.insert
                                id
                                mvz
                                (biografoZafar03 nasun)
          })
          return []
        Nothing -> do
          modify (\ nasun -> nasun {
            bombear1 = Map.insert (mino, gula) id (bombear1 nasun)
          })
          return [pego]

    boleadoBuque2 :: Liga2 -> TaitaAl38 Liga2
    boleadoBuque2 (Cuete45 fifi id gula) = do
      rua79 <- mapM reaBocadoAlca8 fifi
      Cuete45 rua79 id <$> boleadoBuque2 gula
    boleadoBuque2 (Guarda4 l a49 id gula) = do
      via7 <- reaBocadoAlca8 a49
      Guarda4 l via7 id <$> boleadoBuque2 gula
    boleadoBuque2 (Reo7 a49 fifi) = do
      via7  <- reaBocadoAlca8 a49
      rua79 <- mapM reaBocadoAlca8 fifi
      return $ Reo7 via7 rua79
    boleadoBuque2 (Manu _ _) =
      error "(compress: no debería encontrar un LetK)"
    boleadoBuque2 (Patova8 a49 gamba) = do
      via7 <- reaBocadoAlca8 a49
      Patova8 via7 <$> mapM boleadoBuque2 gamba
    boleadoBuque2 (Marinante1 m fifi a29 gamba) = do
      rua79 <- mapM reaBocadoAlca8 fifi
      Marinante1 m rua79 a29 <$> mapM boleadoBuque2 gamba
    boleadoBuque2 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM reaBocadoAlca8 fifi
      ChivoA70 a13 rua79 id <$> boleadoBuque2 gula

    reaBocadoAlca8 :: Bacan8 -> TaitaAl38 Bacan8
    reaBocadoAlca8 (Pingo7 id) = do
      nasun <- get
      case Map.lookup id (biografoZafar03 nasun) of
        Just mvz -> return $ Pingo7 mvz
        Nothing  -> return $ Pingo7 id
    reaBocadoAlca8 a49 = return a49

    tungoPajero152 :: TocadoTras10 -> TaitaAl38 TocadoTras10
    tungoPajero152 (Zarzo79 id mino gula) =
      Zarzo79 id mino <$> boleadoBuque2 gula

