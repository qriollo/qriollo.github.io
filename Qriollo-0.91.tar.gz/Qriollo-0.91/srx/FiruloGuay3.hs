
module FiruloGuay3(
        La4, Bacan8(..), TocadoTras10(..), Liga2(..), pro1,
        onda49,
    ) where

import Data.Char(ord)

import Chanceleta1
import ReventarLa9

type La4 = Integer

data Bacan8 =
    Naso      La4
  | RayadoAl1 Mersun99
  | Pingo7    La4

  | Opa0      Integer La4

  deriving (Show, Eq, Ord)

data TocadoTras10 = Zarzo79 La4 [La4] Liga2
  deriving (Show, Eq, Ord)

data Liga2 = Cuete45    [Bacan8] La4 Liga2
           | Guarda4    Integer Bacan8 La4 Liga2
           | Reo7       Bacan8 [Bacan8]
           | Manu       [TocadoTras10] Liga2
           | Patova8    Bacan8 [Liga2]
           | Marinante1 Mosca1 [Bacan8] [La4] [Liga2]
           | ChivoA70   RelacheInfante53 [Bacan8] La4 Liga2
  deriving (Eq, Ord)

instance Show Liga2 where
  show = cocinarA18

pro1 :: Bacan8 -> Liga2
pro1 h = Reo7 (Naso (-1)) [h]

onda49 :: Liga2 -> [La4]
onda49 (Cuete45 fifi id gula) =
  concatMap fanar49 fifi ++ [id] ++ onda49 gula
onda49 (Guarda4 _ a49 id gula) = fanar49 a49 ++ [id] ++ onda49 gula
onda49 (Reo7 a49 fifi) = fanar49 a49 ++ concatMap fanar49 fifi
onda49 (Manu amuro gula) = concatMap naifa32 amuro ++ onda49 gula
  where
    naifa32 :: TocadoTras10 -> [La4]
    naifa32 (Zarzo79 j mino gula) = j : mino ++ onda49 gula
onda49 (Patova8 a49 gamba) = fanar49 a49 ++ concatMap onda49 gamba
onda49 (Marinante1 _ fifi a29 gamba) =
  concatMap fanar49 fifi ++ a29 ++ concatMap onda49 gamba
onda49 (ChivoA70 _ fifi id gula) =
  concatMap fanar49 fifi ++ [id] ++ onda49 gula

fanar49 :: Bacan8 -> [La4]
fanar49 (Naso id)   = [id]
fanar49 (Pingo7 id) = [id]
fanar49 (Opa0 _ id) = [id]
fanar49 _           = []

cocinarA18 :: Liga2 -> String
cocinarA18 gula = truaA80 gula
  where
    truaA80 :: Liga2 -> String
    truaA80 (Cuete45 fifi id gula) =
      camote id ++ " := [" ++ ligar ", " (map miti1 fifi) ++ "];\n" ++
      truaA80 gula
    truaA80 (Guarda4 l a49 id gula) =
      camote id ++ " := " ++ miti1 a49 ++ "[" ++ show l ++ "];\n" ++
      truaA80 gula
    truaA80 (Reo7 a49 fifi) =
      miti1 a49 ++ "(" ++ ligar ", " (map miti1 fifi) ++ ");\n"
    truaA80 (Manu amuro gula) =
      ligar "\n" (map arreglo9 amuro) ++ "\n" ++
      "Main() {\n" ++
      briyo6 (truaA80 gula) ++
      "}\n"
    truaA80 (Patova8 a49 gamba) =
      "switch " ++ miti1 a49 ++ " {\n" ++
      ligar "\n" (zipWith dedoVersero81 [0..] gamba) ++
      "}\n"
    truaA80 (Marinante1 m fifi [] [gula]) =
      show m ++ "(" ++ ligar ", " (map miti1 fifi) ++ ");\n" ++
      truaA80 gula
    truaA80 (Marinante1 m fifi [id] [gula]) =
      camote id ++ " := " ++ show m ++
      "(" ++ ligar ", " (map miti1 fifi) ++ ");\n" ++
      truaA80 gula
    truaA80 (Marinante1 m fifi [] [guila, corno]) =
      show m ++ "(" ++ ligar ", " (map miti1 fifi) ++ ") {\n" ++
      briyo6 (truaA80 guila) ++
      "} {\n" ++
      briyo6 (truaA80 corno) ++
      "}\n"
    truaA80 (ChivoA70 a13 fifi id gula) =
      camote id ++ " := foreign {" ++ show a13 ++ "}" ++
      "(" ++ ligar ", " (map miti1 fifi) ++ ");\n" ++
      truaA80 gula

    briyo6 :: String -> String
    briyo6 ws = ligar "\n" (map ("  " ++) (lines ws)) ++ "\n"

    dedoVersero81 :: Integer -> Liga2 -> String
    dedoVersero81 l gula =
      show l ++ ":\n" ++ briyo6 (truaA80 gula)

    arreglo9 :: TocadoTras10 -> String
    arreglo9 (Zarzo79 o ws capo) =
      sobreTaba o ++ "(" ++ ligar ", " (map camote ws) ++ ") {\n" ++
      briyo6 (truaA80 capo) ++
      "}\n"

    camote :: La4 -> String
    camote o = "r" ++ show o

    sobreTaba :: La4 -> String
    sobreTaba (-1) = "Return"
    sobreTaba o    = "L" ++ show o

    miti1 :: Bacan8 -> String
    miti1 (Naso o)                = camote o
    miti1 (RayadoAl1 (Ranero2 l)) = show l
    miti1 (RayadoAl1 (Pirar r))   = show (ord r)
    miti1 (Pingo7 o)              = sobreTaba o
    miti1 (Opa0 w o)              = camote o ++ "[" ++ show w ++ "]"

    ligar :: String -> [String] -> String
    ligar a32 []   = ""
    ligar a32 depa = foldr1 (\ o x -> o ++ a32 ++ x) depa

