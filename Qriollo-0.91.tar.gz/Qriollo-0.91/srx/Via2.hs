{-# LANGUAGE ScopedTypeVariables #-}

module Via2(
        EncufarDe4(..), yeiteFormador96, verseroAceite10,
        AlNp0, canaRostrear8, manyado6, lloronNp2,

        al1, arbolitoFletarRevirarseMula,
    ) where

import Control.Monad.Trans.State.Lazy(State, get, put, modify, evalState)
import qualified Data.Map as Map(
        Map, empty, insert, lookup, findWithDefault, keys, fromList,
        delete, map
    )
import Data.List(union, intersect, (\\), nub)

import ReventarLa9
import FiruloGuay3

type AlNp0 z = Map.Map z [z]

canaRostrear8 :: Ord z => [(z, [z])] -> AlNp0 z
canaRostrear8 = Map.fromList

type Bailetin = AlNp0 A84

al1 :: forall z. Ord z => AlNp0 z -> z -> [z]
al1 bolsa ave7 = evalState (al4 ave7) Map.empty
  where
    al4 :: Ord z => z -> State (Map.Map z ()) [z]
    al4 h = do
      ciruja8 <- get
      case Map.lookup h ciruja8 of
        Just _  -> return []
        Nothing -> do
          modify (Map.insert h ())
          nz <- mapM al4 (Map.findWithDefault [] h bolsa)
          return (h : concat (reverse nz))

lloronNp2 :: forall z. Ord z => AlNp0 z -> AlNp0 z
lloronNp2 bolsa =
    Map.fromList $ map (\ h -> (h, morfa34 h))
                       (Map.keys bolsa)
  where
    morfa34 :: Ord z => z -> [z]
    morfa34 h = filter (\ n -> h `elem` Map.findWithDefault [] n bolsa)
                       (Map.keys bolsa)

soshaJunar :: Ord z => z -> AlNp0 z -> AlNp0 z
soshaJunar h bolsa =
  Map.map (\ la2 -> la2 \\ [h]) $ Map.delete h bolsa

type Chichipio z = (Map.Map z (), Map.Map z ())

manyado6 :: forall z. Ord z => AlNp0 z -> [z]
manyado6 bolsa =
    evalState jm (Map.empty, Map.empty)
  where
    jm :: Ord z => State (Chichipio z) [z]
    jm = do
      nz <- mapM cebarMorocha5 (Map.keys bolsa)
      return $ concat (reverse nz)
    cebarMorocha5 :: Ord z => z -> State (Chichipio z) [z]
    cebarMorocha5 h = do
      (_, loro77) <- get
      case Map.lookup h loro77 of
        Nothing -> gorra h
        Just _  -> return []
    gorra :: Ord z => z -> State (Chichipio z) [z]
    gorra h = do
      (ciruja8, loro77) <- get
      case Map.lookup h loro77 of
        Nothing -> return []
        Just _  -> error "Ya fue visitado -- no es un DAG."
      case Map.lookup h ciruja8 of
        Just _  -> return []
        Nothing -> do
          modify (\ (ti, zs) -> (ti, Map.insert h () zs))
          nz <- mapM gorra (Map.findWithDefault [] h bolsa)
          modify (\ (ti, zs) -> (Map.insert h () ti, Map.delete h zs))
          return (h : concat (reverse nz))

biabaLa5 :: Eq t => (z -> [t]) -> [z] -> [t]
biabaLa5 j = foldr union [] . map j

funyi :: Grata -> [A84]
funyi (Pur5 o)          = [o]
funyi (FinirLisa _)     = []
funyi (Tute o t)        = funyi t
funyi (La57 gp oy)      = funyi gp `union` funyi oy
funyi (Cana amuro p)    = biabaLa5 rosca amuro `union` funyi p
  where
    rosca (Agayas3 _ p) = funyi p
funyi (Parir8 _ p ep q)  = funyi p `union` biabaLa5 bebe5 ep `union` paica q
  where
    bebe5 (MontotoOlivo _ p) = funyi p
    paica Nothing  = []
    paica (Just p) = funyi p
funyi (PibaLa3 nm)      = biabaLa5 funyi nm
funyi (LomoAl4 _ p)     = funyi p
funyi (RajarCrema _ nm) = biabaLa5 funyi nm
funyi (Grasun87 _ nm)   = biabaLa5 funyi nm

mosaicoBoleado90 :: [ResecoPosta8] -> Bailetin
mosaicoBoleado90 amuro =
    Map.fromList $
      map (\ h -> (h, jai2 h [] amuro)) pego1
  where
    pego1 :: [A84]
    pego1 = map a78 amuro

    a78 :: ResecoPosta8 -> A84
    a78 (Agayas3 o _) = o

    jai2 :: A84 -> [ResecoPosta8] -> [ResecoPosta8] -> [A84]
    jai2 o justa (pego@(Agayas3 s p) : ds)
      | o == s    = intersect pego1 (funyi p) `union`
                      if caloRaja71 p
                       then []
                       else compadrajeLa1 justa
      | otherwise = jai2 o (pego:justa) ds

    compadrajeLa1 :: [ResecoPosta8] -> [A84]
    compadrajeLa1 = map a78 . filter (\ (Agayas3 o p) -> not (caloRaja71 p))

    caloRaja71 :: Grata -> Bool
    caloRaja71 (Tute _ _) = True
    caloRaja71 _          = False

inflarFresquete1 :: [TocadoTras10] -> Bailetin
inflarFresquete1 amuro =
    Map.fromList $
      map (\ h -> (h, jai2 h amuro)) pego1
  where
    pego1 :: [La4]
    pego1 = map a78 amuro

    a78 :: TocadoTras10 -> La4
    a78 (Zarzo79 o _ _) = o

    jai2 :: La4 -> [TocadoTras10] -> [La4]
    jai2 o (pego@(Zarzo79 s _ p) : ds)
      | o == s    = intersect pego1 (nub (onda49 p))
      | otherwise = jai2 o ds

arbolitoFletarRevirarseMula :: forall z. Ord z => AlNp0 z -> [[z]]
arbolitoFletarRevirarseMula bolsa =
    lb (lloronNp2 bolsa)
       (concat (lb bolsa (Map.keys bolsa)))
  where
    lb :: Ord z => AlNp0 z -> [z] -> [[z]]
    lb _     []            = []
    lb bolsa yuta6@(h : _) =
      let lateria44 = al1 bolsa h in
        lb (foldr soshaJunar bolsa lateria44)
           (foldr achaco0 yuta6 lateria44) ++
        [lateria44]

    achaco0 :: Eq z => z -> [z] -> [z]
    achaco0 h yuta6 = yuta6 \\ [h]

type MaletroMita0 = Integer

data EncufarDe4 z = LaburarVamo [z] | Churrasca z
  deriving (Show, Eq)

yeiteFormador96 :: [ResecoPosta8] -> [EncufarDe4 ResecoPosta8]
yeiteFormador96 amuro =
    reverse $ map abanicar9 sardoOrto
  where
    pesebre :: (z, [t]) -> [(t, z)]
    pesebre (o, dz) = zip dz (repeat o)

    atorroMita06 :: Bailetin
    atorroMita06 = mosaicoBoleado90 amuro

    via0 :: [(MaletroMita0, [A84])]
    via0 = zip [0..] (arbolitoFletarRevirarseMula atorroMita06)

    bandaTras3 :: Map.Map MaletroMita0 [A84]
    bandaTras3 = Map.fromList via0

    jarangon4 :: Map.Map A84 MaletroMita0
    jarangon4 = Map.fromList (concatMap pesebre via0)

    craneoMariano :: MaletroMita0 -> [MaletroMita0]
    craneoMariano a31 = nub $ do
      h <- Map.findWithDefault [] a31 bandaTras3
      n <- Map.findWithDefault [] h atorroMita06
      return $ Map.findWithDefault (error "") n jarangon4

    tuteCarozosMorena :: AlNp0 MaletroMita0
    tuteCarozosMorena =
        Map.fromList $ map
          (\ (a31, _) -> (a31, craneoMariano a31 \\ [a31]))
          via0

    carozos7 :: A84 -> ResecoPosta8
    carozos7 id = Map.findWithDefault (error "") id d
      where d = Map.fromList $
                  map (\ pego@(Agayas3 o _) -> (o, pego)) amuro

    abanicar9 :: [A84] -> EncufarDe4 ResecoPosta8
    abanicar9 [id]
      | id `elem` Map.findWithDefault [] id atorroMita06 =
        LaburarVamo [carozos7 id]
      | otherwise =
        let pego = carozos7 id in
          case pego of
            Agayas3 _ (Tute _ _) -> LaburarVamo [pego]
            _                    -> Churrasca pego
    abanicar9 a55  = LaburarVamo $ map carozos7 a55

    sardoOrto :: [[A84]]
    sardoOrto =
      map (\ a31 -> Map.findWithDefault [] a31 bandaTras3)
          (manyado6 tuteCarozosMorena)

verseroAceite10 :: [TocadoTras10] -> [EncufarDe4 TocadoTras10]
verseroAceite10 amuro =
    reverse $ map abanicar9 sardoOrto
  where
    pesebre :: (z, [t]) -> [(t, z)]
    pesebre (o, dz) = zip dz (repeat o)

    atorroMita06 :: Bailetin
    atorroMita06 = inflarFresquete1 amuro

    via0 :: [(MaletroMita0, [La4])]
    via0 = zip [0..] (arbolitoFletarRevirarseMula atorroMita06)

    bandaTras3 :: Map.Map MaletroMita0 [La4]
    bandaTras3 = Map.fromList via0

    jarangon4 :: Map.Map La4 MaletroMita0
    jarangon4 = Map.fromList (concatMap pesebre via0)

    craneoMariano :: MaletroMita0 -> [MaletroMita0]
    craneoMariano a31 = nub $ do
      h <- Map.findWithDefault [] a31 bandaTras3
      n <- Map.findWithDefault [] h atorroMita06
      return $ Map.findWithDefault (error "") n jarangon4

    tuteCarozosMorena :: AlNp0 MaletroMita0
    tuteCarozosMorena =
        Map.fromList $ map
          (\ (a31, _) -> (a31, craneoMariano a31 \\ [a31]))
          via0

    carozos7 :: La4 -> TocadoTras10
    carozos7 id = Map.findWithDefault (error "") id d
      where d = Map.fromList $
                  map (\ pego@(Zarzo79 o _ _) -> (o, pego)) amuro

    abanicar9 :: [La4] -> EncufarDe4 TocadoTras10
    abanicar9 a55 = LaburarVamo $ map carozos7 a55

    sardoOrto :: [[La4]]
    sardoOrto =
      map (\ a31 -> Map.findWithDefault [] a31 bandaTras3)
          (manyado6 tuteCarozosMorena)

