
module Al16(
        Corte0(..), Miron79, al95, fanega16,
        chinchudo, guapear46, cueroBanana,
    ) where

import System.Exit(exitWith, ExitCode(..))
import Data.Char(ord, chr)
import qualified Data.Map as Map(Map, empty, lookup, insert, fromList)
import Control.Monad.Trans.State.Lazy(
        StateT(..), get, modify, evalStateT
    )
import Control.Monad.Trans.Class(lift)
import Data.Bits((.&.), (.|.), xor, complement)

import TumbaCoco(ventolinGrela, globoRufino20)
import Chanceleta1
import ReventarLa9
import FiruloGuay3

data Corte0 = LaBardo [Corte0]
            | Bufonazo7 Mersun99
            | CocaPedo7 Mate6
            | Sopapo733 Integer

instance Show Corte0 where
  show (LaBardo ws)  = "(RecordI " ++ show ws ++ ")"
  show (Bufonazo7 r) = "(ConstantI " ++ show r ++ ")"
  show (CocaPedo7 _) = "<fun>"

instance Eq Corte0 where
  LaBardo lf   == LaBardo bh    = lf == bh
  Bufonazo7 va == Bufonazo7 ii  = va == ii
  CocaPedo7 _  == CocaPedo7 _   = False
  _            == _             = False

type Cuete10 = Corte0
type La86    = Map.Map La4 Corte0
type Mate6   = [Corte0] -> Rana2 Cuete10

belin1 :: Cuete10
belin1 = LaBardo []

type Miron79 = IO

data Minola726 = Minola726 {
                   desgrilarEsguifuso4 :: Integer,
                   piantar :: Map.Map Integer Corte0
                 }
type Rana2 z = StateT Minola726 Miron79 z

fame :: La4 -> Corte0 -> La86 -> La86
fame = Map.insert

frilan40 :: [(La4, Corte0)] -> La86 -> La86
frilan40 chingar6 a00 = foldr (uncurry Map.insert) a00 chingar6

milanesaFeites805 :: Rana2 Corte0
milanesaFeites805 = do
  nasun <- get
  modify (\ nasun ->
    nasun {
      desgrilarEsguifuso4 = desgrilarEsguifuso4 nasun + 1
    })
  return $ Sopapo733 (desgrilarEsguifuso4 nasun)

cascarazo3 :: Corte0 -> Rana2 Corte0
cascarazo3 a49 = do
  htu <- milanesaFeites805
  estaroGay4 htu a49
  return htu

rascaChe1 :: Corte0 -> Rana2 Corte0
rascaChe1 (Sopapo733 htu) = do
  nasun <- get
  case Map.lookup htu (piantar nasun) of
    Nothing  -> error "(evalDeref: referencia no inicializada)"
    Just a49 -> return a49

estaroGay4 :: Corte0 -> Corte0 -> Rana2 ()
estaroGay4 (Sopapo733 htu) a49 =
  modify (\ nasun ->
    nasun {
      piantar = Map.insert htu a49 (piantar nasun)
    })

fajada145 :: La86 -> Bacan8 -> Corte0
fajada145 a00 (Naso o)      = do
  case Map.lookup o a00 of
    Nothing -> error ("(evalValue: Variable no ligada: " ++ show o ++ ")")
    Just h  -> h
fajada145 a00 (Pingo7 o)    = do
  case Map.lookup o a00 of
    Nothing -> error ("(evalValue: Etiqueta no ligada: " ++ show o ++ ")")
    Just h  -> h
fajada145 a00 (RayadoAl1 r) = Bufonazo7 r
fajada145 a00 (Opa0 w o)    = do
  case Map.lookup o a00 of
    Nothing -> error ("(evalValue: Variable seleccionada no ligada: " ++
                        show o ++ ")")
    Just (LaBardo nz)
      | 0 <= w && w < fromIntegral (length nz)
                  -> nz !! fromIntegral w
      | otherwise -> error ("(evalValue: SelK fuera de rango)")
    Just _ -> error ("(evalValue: SelK sobre un valor que no es un registro)")

lloron34 :: La86 -> Liga2 -> Rana2 Cuete10

lloron34 a00 (Reo7 jai5 mino) =
  case fajada145 a00 jai5 of
    CocaPedo7 mosca ->
      let rua79 = map (fajada145 a00) mino
       in mosca rua79
    quia6 -> error (
               "(evalExpr: " ++ show jai5 ++ " no evalúa a una función " ++
               "sino a " ++ show quia6 ++ ")")

lloron34 a00 (Cuete45 fifi o isa2) =
  let rua79 = map (fajada145 a00) fifi in
    lloron34 (fame o (LaBardo rua79) a00) isa2

lloron34 a00 (Guarda4 w a49 o isa2) =
  case fajada145 a00 a49 of
    LaBardo al4 ->
      lloron34 (fame o (al4 !! fromIntegral w) a00) isa2
    _ -> error ("(evalExpr: El argumento de SelectK no es un registro: " ++
                show w ++ " " ++
                show (fajada145 a00 a49) ++ " " ++
                show o)

lloron34 a00 (Manu amuro isa2) =
    lloron34 cotorraOpa2 isa2
  where
    cotorraOpa2 :: La86
    cotorraOpa2 = frilan40 (map opio182 amuro) a00
    opio182 :: TocadoTras10 -> (La4, Corte0)
    opio182 (Zarzo79 j mino capo) =
      (j,
        CocaPedo7 $ \ hecho6 ->
          lloron34 (frilan40 (zip mino hecho6) cotorraOpa2) capo)

lloron34 a00 (Patova8 a49 lastrar5) =
  let Bufonazo7 (Ranero2 w) = fajada145 a00 a49 in
    lloron34 a00 (lastrar5 !! fromIntegral w)

lloron34 a00 (Marinante1 MaranfioForro hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 chinchudo a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 MenesundaLa94 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 guapear46 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 ChanchoGorda hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (==) a00 hecho6 copo7

lloron34 a00 (Marinante1 ApronteFija7 hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (<=) a00 hecho6 copo7

lloron34 a00 (Marinante1 PapelonZapar2 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 desbole18 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 TumbaderoChe2 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 ramaCapo2 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 AcanalarChala hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 fenomeno8 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 Cachiporra65 hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (/=) a00 hecho6 copo7

lloron34 a00 (Marinante1 ChangaTabas5 hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (<) a00 hecho6 copo7

lloron34 a00 (Marinante1 ApoliyoLuca5 hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (>=) a00 hecho6 copo7

lloron34 a00 (Marinante1 PacoyLompa51 hecho6 [] copo7) =
  guitaPorroLunfoDescuerearAl79 (>) a00 hecho6 copo7

lloron34 a00 (Marinante1 MalcoChimentero9 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 hiloPalmera7 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 MitaDariqueCana7 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 gomaFichar19 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 YuguiyoCulata hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 bacanaje6 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 MopioMaroteA15 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 bardoMinga a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 AmbidextroPua0 hecho6 [nlz] [isa2]) =
  canutoChichipioBrutalNp56 chochoPur8 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 PuaDesbolePan0 hecho6 [nlz] [isa2]) =
  empavonadaBrilllosPua9 caretear68 a00 hecho6 nlz isa2

lloron34 a00 (Marinante1 FelpudoGil5 hecho6 [nlz] [isa2]) =
  bondiInflarMorochaRaje2 (fromIntegral . ord) a00 hecho6 nlz isa2
lloron34 a00 (Marinante1 Afanancio65 hecho6 [nlz] [isa2]) =
  caladoMilongaGarfios432 (chr . fromIntegral) a00 hecho6 nlz isa2
lloron34 a00 (Marinante1 AgachadaCapo12 [quia6] [nlz] [isa2]) =
  let (Bufonazo7 (Ranero2 l)) = fajada145 a00 quia6
   in
     if l == 0
      then lift $ exitWith ExitSuccess
      else lift $ exitWith $ ExitFailure (fromIntegral l)

lloron34 a00 (Marinante1 Beberaje2 [quia6] [] [pirar, cufa1]) =
  if porroFueyero (fajada145 a00 quia6)
   then lloron34 a00 pirar
   else lloron34 a00 cufa1

lloron34 a00 (Marinante1 Rejilla [quia6] [nlz] [isa2]) =
  let trua49 = fajada145 a00 quia6 in
    lloron34 (fame nlz (solfa841 trua49) a00) isa2

lloron34 a00 (Marinante1 Salame5 [quia6] [nlz] [isa2]) = do
  tai <- cascarazo3 (fajada145 a00 quia6)
  lloron34 (fame nlz tai a00) isa2

lloron34 a00 (Marinante1 Falocrata [quia6] [nlz] [isa2]) = do
  a49 <- rascaChe1 (fajada145 a00 quia6)
  lloron34 (fame nlz a49 a00) isa2

lloron34 a00 (Marinante1 OrejearA75 [de36, gay9] [nlz] [isa2]) = do
  estaroGay4 (fajada145 a00 de36) (fajada145 a00 gay9)
  lloron34 (fame nlz (Bufonazo7 (Ranero2 0)) a00) isa2

lloron34 a00 (Marinante1 OrejearA75 [de36, gay9] [] [isa2]) = do
  estaroGay4 (fajada145 a00 de36) (fajada145 a00 gay9)
  lloron34 a00 isa2

lloron34 a00 (Marinante1 JetearRagu1 [a49] [nlz] [isa2]) = do
  let Bufonazo7 (Pirar r) = fajada145 a00 a49 in do
    lift (putChar r)
    lloron34 (fame nlz (Bufonazo7 (Ranero2 0)) a00) isa2

lloron34 a00 (Marinante1 JetearRagu1 [a49] [] [isa2]) = do
  let Bufonazo7 (Pirar r) = fajada145 a00 a49 in do
    lift (putChar r)
    lloron34 a00 isa2

lloron34 a00 (Marinante1 FinirBolasMula3 hecho6 [] copo7) =
  codeguinFletarMaturrangoDe357 (==) a00 hecho6 copo7

lloron34 a00 (Marinante1 m hecho6 rea1 copo7) =
  error ("La primitiva " ++ show m ++ " no está implementada.")

lloron34 a00 (ChivoA70 m hecho6 rea1 copo7) =
  error ("No se puede usar una función gringa en el intérprete:\n" ++
         show m)

canutoChichipioBrutalNp56 ::
    (Integer -> Integer -> Integer) ->
    La86 -> [Bacan8] -> La4 -> Liga2 -> Rana2 Cuete10
canutoChichipioBrutalNp56 j a00 hecho6 nlz isa2 =
  let [Bufonazo7 (Ranero2 gb), Bufonazo7 (Ranero2 ut)] =
        map (fajada145 a00) hecho6
   in lloron34 (fame nlz (Bufonazo7 (Ranero2 (j gb ut))) a00) isa2

empavonadaBrilllosPua9 ::
    (Integer -> Integer) ->
    La86 -> [Bacan8] -> La4 -> Liga2 -> Rana2 Cuete10
empavonadaBrilllosPua9 j a00 hecho6 nlz isa2 =
  let [Bufonazo7 (Ranero2 gb)] =
        map (fajada145 a00) hecho6
   in lloron34 (fame nlz (Bufonazo7 (Ranero2 (j gb))) a00) isa2

bondiInflarMorochaRaje2 ::
    (Char -> Integer) ->
    La86 -> [Bacan8] -> La4 -> Liga2 -> Rana2 Cuete10
bondiInflarMorochaRaje2 j a00 hecho6 nlz isa2 =
  let [Bufonazo7 (Pirar gb)] =
        map (fajada145 a00) hecho6
   in lloron34 (fame nlz (Bufonazo7 (Ranero2 (j gb))) a00) isa2

caladoMilongaGarfios432 ::
    (Integer -> Char) ->
    La86 -> [Bacan8] -> La4 -> Liga2 -> Rana2 Cuete10
caladoMilongaGarfios432 j a00 hecho6 nlz isa2 =
  let [Bufonazo7 (Ranero2 gb)] =
        map (fajada145 a00) hecho6
   in lloron34 (fame nlz (Bufonazo7 (Pirar (j gb))) a00) isa2

guitaPorroLunfoDescuerearAl79 ::
    (Integer -> Integer -> Bool) ->
    La86 -> [Bacan8] -> [Liga2] -> Rana2 Cuete10
guitaPorroLunfoDescuerearAl79 j a00 hecho6 [pirar, cufa1] =
  let [Bufonazo7 (Ranero2 gb), Bufonazo7 (Ranero2 ut)] =
        map (fajada145 a00) hecho6 in
     if j gb ut
      then lloron34 a00 pirar
      else lloron34 a00 cufa1

codeguinFletarMaturrangoDe357 ::
    (Integer -> Integer -> Bool) ->
    La86 -> [Bacan8] -> [Liga2] -> Rana2 Cuete10
codeguinFletarMaturrangoDe357 j a00 hecho6 [pirar, cufa1] =
  let [Sopapo733 gb, Sopapo733 ut] =
        map (fajada145 a00) hecho6 in
     if j gb ut
      then lloron34 a00 pirar
      else lloron34 a00 cufa1

solfa841 :: Corte0 -> Corte0
solfa841 (LaBardo (Bufonazo7 (Ranero2 l) : _)) = Bufonazo7 (Ranero2 l)
solfa841 (Bufonazo7 r) = Bufonazo7 (Ranero2 $ cueroBanana r)

cueroBanana :: Mersun99 -> Integer
cueroBanana (Ranero2 l) = l
cueroBanana (Pirar r)   = fromIntegral (ord r)

porroFueyero :: Corte0 -> Bool
porroFueyero (LaBardo _)   = True
porroFueyero (Bufonazo7 _) = False

chinchudo :: Integer -> Integer -> Integer
chinchudo o s = (o + s) `mod` (globoRufino20 + 1)

guapear46 :: Integer -> Integer -> Integer
guapear46 o s = (o - s) `mod` (globoRufino20 + 1)

desbole18 :: Integer -> Integer -> Integer
desbole18 o s = (o * s) `mod` (globoRufino20 + 1)

ramaCapo2 :: Integer -> Integer -> Integer
ramaCapo2 o s = (o `div` s) `mod` (globoRufino20 + 1)

fenomeno8 :: Integer -> Integer -> Integer
fenomeno8 o s = (o `mod` s) `mod` (globoRufino20 + 1)

hiloPalmera7 :: Integer -> Integer -> Integer
hiloPalmera7 o s = (o * (2 ^ s)) `mod` (globoRufino20 + 1)

gomaFichar19 :: Integer -> Integer -> Integer
gomaFichar19 o s = (o `div` (2 ^ s)) `mod` (globoRufino20 + 1)

bacanaje6 :: Integer -> Integer -> Integer
bacanaje6 o s = (o .|. s) `mod` (globoRufino20 + 1)

bardoMinga :: Integer -> Integer -> Integer
bardoMinga o s = (o .&. s) `mod` (globoRufino20 + 1)

chochoPur8 :: Integer -> Integer -> Integer
chochoPur8 o s = (o `xor` s) `mod` (globoRufino20 + 1)

caretear68 :: Integer -> Integer
caretear68 o = (complement o) `mod` (globoRufino20 + 1)

fanega16 :: Mate6 -> Liga2 -> Miron79 Cuete10
fanega16 isa2 gula =
    evalStateT (lloron34 rechipe373 gula) bochoMufarse
  where
    bochoMufarse :: Minola726
    bochoMufarse = Minola726 {
                     desgrilarEsguifuso4 = 0,
                     piantar = Map.empty
                   }
    rechipe373 :: La86
    rechipe373 = Map.fromList [
        (-1, CocaPedo7 isa2)
      ]

percantinaCatrera951 :: Mate6
percantinaCatrera951 [o] = do
  lift (putStr (show o ++ "\n"))
  return belin1

tacheroYurnoLarva9 :: Mate6
tacheroYurnoLarva9 [o] = return o

al95 :: Liga2 -> IO Corte0
al95 = fanega16 tacheroYurnoLarva9

