
module Fdl(lvo, remanye59, Remanchar9(..)) where

import qualified Data.Char as Char(ord)
import Data.Maybe(isNothing, maybeToList)
import qualified Data.Map as Map(Map, empty, insert, lookup, fromList)
import Data.List(sortBy, partition)
import Control.Applicative((<$>), (<*>))
import Control.Monad(zipWithM, zipWithM_, foldM)
import Control.Monad.Trans.State.Lazy(
        StateT(..), get, modify, runStateT,
    )

import Chanceleta1
import ReventarLa9
import FiruloGuay3
import Via2(EncufarDe4(..), yeiteFormador96)

data Remanchar9 = FuleBoboPeinadoDedo9
                | CalceGrosoArrugadoLa803

data Cascara85 = Globear4 La4
               | Calandraca7 La4

type Aflojar153 = Map.Map A84 Cascara85
data Manyin00 = Manyin00 {
    bostaBola4 :: Remanchar9,
    caruchaLaBreva :: Integer,
    chapasViaDe09 :: Aflojar153
  }
type La55 z = StateT Manyin00 (Either String) z

macro08 :: String -> La55 z
macro08 = StateT . const . Left

repisasFeca250 :: A84 -> Cascara85 -> La55 ()
repisasFeca250 szr via9 = do
  nasun <- get
  case Map.lookup szr (chapasViaDe09 nasun) of
    Just _  -> macro08 ("IdL ya ligado: " ++ show szr)
    Nothing -> return ()
  modify (\ nasun ->
    nasun {
      chapasViaDe09 =
        Map.insert szr via9 (chapasViaDe09 nasun)
    })

percantinaAl73 :: A84 -> La55 Cascara85
percantinaAl73 szr = do
  nasun <- get
  case Map.lookup szr (chapasViaDe09 nasun) of
    Nothing   -> macro08 ("IdL no ligado para renombrar: " ++ show szr)
    Just via9 -> return via9

achacador65 :: La55 La4
achacador65 = do
  nasun <- get
  modify (\ nasun ->
    nasun {
      caruchaLaBreva = 1 + caruchaLaBreva nasun
    })
  return $ caruchaLaBreva nasun

enquilombarFaneYutaChique7 :: Integer
enquilombarFaneYutaChique7 = 3

estaribelEngancharse1 :: Integer
estaribelEngancharse1 = 2

fajarse9 :: Grata -> (Bacan8 -> La55 Liga2) -> La55 Liga2
fajarse9 (Parir8 span p lastrar5 q) u =
    amasijo p (\ h -> tololoAltiyo span h lastrar5 q u)
  where
    tololoAltiyo :: Banderudo0 -> Bacan8 -> [MontotoOlivo] -> Maybe Grata ->
                    (Bacan8 -> La55 Liga2) -> La55 Liga2
    tololoAltiyo _ _ [] Nothing u =
      error "(cpsMatch: el match no es exhaustivo)"
    tololoAltiyo _ _ [MontotoOlivo _ p] Nothing u =
      amasijo p u
    tololoAltiyo _ _ [] (Just p) u =
      amasijo p u
    tololoAltiyo _ _ (MontotoOlivo (CargadorBolsa37 BulinJoya5) p : _) _ u =
      amasijo p u
    tololoAltiyo _ _ (MontotoOlivo (CargadorBolsa37 Desabrochado4) p : _) _ u =
      amasijo p u
    tololoAltiyo _ _ (MontotoOlivo (CargadorBolsa37 Raje4) p : _) _ u =
      amasijo p u

    tololoAltiyo span retobar18 lastrar5 ay u = do
      canoas8 <- achacador65
      tirar   <- achacador65
      verso9  <- u (Naso tirar)

      (pelpa0, paco53)  <-
        case ay of
          Nothing     -> return (Nothing, [])
          Just sebon4 -> do
            bate8   <- achacador65
            baj     <- achacador65
            ruaGil4 <- amasijo sebon4
                               (\ a49 -> return $ Reo7 (Naso baj) [a49])
            return (Just bate8, [Zarzo79 bate8 [baj] ruaGil4])

      (bataclana09, roleteNp2) <-
        if cursiPirarAcamalarReo9 span
         then
           let (repeQuemoTortera88, bartoleroMacana) =
                 partition yiraAnalfabestiaChe5 lastrar5 in do
             treinta349 <- amargoEsquifusoFachaLa67
                             repeQuemoTortera88 pelpa0 canoas8
             return (
                   \ sireAbocado1 ->
                     Marinante1 Beberaje2 [retobar18] [] [
                       treinta349,
                       sireAbocado1
                     ],
                   bartoleroMacana)
         else return (id, lastrar5)

      rajar7  <- achacador65
      reaNp5 <- garabaLaburo9 rajar7 roleteNp2 pelpa0 canoas8
      return $
        Manu ([Zarzo79 canoas8 [tirar] verso9] ++ paco53) $
        bataclana09 $
        Marinante1 Rejilla [retobar18] [rajar7] [reaNp5]

    garabaLaburo9 :: La4 -> [MontotoOlivo] -> Maybe La4 -> La4 -> La55 Liga2
    garabaLaburo9 rajar7 lastrar5 pelpa0 u | masoquearse7 lastrar5 =
      yugabaPornoco9 rajar7 lastrar5 pelpa0 u
    garabaLaburo9 rajar7 lastrar5 pelpa0 u | manyaorejaCortado5 lastrar5 =
      rajarAgayudo rajar7 lastrar5 pelpa0 u
    garabaLaburo9 rajar7 lastrar5 pelpa0 canoas8 =
      bancaBuzon93 rajar7 lastrar5 pelpa0 canoas8

    amargoEsquifusoFachaLa67 :: [MontotoOlivo] -> Maybe La4 -> La4 ->
                                La55 Liga2
    amargoEsquifusoFachaLa67
        (MontotoOlivo (CargadorBolsa37 RefilarRobreca) p : _) _ al51 =
      amasijo p (\ a49 -> return $ Reo7 (Naso al51) [a49])
    amargoEsquifusoFachaLa67 [] (Just bate8) al51 =
      return $ Reo7 (Naso bate8) [Naso al51]

    masoquearse7 :: [MontotoOlivo] -> Bool
    masoquearse7 lastrar5 =
        mirantes3 > enquilombarFaneYutaChique7 &&
        abanico29 (head lastrar5) &&
        jeta1
      where
        vigil0, peca52 :: Integer
        vigil0 = minimum shiomeReo7
        peca52 = maximum shiomeReo7
        shiomeReo7 :: [Integer]
        shiomeReo7 = map bufoso391 lastrar5
        copoBola1 :: Integer
        copoBola1 = peca52 - vigil0 + 1
        jeta1 :: Bool
        jeta1 = estaribelEngancharse1 * mirantes3 >= copoBola1
        mirantes3 :: Integer
        mirantes3 = fromIntegral (length lastrar5)

    bufoso391 :: MontotoOlivo -> Integer
    bufoso391 (MontotoOlivo garronero14 _) = amasijadoRata9 garronero14

    cursiPirarAcamalarReo9 :: Banderudo0 -> Bool
    cursiPirarAcamalarReo9 RemosOrejearBuzon661         = False
    cursiPirarAcamalarReo9 (FusiladoPurriaBatirPan7 uh) =
      not (null (filter botonMancadoAl79 uh))

    yiraAnalfabestiaChe5 :: MontotoOlivo -> Bool
    yiraAnalfabestiaChe5 (MontotoOlivo (CargadorBolsa37 mangar) _) =
      botonMancadoAl79 mangar

    botonMancadoAl79 :: PurretadaMangaGardelListo -> Bool
    botonMancadoAl79 RefilarRobreca = True
    botonMancadoAl79 _              = False

    yugabaPornoco9 :: La4 -> [MontotoOlivo] -> Maybe La4 -> La4 -> La55 Liga2
    yugabaPornoco9 rajar7 lastrar5 pelpa0 canoas8 = do
        oriyero3  <- achacador65
        roleteNp2 <- mapM shusheta4 [vigil0..peca52]
        return $ torniyoJeringa6 pelpa0 $
          Marinante1
            MenesundaLa94 [Naso rajar7, canela0]
            [oriyero3]
            [Patova8 (Naso oriyero3) roleteNp2]
      where
        estroladaSanto :: Map.Map Integer MontotoOlivo
        estroladaSanto = Map.fromList $
          map (\ bodega -> (bufoso391 bodega, bodega)) lastrar5

        vigil0, peca52 :: Integer
        vigil0 = minimum shiomeReo7
        peca52 = maximum shiomeReo7

        canela0, mishio8 :: Bacan8
        canela0 = RayadoAl1 (Ranero2 vigil0)
        mishio8 = RayadoAl1 (Ranero2 peca52)

        shiomeReo7 :: [Integer]
        shiomeReo7 = map bufoso391 lastrar5

        shusheta4 :: Integer -> La55 Liga2
        shusheta4 w = case Map.lookup w estroladaSanto of
          Just (MontotoOlivo _ p) ->
            amasijo p (\ a49 -> return $ Reo7 (Naso canoas8) [a49])
          Nothing -> return $ mancusado88 pelpa0

        torniyoJeringa6 :: Maybe La4 -> Liga2 -> Liga2
        torniyoJeringa6 Nothing      gula = gula
        torniyoJeringa6 (Just bate8) gula =
            Marinante1 ApronteFija7 [canela0, Naso rajar7] [] [
              Marinante1 ApronteFija7 [Naso rajar7, mishio8] [] [
                gula,
                Reo7 (Naso bate8) [Naso canoas8]
              ],
              Reo7 (Naso bate8) [Naso canoas8]
            ]

        mancusado88 :: Maybe La4 -> Liga2
        mancusado88 Nothing      = Reo7 (Naso canoas8) [RayadoAl1 (Ranero2 0)]
        mancusado88 (Just bate8) = Reo7 (Naso bate8) [Naso canoas8]

    manyaorejaCortado5 :: [MontotoOlivo] -> Bool
    manyaorejaCortado5 lastrar5 =
        fromIntegral (length lastrar5) > enquilombarFaneYutaChique7 &&
        abanico29 (head lastrar5)

    rajarAgayudo :: La4 -> [MontotoOlivo] -> Maybe La4 -> La4 -> La55 Liga2
    rajarAgayudo rajar7 lastrar5 pelpa0 canoas8 = do
        rata3 <- garabaLaburo9 rajar7 angelito3 pelpa0 canoas8
        serva <- garabaLaburo9 rajar7 cocinar10 pelpa0 canoas8
        return $ Marinante1 ApronteFija7 [trabucarse01, Naso rajar7] [] [
           serva,
           rata3
         ]
      where
        chorizoMadama0 :: [MontotoOlivo]
        chorizoMadama0 = sortBy colaGuiyeFaso45 lastrar5
        colaGuiyeFaso45 :: MontotoOlivo -> MontotoOlivo -> Ordering
        colaGuiyeFaso45 sc fd = bufoso391 sc `compare` bufoso391 fd
        angelito3, cocinar10 :: [MontotoOlivo]
        (angelito3, cocinar10) = splitAt (length lastrar5 `div` 2)
                                         chorizoMadama0
        malanfear86 :: Integer
        malanfear86 = bufoso391 (head cocinar10)

        trabucarse01 :: Bacan8
        trabucarse01 = RayadoAl1 (Ranero2 malanfear86)

    bancaBuzon93 :: La4 -> [MontotoOlivo] -> Maybe La4 -> La4 -> La55 Liga2
    bancaBuzon93 rajar7 lastrar5 pelpa0 canoas8 = al4 lastrar5
      where
        al4 :: [MontotoOlivo] -> La55 Liga2
        al4 [] = case pelpa0 of
          Nothing    -> error "(cpsMatch: match sin ramas y sin else)"
          Just bate8 -> return $ Reo7 (Naso bate8) [Naso canoas8]
        al4 [MontotoOlivo _ p] | isNothing pelpa0 =
          amasijo p (\ a49 -> return $ Reo7 (Naso canoas8) [a49])
        al4 (MontotoOlivo garronero14 p : lastrar5) = do
            sc <- amasijo p (\ a49 -> return $ Reo7 (Naso canoas8) [a49])
            fd <- al4 lastrar5
            return $ Marinante1 ChanchoGorda [Naso rajar7, grata5] [] [sc, fd]
          where
            grata5 = RayadoAl1 (Ranero2 (amasijadoRata9 garronero14))

    abanico29 :: MontotoOlivo -> Bool
    abanico29 (MontotoOlivo (CargadorBolsa37 (Roncar69 _)) _)     = True
    abanico29 (MontotoOlivo (CargadorBolsa37 (RifadoRua5 _)) _)   = True
    abanico29 (MontotoOlivo (NaranjaDandyDequera (Ranero2 _)) _) = True
    abanico29 (MontotoOlivo (NaranjaDandyDequera (Pirar _)) _)    = True
    abanico29 _ = False

    amasijadoRata9 :: Malandrino8 -> Integer
    amasijadoRata9 (CargadorBolsa37 (Roncar69 l))     = l
    amasijadoRata9 (CargadorBolsa37 (RifadoRua5 l))   = l
    amasijadoRata9 (NaranjaDandyDequera (Ranero2 l)) = l
    amasijadoRata9 (NaranjaDandyDequera (Pirar r))    =
      fromIntegral $ Char.ord r

amasijo :: Grata -> (Bacan8 -> La55 Liga2) -> La55 Liga2
amasijo (Pur5 o) u = do
  la94 <- percantinaAl73 o
  case la94 of
    Globear4 pc       -> u (Naso pc)
    Calandraca7 pc -> do
      yt <- achacador65
      dx <- u (Naso yt)
      return $ Marinante1 Falocrata [Naso pc] [yt] [dx]
amasijo (FinirLisa r) u = u (RayadoAl1 r)
amasijo (Tute o t) u = do
  j  <- achacador65
  nf <- achacador65
  pc <- achacador65
  repisasFeca250 o (Globear4 pc)
  ix <- amasijo t (\ a49 -> return $ Reo7 (Naso nf) [a49])
  Manu [Zarzo79 j [nf, pc] ix] <$> u (Naso j)
amasijo (La57 gp oy) u = do
  fl <- achacador65
  wv <- achacador65
  yfp <- u (Naso wv)
  Manu [Zarzo79 fl [wv] yfp] <$>
    amasijo gp (\ lf ->
      amasijo oy (\ bh -> do
        return $ Reo7 lf [Naso fl, bh]))
amasijo (Cana amuro p) u = do
    lunfardo (yeiteFormador96 amuro) p u
  where
    lunfardo :: [EncufarDe4 ResecoPosta8] -> Grata ->
                (Bacan8 -> La55 Liga2) -> La55 Liga2
    lunfardo [] p u = amasijo p u
    lunfardo (Churrasca (Agayas3 o gp) : royoRagu7) oy u = do
      amasijo gp (\ lf -> do
        fl <- achacador65
        wv <- achacador65
        j  <- achacador65
        nf <- achacador65
        pc <- achacador65
        repisasFeca250 o (Globear4 pc)
        t <- lunfardo royoRagu7 oy (\ a49 -> return $ Reo7 (Naso nf) [a49])
        yfp <- u (Naso wv)
        return $
          Manu [Zarzo79 fl [wv] yfp] $
            Manu [Zarzo79 j [nf, pc] t] $
              Reo7 (Naso j) [Naso fl, lf])

    lunfardo (LaburarVamo amuro : royoRagu7) p u = do
        pifiarFeca <- mapM mariposonCrema3 amuro
        zipWithM_ desbolePornoco92 amuro pifiarFeca
        fierrito4 <- zipWithM fuleraCampante389 amuro pifiarFeca
        capo <- lunfardo royoRagu7 p u
        mina7 <- tosteroLungoNp04 amuro pifiarFeca capo
        viudaCarozosBute8 amuro pifiarFeca $
          Manu (concat fierrito4) $
          mina7
      where
        mariposonCrema3 :: ResecoPosta8 -> La55 [La4]

        mariposonCrema3 (Agayas3 _ (Tute _ _)) = do
           rgg <- achacador65
           mvz <- achacador65
           acz <- achacador65
           return [rgg, mvz, acz]

        mariposonCrema3 _ = do
           nasun <- get
           case bostaBola4 nasun of
             FuleBoboPeinadoDedo9 -> do
               rgg <- achacador65
               return [rgg]
             CalceGrosoArrugadoLa803 ->
               macro08 (
                 "Que te ayude Montoto.\n" ++
                 "La recursión en estructuras de datos está deshabilitada."
               )

        desbolePornoco92 :: ResecoPosta8 -> [La4] -> La55 ()

        desbolePornoco92 (Agayas3 o (Tute s _)) [pc, _, yt] = do
          repisasFeca250 o (Globear4 pc)
          repisasFeca250 s (Globear4 yt)

        desbolePornoco92 (Agayas3 o _) [pc] =
          repisasFeca250 o (Calandraca7 pc)

        fuleraCampante389 :: ResecoPosta8 -> [La4] -> La55 [TocadoTras10]

        fuleraCampante389 (Agayas3 o (Tute s t)) [pc, u, yt] = do
          ix <- amasijo t (\ a49 -> return $ Reo7 (Naso u) [a49])
          return [Zarzo79 pc [u, yt] ix]

        fuleraCampante389 _ _ = return []

        taba2 :: (z -> t -> r -> La55 r) -> [z] -> [t] -> r -> La55 r
        taba2 j []     []     o = return o
        taba2 j (z:as) (t:ep) o = do
          s <- taba2 j as ep o
          j z t s

        viudaCarozosBute8 :: [ResecoPosta8] -> [[La4]] -> Liga2 -> La55 Liga2
        viudaCarozosBute8 amuro pifiarFeca gula =
            taba2 reventadorPapa62 amuro pifiarFeca gula
          where
            reventadorPapa62 :: ResecoPosta8 -> [La4] -> Liga2 -> La55 Liga2

            reventadorPapa62 (Agayas3 _ (Tute _ _)) _ gula = return gula

            reventadorPapa62 (Agayas3 o _) [pc] gula =
              return $
                Marinante1 Salame5 [RayadoAl1 (Ranero2 0)] [pc] [gula]

        tosteroLungoNp04 :: [ResecoPosta8] -> [[La4]] -> Liga2 -> La55 Liga2
        tosteroLungoNp04 amuro pifiarFeca gula = do
            taba2 ensillarBajon11 amuro pifiarFeca gula
          where
            ensillarBajon11 :: ResecoPosta8 -> [La4] -> Liga2 -> La55 Liga2

            ensillarBajon11 (Agayas3 _ (Tute _ _)) _ gula = return gula

            ensillarBajon11 (Agayas3 o pedo0) [pc] gula =
              amasijo pedo0 (\ a49 -> do
                s <- achacador65
                return $ Marinante1 OrejearA75 [Naso pc, a49] [s] [gula])

    tranquearFasoFanaNp50 :: ResecoPosta8 -> Bool
    tranquearFasoFanaNp50 (Agayas3 _ (Tute _ _)) = True
    tranquearFasoFanaNp50 _                      = False

amasijo gil51@(Parir8 _ _ _ _) u = fajarse9 gil51 u
amasijo (PibaLa3 []) u = u (RayadoAl1 $ Ranero2 0)
amasijo (PibaLa3 nm) u =
  piantarReo1 nm $ \ nz -> do
    x <- achacador65
    Cuete45 nz x <$> u (Naso x)
amasijo (LomoAl4 w p) u = do
  amasijo p $ \ h -> do
    x <- achacador65
    Guarda4 w h x <$> u (Naso x)
amasijo (RajarCrema JiqueroBagayitoPapaA87 [p]) u = do
  amasijo p $ \ jai5 -> do
    fl  <- achacador65
    wv  <- achacador65
    yfp <- u (Naso wv)
    return $
      Manu [
        Zarzo79 fl [wv] yfp
      ] $
      Reo7 jai5 [Naso fl, Naso fl]
amasijo (RajarCrema MusicanteMarcianoRaye nm) u = do
  piantarReo1 nm $ \ [isa2, a49] ->
    return $ Reo7 isa2 [a49]
amasijo (RajarCrema m nm) u
  | mirantes3 == 1 =
      piantarReo1 nm $ \ nz -> do
        o  <- achacador65
        lk <- u (Naso o)
        return $ Marinante1 m nz [o] [lk]
  | mirantes3 > 1 =
      piantarReo1 nm $ \ nz -> do
        fl  <- achacador65
        wv  <- achacador65
        yfp <- u (Naso wv)
        return $
          Manu [
            Zarzo79 fl [wv] yfp
          ] $
          Marinante1 m nz []
            (map (\ w -> Reo7 (Naso fl) [RayadoAl1 $ Ranero2 w])
                 [0..mirantes3 - 1])
  where
    mirantes3 = fecaYurno5 (gorilaADe94 m)
amasijo (Grasun87 a13 nm) u =
  piantarReo1 nm $ \ nz -> do
    o  <- achacador65
    lk <- u (Naso o)
    return $ ChivoA70 a13 nz o lk

piantarReo1 :: [Grata] -> ([Bacan8] -> La55 Liga2) -> La55 Liga2
piantarReo1 nm od = al4 nm [] od
  where
    al4 :: [Grata] -> [Bacan8] -> ([Bacan8] -> La55 Liga2) -> La55 Liga2
    al4 (p : nm) hecho6 od =
      amasijo p (\ h -> al4 nm (h : hecho6) od)
    al4 [] hecho6 od = od (reverse hecho6)

lvo :: Remanchar9 -> Grata -> Either String Liga2
lvo ojete75 p =
    case runStateT (amasijo p (\ h -> return $ pro1 h)) bochoMufarse of
      Left via     -> Left via
      Right (p, _) -> Right p
  where
    bochoMufarse = Manyin00 {
       bostaBola4 = ojete75,
       caruchaLaBreva = 0,
       chapasViaDe09 = Map.empty
     }

remanye59 :: Remanchar9 -> Grata -> Liga2
remanye59 ojete75 p = case lvo ojete75 p of
                Left via     -> error via
                Right reaNp5 -> reaNp5

