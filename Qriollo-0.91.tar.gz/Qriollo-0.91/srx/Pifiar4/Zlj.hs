
module Pifiar4.Zlj(
        tamboTarado3, CalorBate3(..), MinoRantifusaMufa4(..)
    ) where

import Data.Char(chr, ord)
import Control.Monad(zipWithM)
import Control.Monad.Trans.State.Lazy(State, get, modify, runState)
import Data.List(findIndex, isPrefixOf)
import qualified Data.Map as Map(
        Map, empty, lookup, insert, fromList, toList, findWithDefault
    )

import Chanceleta1
import ReventarLa9
import FiruloGuay3
import Pifiar4.Filado96

data MinoRantifusaMufa4 = JvmOpt_ToplevelExit
                        | JvmOpt_ToplevelShowAsString
  deriving (Read, Eq)

data CalorBate3 = CalorBate3 {
                    colchonear4 :: MinoRantifusaMufa4
                  }

data CoteAl90 =
   CoteAl90 {
     falocracia :: Map.Map String Cotin7,
     priseBartoleroBocho8 :: Map.Map La4 BoladaA329,
     boliyaFideosJoya18 :: Map.Map La4 [La4],
     chupadinBasuriar550 :: BurroRula2,
     bolazoPelpaPosta932 :: Map.Map Integer (),
     entrancarseChina6 :: Integer,
     guitarreroLa16 :: Map.Map BurroRula2 (BoladaA329, BoladaA329)
   }
type La77 = State CoteAl90

type ViviyoMiti4 = Integer

data GaloQuemadoLa84 =
     GaloQuemadoLa84 {
         manyamientoRanero581       :: BurroRula2,
         fuleriaRajeRuaBombo11      :: [GaruarYuta3],
         astiyaEscobaCapoBoletaDe45 :: BurroRula2
     }

data JoyaCajetiyaLa46 =
     JoyaCajetiyaLa46 {
         sobradorManduqueChairaLa52  :: BurroRula2,
         trotadoraBufonazoA038       :: ZarparFrio0,
         lunfardoRatearBarbijo6      :: [GaruarYuta3],
         ensiyarseFideosCanastaOlivo :: AlfajiaAl22,
         jetatoreChusmajeMusa6       :: Maybe [Vlm],
         pelotudoPesebreEscashato35  :: [RaneroDe29]
     }

data GuilaMejicaneada753 =
     GuilaMejicaneada753 {
         falopaCaraculicoGatoYuta2      :: BurroRula2,
         lanceroCanchereadaLleno4       :: ZarparFrio0,
         apuntadorAtorroCanaTragarCapo3 :: AlfajiaAl22
     }

fuleriaHorizontal278 :: ChurrosGruyosPlomo
fuleriaHorizontal278 =
  ChurrosGruyosPlomo {
     pescadoGuitarrearChoclo5 = "java/lang/System",
     requintadoOrejudoVelas8 = "out",
     najusarAtorraderoGuri17 =
       MarcianoForro63 "java/io/PrintStream"
  }

bolacearGrilloCirquero014 :: GuilaMejicaneada753
bolacearGrilloCirquero014 =
  GuilaMejicaneada753 {
      falopaCaraculicoGatoYuta2 = "java/io/PrintStream",
      lanceroCanchereadaLleno4  = "print",
      apuntadorAtorroCanaTragarCapo3 =
        AlfajiaAl22 [MarcianoForro63 "java/lang/Object"] ChupeCucha
  }

fideosVueloChotoCapelunA596 :: GuilaMejicaneada753
fideosVueloChotoCapelunA596 =
  GuilaMejicaneada753 {
      falopaCaraculicoGatoYuta2 = "java/io/PrintStream",
      lanceroCanchereadaLleno4  = "println",
      apuntadorAtorroCanaTragarCapo3 =
        AlfajiaAl22 [MarcianoForro63 "java/lang/Object"] ChupeCucha
  }

untarUpaMangoEncamotarsePingo4 :: GuilaMejicaneada753
untarUpaMangoEncamotarsePingo4 =
  GuilaMejicaneada753 {
      falopaCaraculicoGatoYuta2 = "java/io/PrintStream",
      lanceroCanchereadaLleno4  = "print",
      apuntadorAtorroCanaTragarCapo3 =
        AlfajiaAl22 [ACuloHumo5] ChupeCucha
  }

culiadoRemancharBife7 :: GuilaMejicaneada753
culiadoRemancharBife7 =
  GuilaMejicaneada753 {
     falopaCaraculicoGatoYuta2 = "java/lang/System",
     lanceroCanchereadaLleno4  = "exit",
     apuntadorAtorroCanaTragarCapo3 =
       AlfajiaAl22 [ZafarNp49] ChupeCucha
  }

fumistaTacheroMilongaAl02 :: GuilaMejicaneada753
fumistaTacheroMilongaAl02 =
  GuilaMejicaneada753 {
     falopaCaraculicoGatoYuta2 = "java/lang/Integer",
     lanceroCanchereadaLleno4  = "valueOf",
     apuntadorAtorroCanaTragarCapo3 =
       AlfajiaAl22 [ZafarNp49] (MarcianoForro63 "java/lang/Integer")
  }

petisaEmpedarseMoscaMufa89 :: GuilaMejicaneada753
petisaEmpedarseMoscaMufa89 =
  GuilaMejicaneada753 {
     falopaCaraculicoGatoYuta2 = "java/lang/Integer",
     lanceroCanchereadaLleno4  = "intValue",
     apuntadorAtorroCanaTragarCapo3 =
       AlfajiaAl22 [] ZafarNp49
  }

curadoCaretaMaletaTrolo2 :: GuilaMejicaneada753
curadoCaretaMaletaTrolo2 =
  GuilaMejicaneada753 {
     falopaCaraculicoGatoYuta2 = "java/lang/Object",
     lanceroCanchereadaLleno4  = "equals",
     apuntadorAtorroCanaTragarCapo3 =
       AlfajiaAl22 [MarcianoForro63 "java/lang/Object"]
                   CabronAndante
  }

data ChupadoBuzarda4 =
     ChupadoBuzarda4 {
         bostaEsquilloCheAl12       :: ZarparFrio0,
         ranunFaloperoFeites60      :: [GaruarYuta3],
         clavarseCoceoFato872       :: Navo1,
         sacudirChalaChotoFragotero :: [RaneroDe29]
     }

data ChurrosGruyosPlomo =
     ChurrosGruyosPlomo {
         pescadoGuitarrearChoclo5 :: BurroRula2,
         requintadoOrejudoVelas8  :: ZarparFrio0,
         najusarAtorraderoGuri17  :: Navo1
     }

vichar8 :: [z] -> Integer
vichar8 = fromIntegral . length

pan8 :: Integer -> Integer -> String
pan8 t 0 = "0"
pan8 t l = al4 t l
  where
    pingo656 :: String
    pingo656 =
      "0123456789abcdefghijklmnopqrstuvwxyz"
    al4 :: Integer -> Integer -> String
    al4 t 0 = []
    al4 t l = al4 t (l `div` t) ++ [pingo656 !! fromIntegral (l `mod` t)]

fulerin23 :: Integer -> [z] -> (z -> z) -> [z]
fulerin23 w ws j = let (dz, p : td) = splitAt (fromIntegral w) ws in
                     dz ++ [j p] ++ td

sonatinaFlash8 :: CalorBate3 -> [Canoa5] -> BurroRula2 -> Liga2 ->
                  [(BurroRula2, Cotin7)]
sonatinaFlash8 acamala678 blanca6 esputzaVivo75 gula =
    case runState (jeton82 gula) bochoMufarse of
      (_, nasun) -> Map.toList (falocracia nasun)
  where
    bochoMufarse :: CoteAl90
    bochoMufarse =
      CoteAl90 {
        falocracia = Map.fromList [
          (esputzaVivo75,
           achumado03 (GaloQuemadoLa84 {
                          manyamientoRanero581 = esputzaVivo75,
                          fuleriaRajeRuaBombo11 = [MatonearChucaJeta2],
                          astiyaEscobaCapoBoletaDe45 = galerudo43
                      }))
        ],
        priseBartoleroBocho8 = Map.empty,
        boliyaFideosJoya18 = Map.empty,
        chupadinBasuriar550 = "",
        bolazoPelpaPosta932 = Map.empty,
        entrancarseChina6 = 0,
        guitarreroLa16 = Map.empty
      }

    galerudo43 :: BurroRula2
    galerudo43 = head $
                 concatMap calaveraTimbo913 blanca6 ++ ["java/lang/Object"]
      where
        calaveraTimbo913 :: Canoa5 -> [String]
        calaveraTimbo913 (FaloperoChoto LanguidoBanana apuntamento) =
          case words apuntamento of
            ["extends", al7] -> [al7]
            _ -> []
        calaveraTimbo913 _ = []

    achumado03 :: GaloQuemadoLa84 -> Cotin7
    achumado03 griloNp55 =
      Cotin7 {

          cagarLigaNaboNabo38 = 49,
          percantaAtorranta90 = 0,
          matrimoniadoBosta40 = [

            RajadoApunte718 (BoladaA329 2),

            FortachoCaron4 (manyamientoRanero581 griloNp55),

            RajadoApunte718 (BoladaA329 4),

            FortachoCaron4 (astiyaEscobaCapoBoletaDe45 griloNp55),

            FortachoCaron4 "Code",

            FortachoCaron4 "InnerClasses",

            FortachoCaron4 "StackMapTable"
          ],
          timbearCargarBombo  = fuleriaRajeRuaBombo11 griloNp55,
          alumbrarMorlaco5    = BoladaA329 1,
          gordaRongaApuntar   = BoladaA329 3,
          enfocarCable5       = [],
          fragoteroFula4      = [],
          brutalBarraHomo04   = []
      }

    invernizzio612 :: GaloQuemadoLa84 -> La77 ()
    invernizzio612 griloNp55 = do
      modify (\ nasun -> nasun {
        falocracia = Map.insert (manyamientoRanero581 griloNp55)
                                (achumado03 griloNp55)
                                (falocracia nasun)
      })

      guiyadoJeringaMufa2 <- sushetaGrata5
          (manyamientoRanero581 griloNp55)
          (GuilaMejicaneada753 {
             falopaCaraculicoGatoYuta2 =
               astiyaEscobaCapoBoletaDe45 griloNp55,
             lanceroCanchereadaLleno4  = "<init>",
             apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
          })

      despelote6
          (JoyaCajetiyaLa46 {
             sobradorManduqueChairaLa52  = manyamientoRanero581 griloNp55,
             trotadoraBufonazoA038       = "<init>",
             lunfardoRatearBarbijo6      = [],
             ensiyarseFideosCanastaOlivo = AlfajiaAl22 [] ChupeCucha,
             pelotudoPesebreEscashato35  = [],
             jetatoreChusmajeMusa6       = Just
                 [
                     Cachirulo99,
                     TrotadoraJeringa4 guiyadoJeringaMufa2,
                     Bulevar541
                 ]
          })

    runfla38 :: BurroRula2 -> La77 Cotin7
    runfla38 alGaga8 = do
      nasun <- get
      return $ Map.findWithDefault
                     (error
                       ("(exprToJClasses: clase no definida: " ++
                        alGaga8 ++
                        ")"))
                     alGaga8
                     (falocracia nasun)

    suertudo345 :: BurroRula2 -> (Cotin7 -> Cotin7) -> La77 ()
    suertudo345 alGaga8 j = do
      al7 <- runfla38 alGaga8
      modify (\ nasun -> nasun {
        falocracia = Map.insert alGaga8 (j al7) (falocracia nasun)
      })

    calarLinusa855 :: BurroRula2 -> GaloQuemadoLa84 -> La77 BoladaA329
    calarLinusa855 arranyar2 griloNp55 = do
        al7 <- runfla38 arranyar2
        w <- case findIndex lunfoDespeloteGrillero600
                            (brutalBarraHomo04 al7) of
               Nothing -> do
                   negrajeCalentura378 <- mancusadoAl53 arranyar2
                                          (FortachoCaron4 "InnerClasses")
                   suertudo345 arranyar2 (\ al7 -> al7 {
                       brutalBarraHomo04 =
                         brutalBarraHomo04 al7 ++
                         [MatufieroMalerbaApunte3 {
                            viyuyeraPetisaEspirajuseAl38 =
                              negrajeCalentura378,
                            shomeriaLancearOlfaMamboEnajarTayar4 = []
                         }]
                   })
                   return $ vichar8 (brutalBarraHomo04 al7)
               Just w  -> return (fromIntegral w)
        quecoEnfardar41 <- mancusadoAl53 arranyar2
                               (FortachoCaron4
                                 (manyamientoRanero581 griloNp55))
        boletaArranyar9 <- mancusadoAl53 arranyar2
                               (RajadoApunte718 quecoEnfardar41)
        invernizzio612 griloNp55
        suertudo345 arranyar2
          (\ al7 -> al7 {
            brutalBarraHomo04 =
              fulerin23 w (brutalBarraHomo04 al7)
                (\ al60 ->
                   al60 {
                       shomeriaLancearOlfaMamboEnajarTayar4 =
                       shomeriaLancearOlfaMamboEnajarTayar4 al60 ++ [
                         CraneoQuia3 {
                           naranjaEncocorarseGagaLa09 = boletaArranyar9,
                           lavanderoFacaPelecheFelpa4 = BoladaA329 0,
                           alGloboTachometroCatrera87 = quecoEnfardar41,
                           pechazoAbatatarseDiego3    =
                             fuleriaRajeRuaBombo11 griloNp55
                         }
                       ]
                   })
          })
        return boletaArranyar9
      where
        lunfoDespeloteGrillero600 (MatufieroMalerbaApunte3 _ _) = True
        lunfoDespeloteGrillero600 _ = False

    mancusadoAl53 :: BurroRula2 -> PiponLa17 -> La77 BoladaA329
    mancusadoAl53 alGaga8 chuca823 = do
        al7 <- runfla38 alGaga8
        case findIndex (== chuca823) (matrimoniadoBosta40 al7) of
          Just w  -> return $ BoladaA329 (fromIntegral (w + 1))
          Nothing -> do
            suertudo345 alGaga8
              (\ al7 -> al7 {
                matrimoniadoBosta40 = matrimoniadoBosta40 al7 ++ [chuca823]
              })
            al7 <- runfla38 alGaga8
            return $ BoladaA329 (vichar8 (matrimoniadoBosta40 al7))

    despelote6 :: JoyaCajetiyaLa46 -> La77 ()
    despelote6 griloNp55 = do
        betunAl61 <-
          mancusadoAl53
            alGaga8
            (FortachoCaron4 (trotadoraBufonazoA038 griloNp55))
        trepadorEnyugar <-
          mancusadoAl53
            alGaga8
            (ChorizoChivatoDiego4 (ensiyarseFideosCanastaOlivo griloNp55))
        suertudo345 alGaga8
          (\ al7 -> al7 {
            fragoteroFula4 = fragoteroFula4 al7 ++
                             [chapa6 betunAl61 trepadorEnyugar]
          })
      where
        alGaga8 :: BurroRula2
        alGaga8 = sobradorManduqueChairaLa52 griloNp55
        chapa6 :: BoladaA329 -> BoladaA329 -> Chabon8
        chapa6 betunAl61 trepadorEnyugar = Chabon8 {
          garabitoGaga2 = lunfardoRatearBarbijo6 griloNp55,
          entromparse8  = betunAl61,
          garronTruaPilas036 = trepadorEnyugar,
          anaanaCachuchaAl13 = runfleroYeyatore
                                 (jetatoreChusmajeMusa6 griloNp55)
        }
        runfleroYeyatore :: Maybe [Vlm] -> [RaneroDe29]
        runfleroYeyatore Nothing     = []
        runfleroYeyatore (Just de26) = [
              ShucaJeringa795 {
                hincharLimosneroNp44 = BoladaA329 5,
                purDeschavarEscorchador5 = 64,
                quiaHondaPiturrearRama701 = 64,
                diquePintadoRobreca2 = de26,
                corridoEscruchanteEnvinado = [],
                bolicheChucaDopadoAlcancia =
                  pelotudoPesebreEscashato35 griloNp55
              }
          ]

    sushetaGrata5 :: BurroRula2 -> GuilaMejicaneada753 -> La77 BoladaA329
    sushetaGrata5 alGaga8 griloNp55 = do
        casoMeodromo16 <-
          mancusadoAl53
            alGaga8
            (FortachoCaron4 (falopaCaraculicoGatoYuta2 griloNp55))
        tostero205 <-
          mancusadoAl53
            alGaga8
            (RajadoApunte718 casoMeodromo16)
        betunAl61 <-
          mancusadoAl53
            alGaga8
            (FortachoCaron4 (lanceroCanchereadaLleno4 griloNp55))
        trepadorEnyugar <-
          mancusadoAl53
            alGaga8
            (ChorizoChivatoDiego4 (apuntadorAtorroCanaTragarCapo3 griloNp55))
        jugarseDeschave7 <-
          mancusadoAl53 alGaga8 (GarquetaAlfajiaRafa19
                                   betunAl61
                                   trepadorEnyugar)
        descuerearDe97 <-
          mancusadoAl53 alGaga8 (FulmineCornoCuore27
                                   tostero205
                                   jugarseDeschave7)
        return descuerearDe97

    anduma003 :: BurroRula2 -> ChupadoBuzarda4 -> La77 ()
    anduma003 alGaga8 griloNp55 = do
      yutoGula5 <-
        mancusadoAl53
          alGaga8
          (OndaTorvelo206 (clavarseCoceoFato872 griloNp55))
      betunAl61 <-
        mancusadoAl53
          alGaga8
          (FortachoCaron4 (bostaEsquilloCheAl12 griloNp55))
      suertudo345 alGaga8 (\ al7 -> al7 {
          enfocarCable5 =
            enfocarCable5 al7 ++
              [Caber1 {
                  tarumbaRati5 = ranunFaloperoFeites60 griloNp55,
                  papelonAl33  = betunAl61,
                  buchonOnda8  = yutoGula5,
                  barulloTimbear339 = sacudirChalaChotoFragotero griloNp55
              }]
      })

    perroBicho88 :: BurroRula2 -> ChurrosGruyosPlomo -> La77 BoladaA329
    perroBicho88 alGaga8 griloNp55 = do
        casoMeodromo16 <-
          mancusadoAl53
            alGaga8
            (FortachoCaron4 (pescadoGuitarrearChoclo5 griloNp55))
        tostero205 <-
          mancusadoAl53
            alGaga8
            (RajadoApunte718 casoMeodromo16)
        betunAl61 <-
          mancusadoAl53
            alGaga8
            (FortachoCaron4 (requintadoOrejudoVelas8 griloNp55))
        yutoGula5 <-
          mancusadoAl53
            alGaga8
            (OndaTorvelo206 (najusarAtorraderoGuri17 griloNp55))
        jugarseDeschave7 <-
          mancusadoAl53 alGaga8 (GarquetaAlfajiaRafa19
                                   betunAl61
                                   yutoGula5)
        libretoOpa612 <-
          mancusadoAl53 alGaga8 (ChairaArticuloDe33
                                   tostero205
                                   jugarseDeschave7)
        return libretoOpa612

    abrochar934 :: La77 Enaje7
    abrochar934 = do
      nasun <- get
      modify (\ nasun -> nasun {
        entrancarseChina6 = entrancarseChina6 nasun + 1
      })
      return $ "Label_" ++ show (entrancarseChina6 nasun)

    jeton82 :: Liga2 -> La77 ()
    jeton82 gula = do

      jamarSofaifaRobreca13 <- calarLinusa855 esputzaVivo75
        (GaloQuemadoLa84 {
            manyamientoRanero581  = garparLancero6 esputzaVivo75 "Cont",
            fuleriaRajeRuaBombo11 = [LevantarRanchitos4,
                                     RevienteCogerYigolo7],
            astiyaEscobaCapoBoletaDe45 = "java/lang/Object"
        })

      despelote6
        (JoyaCajetiyaLa46 {
            sobradorManduqueChairaLa52 = garparLancero6 esputzaVivo75 "Cont",
            trotadoraBufonazoA038 = "cont",
            lunfardoRatearBarbijo6 = [RevienteCogerYigolo7],
            ensiyarseFideosCanastaOlivo =
                AlfajiaAl22 [] ChupeCucha,
            pelotudoPesebreEscashato35  = [],
            jetatoreChusmajeMusa6 = Nothing
        })

      roleteGalo4 <-
        calarLinusa855 esputzaVivo75
          (GaloQuemadoLa84 {
              manyamientoRanero581  = garparLancero6 esputzaVivo75 "Top",
              fuleriaRajeRuaBombo11 = [LevantarRanchitos4],
              astiyaEscobaCapoBoletaDe45 =
                garparLancero6 esputzaVivo75 "Cont"
          })

      modify (\ nasun -> nasun {

          priseBartoleroBocho8 =
            Map.insert (-1) roleteGalo4
                       (priseBartoleroBocho8 nasun),
          boliyaFideosJoya18 =
            Map.insert (-1) [0]
                       (boliyaFideosJoya18 nasun)
      })

      nasoAcamalaBagayitoRayadura467 <-
        sushetaGrata5
          (garparLancero6 esputzaVivo75 "Top")
          fideosVueloChotoCapelunA596

      biabaFicharFalopaLisa3 <-
        sushetaGrata5
          (garparLancero6 esputzaVivo75 "Top")
          culiadoRemancharBife7

      solariYeiteForro281 <- cafeLarvaGaruferoDe38
                               (garparLancero6 esputzaVivo75 "Top")
                               0

      fiambreBochinCasoAceitosaRunflaA724 <-
        perroBicho88
            (garparLancero6 esputzaVivo75 "Top")
            fuleriaHorizontal278

      maromaBondi6 <-
        case colchonear4 acamala678 of
          JvmOpt_ToplevelShowAsString -> do

            hacerFanguyosCable5 (garparLancero6 esputzaVivo75 "Top")
            (musaRemancharCana9, _) <- alacransar67
            llenarVotacenFiruloFelpudo09 <-
              sushetaGrata5
                (garparLancero6 esputzaVivo75 "Top")
                bolacearGrilloCirquero014
            return [

                  AfilarYapa220 fiambreBochinCasoAceitosaRunflaA724,
                  AfilarYapa220 solariYeiteForro281,
                  BrzarroEmpapelar musaRemancharCana9,
                  GuincheroSanata59 llenarVotacenFiruloFelpudo09,

                  NasoNeura288,
                  BrzarroEmpapelar biabaFicharFalopaLisa3,
                  Bulevar541
              ]
          JvmOpt_ToplevelExit -> do

            return [
                  NasoNeura288,
                  BrzarroEmpapelar biabaFicharFalopaLisa3,
                  Bulevar541
              ]

      despelote6
        (JoyaCajetiyaLa46 {
            sobradorManduqueChairaLa52 = garparLancero6 esputzaVivo75 "Top",
            trotadoraBufonazoA038 = "cont",
            lunfardoRatearBarbijo6 = [],
            ensiyarseFideosCanastaOlivo =
                AlfajiaAl22 [] ChupeCucha,
            pelotudoPesebreEscashato35  = [],
            jetatoreChusmajeMusa6 = Just maromaBondi6
        })

      fatoSofaifaSanto7 <-
        sushetaGrata5
          esputzaVivo75
          (GuilaMejicaneada753 {
              falopaCaraculicoGatoYuta2 =
                garparLancero6 esputzaVivo75 "Cont",
              lanceroCanchereadaLleno4  = "cont",
              apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
          })

      festicholaMorondanga987 <-
        sushetaGrata5 esputzaVivo75 fumistaTacheroMilongaAl02

      hacerFanguyosCable5 (garparLancero6 esputzaVivo75 "Start")

      manduqueCasa4 <-
        calarLinusa855 esputzaVivo75
          (GaloQuemadoLa84 {
              manyamientoRanero581  = garparLancero6 esputzaVivo75 "Start",
              fuleriaRajeRuaBombo11 = [LevantarRanchitos4],
              astiyaEscobaCapoBoletaDe45 =
                garparLancero6 esputzaVivo75 "Cont"
          })
      felpear2 <- gorra gula
      despelote6
        (JoyaCajetiyaLa46 {
            sobradorManduqueChairaLa52 =
              garparLancero6 esputzaVivo75 "Start",
            trotadoraBufonazoA038 = "cont",
            lunfardoRatearBarbijo6 = [],
            ensiyarseFideosCanastaOlivo =
                 AlfajiaAl22 [] ChupeCucha,
            pelotudoPesebreEscashato35  = [],
            jetatoreChusmajeMusa6 = Just felpear2
        })
      piantaoZumbarse870 <-
        sushetaGrata5
          esputzaVivo75
          (GuilaMejicaneada753 {
              falopaCaraculicoGatoYuta2 =
                garparLancero6 esputzaVivo75 "Start",
              lanceroCanchereadaLleno4  = "<init>",
              apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
          })

      garronMulero62 <- guiyaFilo866 esputzaVivo75
                                     (garparLancero6 esputzaVivo75 "Cont")
      gansadaRegaladoDe674 <- cafeLarvaGaruferoDe38 esputzaVivo75 (-1)
      despelote6
        (JoyaCajetiyaLa46 {
            sobradorManduqueChairaLa52 = esputzaVivo75,
            trotadoraBufonazoA038 = "main",
            lunfardoRatearBarbijo6 = [MatonearChucaJeta2,
                                      LevantarRanchitos4],
            ensiyarseFideosCanastaOlivo =
                 AlfajiaAl22
                   [Testamento2 (MarcianoForro63 "java/lang/String")]
                   ChupeCucha,
            pelotudoPesebreEscashato35  = [

            ],
            jetatoreChusmajeMusa6 = Just (
                 [

                   Posta56 manduqueCasa4,
                   Banda08,
                   TrotadoraJeringa4 piantaoZumbarse870,
                   MachazoYeca61 gansadaRegaladoDe674,

                   Quilombo4 "loop",
                   AfilarYapa220 gansadaRegaladoDe674,
                   GronchoMelon5 garronMulero62,
                   GuincheroSanata59 fatoSofaifaSanto7,
                   NaboLa26 "loop",

                   Bulevar541
                 ]
            )
        })

    garparLancero6 :: BurroRula2 -> String -> BurroRula2
    garparLancero6 arranyar2 enyugar74 = arranyar2 ++ "$" ++ enyugar74

    alcanciaChoto5 :: La4 -> BurroRula2
    alcanciaChoto5 (-1)  = garparLancero6 esputzaVivo75 "Top"
    alcanciaChoto5 culo1 = garparLancero6 esputzaVivo75 ("L" ++ misto4 culo1)
      where

        misto4 :: Integer -> String
        misto4 = pan8 36

    guiyaFilo866 :: BurroRula2 -> BurroRula2 -> La77 BoladaA329
    guiyaFilo866 alGaga8 grilleroChacar815 = do
      casoMeodromo16 <-
        mancusadoAl53
          alGaga8
          (FortachoCaron4 grilleroChacar815)
      mancusadoAl53
        alGaga8
        (RajadoApunte718 casoMeodromo16)

    alacransar67 :: La77 (BoladaA329, BoladaA329)
    alacransar67 = do
        lechuzaArmarse91 <- sesentaChupamedias1
        nasun <- get
        case Map.lookup lechuzaArmarse91 (guitarreroLa16 nasun) of
          Nothing -> do
            cascada <- salaminMuerto47
            modify (\ nasun -> nasun {
              guitarreroLa16 =
                Map.insert lechuzaArmarse91
                           cascada
                           (guitarreroLa16 nasun)
            })
            return cascada
          Just cascada  -> return cascada
      where
        salaminMuerto47 :: La77 (BoladaA329, BoladaA329)
        salaminMuerto47 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          cocinadoCotorroCampaniya828
          musaRemancharCana9 <- sushetaGrata5
            lechuzaArmarse91
            (GuilaMejicaneada753 {
                falopaCaraculicoGatoYuta2 = lechuzaArmarse91,
                lanceroCanchereadaLleno4  = "string_ij",
                apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [MarcianoForro63 "java/lang/Object"]
                                (MarcianoForro63 "java/lang/String")
            })
          borderCaneroArrugueBomba540
          cincharAceiteDuro1 <- sushetaGrata5
            lechuzaArmarse91
            (GuilaMejicaneada753 {
                falopaCaraculicoGatoYuta2 = lechuzaArmarse91,
                lanceroCanchereadaLleno4  = "string_ji",
                apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [MarcianoForro63 "java/lang/String"]
                                (MarcianoForro63 "java/lang/Object")
            })
          return (musaRemancharCana9, cincharAceiteDuro1)

        cocinadoCotorroCampaniya828 :: La77 ()
        cocinadoCotorroCampaniya828 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                           "[Ljava/lang/Object;"
          ortoGilardoZapaba2 <- guiyaFilo866 lechuzaArmarse91
                                             "java/lang/StringBuilder"
          serpentinaTarroJamar57 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/StringBuilder",
                  lanceroCanchereadaLleno4  = "<init>",
                  apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
              })
          infanteTaradoRufinoRegadera3 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/StringBuilder",
                  lanceroCanchereadaLleno4  = "append",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [ACuloHumo5]
                                (MarcianoForro63 "java/lang/StringBuilder")
              })
          facaCachiporraEntrancarse1 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/StringBuilder",
                  lanceroCanchereadaLleno4  = "toString",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 []
                                (MarcianoForro63 "java/lang/String")
              })
          sonadoMopio8 <- guiyaFilo866 lechuzaArmarse91
                                       "java/lang/Integer"
          engramparAl02 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/Integer",
                  lanceroCanchereadaLleno4  = "intValue",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 []
                                (ZafarNp49)
              })
          despelote6
            (JoyaCajetiyaLa46 {
                sobradorManduqueChairaLa52 = lechuzaArmarse91,
                trotadoraBufonazoA038 = "string_ij",
                lunfardoRatearBarbijo6 = [LevantarRanchitos4],
                ensiyarseFideosCanastaOlivo =
                    AlfajiaAl22 [MarcianoForro63 "java/lang/Object"]
                                (MarcianoForro63 "java/lang/String"),
                pelotudoPesebreEscashato35  = [],
                jetatoreChusmajeMusa6 = Just [
                    Posta56 ortoGilardoZapaba2,
                    Banda08,
                    TrotadoraJeringa4 serpentinaTarroJamar57,
                    Ablandado024,
                    Quilombo4 "loop_start",
                    Cachirulo99,
                    MilongaBrodo10 sacadoSonatina15,
                    Bocon323 "loop_end",
                    TachoJoya70,
                    Cachirulo99,
                    GronchoMelon5 sacadoSonatina15,
                    NasoNeura288,
                    GigoloLa94,
                    GronchoMelon5 sonadoMopio8,
                    GuincheroSanata59 engramparAl02,
                    Baile63,
                    GuincheroSanata59 infanteTaradoRufinoRegadera3,
                    Murga82,
                    Cachirulo99,
                    GronchoMelon5 sacadoSonatina15,
                    QueserasDe00,
                    GigoloLa94,
                    Embroncarse0,
                    NaboLa26 "loop_start",
                    Quilombo4 "loop_end",
                    TachoJoya70,
                    GuincheroSanata59 facaCachiporraEntrancarse1,
                    Avivarse187
                ]
            })

        borderCaneroArrugueBomba540 :: La77 ()
        borderCaneroArrugueBomba540 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          atorranciaRaje0 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/Integer",
                  lanceroCanchereadaLleno4  = "valueOf",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [ZafarNp49]
                                (MarcianoForro63 "java/lang/Integer")
              })
          orejeroYantaQuia7 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/String",
                  lanceroCanchereadaLleno4  = "length",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [] ZafarNp49
              })
          mateFideos2 <-
            sushetaGrata5
              lechuzaArmarse91
              (GuilaMejicaneada753 {
                  falopaCaraculicoGatoYuta2 = "java/lang/String",
                  lanceroCanchereadaLleno4  = "charAt",
                  apuntadorAtorroCanaTragarCapo3 =
                    AlfajiaAl22 [ZafarNp49] ACuloHumo5
              })
          moldeJoda68 <- guiyaFilo866 lechuzaArmarse91
                                      "java/lang/Object"
          despelote6
            (JoyaCajetiyaLa46 {
                sobradorManduqueChairaLa52 = lechuzaArmarse91,
                trotadoraBufonazoA038 = "string_ji",
                lunfardoRatearBarbijo6 = [LevantarRanchitos4],
                ensiyarseFideosCanastaOlivo =
                    AlfajiaAl22 [MarcianoForro63 "java/lang/String"]
                                (MarcianoForro63 "java/lang/Object"),
                pelotudoPesebreEscashato35  = [],
                jetatoreChusmajeMusa6 =
                  Just $ [
                    NasoNeura288,
                    BrzarroEmpapelar atorranciaRaje0,
                    Ablandado024,
                    Cachirulo99,
                    GuincheroSanata59 orejeroYantaQuia7,
                    QueserasDe00,
                    TuboLa18,
                    DonaLadeado1,
                    Quilombo4 "loop_start",
                    Concurdaneo,
                    Fundido6 "loop_end",
                    FanguyosA416,
                    ChinaCucha980 moldeJoda68,
                    Banda08,
                    NasoNeura288,
                    Cachirulo99,
                    Concurdaneo,
                    GuincheroSanata59 mateFideos2,
                    BrzarroEmpapelar atorranciaRaje0,
                    CortinaDe59,
                    Banda08,
                    QueserasDe00,
                    TachoJoya70,
                    CortinaDe59,
                    Ablandado024,
                    Borrego9 2 (-1),
                    NaboLa26 "loop_start",
                    Quilombo4 "loop_end",
                    TachoJoya70,
                    Avivarse187
                ]
            })

    gorra :: Liga2 -> La77 [Vlm]

    gorra (Cuete45 fifi id gula) = do
        lechuzaArmarse91 <- sesentaChupamedias1
        jugadoCarucha284 <- guiyaFilo866 lechuzaArmarse91 "java/lang/Object"
        inflarse460 <- azoteaGaman4 (vichar8 fifi)
        raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
        sacado20 <- gorra gula
        caspera9 <- mapM budin4 fifi
        melonRafa44 <- zipWithM malerba5 [0..] caspera9
        return $
            inflarse460 ++
            [ChinaCucha980 jugadoCarucha284] ++
            concat melonRafa44 ++
            [MachazoYeca61 raspa537] ++
            sacado20
      where
        malerba5 :: Integer -> [Vlm] -> La77 [Vlm]
        malerba5 w tanoSire7 = do
          jai92 <- azoteaGaman4 w
          return (
            [Banda08] ++
            jai92 ++
            tanoSire7 ++
            [CortinaDe59]
           )

    gorra (Guarda4 w a49 id gula) = do
        lechuzaArmarse91 <- sesentaChupamedias1
        fane552 <- budin4 a49
        jai92 <- azoteaGaman4 w
        raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
        sacado20 <- gorra gula
        sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                         "[Ljava/lang/Object;"
        return (
            fane552 ++
            [GronchoMelon5 sacadoSonatina15] ++
            jai92 ++
            [GigoloLa94] ++
            [MachazoYeca61 raspa537] ++
            sacado20
          )

    gorra (Reo7 a49 fifi) = do
        fane552  <- budin4 a49
        caspera9 <- mapM budin4 fifi
        fatoSofaifaSanto7 <-
          sushetaGrata5
            esputzaVivo75
            (GuilaMejicaneada753 {
                falopaCaraculicoGatoYuta2 =
                    garparLancero6 esputzaVivo75 "Cont",
                lanceroCanchereadaLleno4  = "cont",
                apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
            })
        chabon978 <- bestiaGuardaGrela822 a49 (vichar8 caspera9)
        lechuzaArmarse91 <- sesentaChupamedias1
        limpiarReo67 <- mapM fuellePur66 chabon978
        gansadaRegaladoDe674 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 (-1)
        return $
            fane552 ++
            [MachazoYeca61 gansadaRegaladoDe674] ++
            concat (reverse caspera9) ++
            concat limpiarReo67 ++
            [Bulevar541]
      where
        fuellePur66 :: Integer -> La77 [Vlm]
        fuellePur66 rejilla95 = do
            lechuzaArmarse91 <- sesentaChupamedias1
            raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 rejilla95
            return [MachazoYeca61 raspa537]
        bestiaGuardaGrela822 :: Bacan8 -> Integer -> La77 [La4]
        bestiaGuardaGrela822 (Pingo7 j) l = do
          nasun <- get
          case Map.lookup j (boliyaFideosJoya18 nasun) of
            Just garuga -> return garuga
            Nothing     ->
              error ("(compileToJvm/getFunctionParamList: " ++
                     "etiqueta no definida)")
        bestiaGuardaGrela822 _          l = return [0..l - 1]

    gorra (Manu amuro gula) = do
        mapM_ beligeranciaRama3 amuro
        mapM_ pocilga43 amuro

        hacerFanguyosCable5 (garparLancero6 esputzaVivo75 "Start")
        gorra gula
      where
        beligeranciaRama3 :: TocadoTras10 -> La77 ()
        beligeranciaRama3 (Zarzo79 j garuga _) = do
          fatoPutear <-
            calarLinusa855 esputzaVivo75
              (GaloQuemadoLa84 {
                  manyamientoRanero581  = alcanciaChoto5 j,
                  fuleriaRajeRuaBombo11 = [LevantarRanchitos4],
                  astiyaEscobaCapoBoletaDe45 =
                      garparLancero6 esputzaVivo75 "Cont"
              })
          modify (\ nasun -> nasun {
            priseBartoleroBocho8 =
              Map.insert j fatoPutear
                         (priseBartoleroBocho8 nasun),
            boliyaFideosJoya18 =
              Map.insert j garuga
                         (boliyaFideosJoya18 nasun)
          })
        pocilga43 :: TocadoTras10 -> La77 ()
        pocilga43 (Zarzo79 j _ capo) = do
          hacerFanguyosCable5 (alcanciaChoto5 j)
          jetaNp75 <- gorra capo
          return ()
          despelote6
            (JoyaCajetiyaLa46 {
                sobradorManduqueChairaLa52 = alcanciaChoto5 j,
                trotadoraBufonazoA038 = "cont",
                lunfardoRatearBarbijo6 = [],
                ensiyarseFideosCanastaOlivo =
                    AlfajiaAl22 [] ChupeCucha,
                pelotudoPesebreEscashato35  = [],
                jetatoreChusmajeMusa6 = Just (
                  jetaNp75
                )
            })

    gorra (Patova8 a49 gamba) = do
        fane552 <- budin4 a49
        rata53 <- mapM (const abrochar934) gamba
        lastrar5 <- zipWithM morfarRula3 rata53 gamba

        lechuzaArmarse91 <- sesentaChupamedias1

        escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                          "java/lang/Integer"
        chamuyaFioloHinchadoMurga8 <-
          sushetaGrata5 lechuzaArmarse91 petisaEmpedarseMoscaMufa89

        return (
            fane552 ++

            [GronchoMelon5 escabiadoCupula66] ++
            [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
            [TrajeadoAsunto8 rata53] ++
            concat lastrar5
          )
      where
        morfarRula3 :: Enaje7 -> Liga2 -> La77 [Vlm]
        morfarRula3 culo1 gula = do
          sacado20 <- gorra gula
          return (
              [Quilombo4 culo1] ++
              sacado20
            )
    gorra (Marinante1 Salame5 [a49] [id] [gula]) =
      gorra (Cuete45 [a49] id gula)
    gorra (Marinante1 Falocrata [a49] [id] [gula]) =
      gorra (Guarda4 0 a49 id gula)
    gorra (Marinante1 OrejearA75 [de36, gay9] reaNp5 [gula]) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                       "[Ljava/lang/Object;"
      tenacear <- budin4 de36
      filoLa65 <- budin4 gay9
      opio7 <- azoteaGaman4 0
      truchoA184 <- rayeTeloEntubado9 reaNp5
      sacado20 <- gorra gula
      return (
          tenacear ++
          [GronchoMelon5 sacadoSonatina15] ++
          opio7 ++
          filoLa65 ++
          [CortinaDe59] ++
          truchoA184 ++
          sacado20
        )
    gorra (Marinante1 MaranfioForro [gil8, reo2] [id] [gula]) =
      canutoChichipioBrutalNp56 gil8 reo2 id gula [Otario95]
    gorra (Marinante1 MenesundaLa94 [gil8, reo2] [id] [gula]) = do
      canutoChichipioBrutalNp56 gil8 reo2 id gula [TuboLa18]
    gorra (Marinante1 ChanchoGorda [gil8, reo2] [] [guila, corno]) = do
      guitaPorroLunfoDescuerearAl79 gil8 reo2 guila corno CurroRaje84
    gorra (Marinante1 ApronteFija7 [gil8, reo2] [] [guila, corno]) = do
      guitaPorroLunfoDescuerearAl79 gil8 reo2 guila corno Shacador967
    gorra (Marinante1 Beberaje2 [a49] [] [guila, corno]) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                      "[Ljava/lang/Object;"
      culo1 <- abrochar934
      fane552 <- budin4 a49
      pintar129 <- gorra guila
      fifarLa55 <- gorra corno
      return (
          fane552 ++
          [MilongaBrodo10 sacadoSonatina15] ++
          [Bocon323 culo1] ++

          pintar129 ++
          [Quilombo4 culo1] ++

          fifarLa55
        )
    gorra (Marinante1 Rejilla [a49] [id] [gula]) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                      "[Ljava/lang/Object;"
      raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
      tarro9 <- abrochar934
      punga7 <- abrochar934
      opio7 <- azoteaGaman4 0
      fane552 <- budin4 a49
      sacado20 <- gorra gula
      return (
          fane552 ++
          [Banda08] ++
          [MilongaBrodo10 sacadoSonatina15] ++
          [Bocon323 tarro9] ++

            [GronchoMelon5 sacadoSonatina15] ++
            opio7 ++
            [GigoloLa94] ++
            [MachazoYeca61 raspa537] ++
          [NaboLa26 punga7] ++
          [Quilombo4 tarro9] ++

            [MachazoYeca61 raspa537] ++
          [Quilombo4 punga7] ++
          sacado20
        )
    gorra (Marinante1 JetearRagu1 [a49] reaNp5 [gula]) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      cafetearConejo <- perroBicho88 lechuzaArmarse91 fuleriaHorizontal278
      fane552 <- budin4 a49
      escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                        "java/lang/Integer"
      chamuyaFioloHinchadoMurga8 <-
        sushetaGrata5 lechuzaArmarse91 petisaEmpedarseMoscaMufa89
      catreraForradoPibe99 <-
        sushetaGrata5 lechuzaArmarse91 untarUpaMangoEncamotarsePingo4

      sacado20 <- gorra gula
      truchoA184 <- rayeTeloEntubado9 reaNp5
      return (
        [AfilarYapa220 cafetearConejo] ++
        fane552 ++
        [GronchoMelon5 escabiadoCupula66] ++
        [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
        [GuincheroSanata59 catreraForradoPibe99] ++
        truchoA184 ++
        sacado20
       )
    gorra (ChivoA70 (RelacheInfante53 LanguidoBanana breca2 trincar5 convoy8)
                    mino
                    id
                    gula) = do
        lechuzaArmarse91 <- sesentaChupamedias1
        mersada0       <- zipWithM clavarseNavo153 trincar5 mino
        sacado20       <- gorra gula
        (chapetonada513, servaHilo7)
                       <- ganchoPavaMate692 breca2
        rolingaCaduta9 <- biabaMorfetear518 convoy8
        raspa537       <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
        return (
            chapetonada513 ++
            concat mersada0 ++
            servaHilo7 ++
            rolingaCaduta9 ++
            [MachazoYeca61 raspa537] ++
            sacado20
          )
      where
        clavarseNavo153 :: Cancherear7 -> Bacan8 -> La77 [Vlm]
        clavarseNavo153 SeseraChe35 _ = return []
        clavarseNavo153 isa np4 = do
          biyuya7 <- budin4 np4
          alzarse7 <- pichichoApunte719 isa
          return (
              biyuya7 ++
              alzarse7
            )

        salameFumante4 :: [Navo1]
        salameFumante4 = map cascotePiraoBulto5 trincar5

        chupandina774 :: Navo1
        chupandina774 = cascotePiraoBulto5 convoy8

        cascotePiraoBulto5 :: Cancherear7 -> Navo1
        cascotePiraoBulto5 AsuntoCasaA56 = ZafarNp49
        cascotePiraoBulto5 RifadoRasca   = ACuloHumo5
        cascotePiraoBulto5 QuiaEnculado8 =
            MarcianoForro63 "java/lang/String"
        cascotePiraoBulto5 SeseraChe35   = ChupeCucha
        cascotePiraoBulto5 ComilonUpa6 = CabronAndante
        cascotePiraoBulto5 (MironAlce1 capiya6) =
          MarcianoForro63 capiya6
        cascotePiraoBulto5 _ =
          error "foreignTypeToJType: type not implemented"

        pichichoApunte719 :: Cancherear7 -> La77 [Vlm]
        pichichoApunte719 AsuntoCasaA56 = do
           lechuzaArmarse91 <- sesentaChupamedias1
           escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                        "java/lang/Integer"
           chamuyaFioloHinchadoMurga8 <-
             sushetaGrata5 lechuzaArmarse91 petisaEmpedarseMoscaMufa89
           return (
               [GronchoMelon5 escabiadoCupula66] ++
               [GuincheroSanata59 chamuyaFioloHinchadoMurga8]
             )
        pichichoApunte719 RifadoRasca = do
          pichichoApunte719 AsuntoCasaA56
        pichichoApunte719 QuiaEnculado8 = do
          (musaRemancharCana9, _) <- alacransar67
          return [BrzarroEmpapelar musaRemancharCana9]
        pichichoApunte719 SeseraChe35 =
          error "(compileToJvm: No se deberían visitar argumentos de tipo ())"
        pichichoApunte719 ComilonUpa6 = do
           lechuzaArmarse91 <- sesentaChupamedias1
           escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                        "java/lang/Integer"
           cortadaVisteTrompaJirafa0 <-
             sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02

           lunfaDeshilachadoBolazo4 <-
             sushetaGrata5 lechuzaArmarse91 curadoCaretaMaletaTrolo2

           opio7 <- azoteaGaman4 0
           cortadaVisteTrompaJirafa0 <-
             sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02
           return (
               [GronchoMelon5 escabiadoCupula66] ++
               opio7 ++
               [BrzarroEmpapelar cortadaVisteTrompaJirafa0] ++
               [GuincheroSanata59 lunfaDeshilachadoBolazo4]
             )
        pichichoApunte719 (MironAlce1 capiya6) = do
          lechuzaArmarse91 <- sesentaChupamedias1
          fatoPutear <- guiyaFilo866 lechuzaArmarse91 capiya6
          return [GronchoMelon5 fatoPutear]
        pichichoApunte719 _ =
          error "castInternalToJvm: Cast for type not implemented"

        biabaMorfetear518 :: Cancherear7 -> La77 [Vlm]
        biabaMorfetear518 AsuntoCasaA56 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          cortadaVisteTrompaJirafa0 <-
            sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02

          return [BrzarroEmpapelar cortadaVisteTrompaJirafa0]
        biabaMorfetear518 RifadoRasca = do
          lechuzaArmarse91 <- sesentaChupamedias1
          cortadaVisteTrompaJirafa0 <-
            sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02

          return [BrzarroEmpapelar cortadaVisteTrompaJirafa0]
        biabaMorfetear518 ComilonUpa6 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          cortadaVisteTrompaJirafa0 <-
             sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02

          fratachar <- abrochar934
          abrancar <- abrochar934
          opio7 <- azoteaGaman4 0
          masa8 <- azoteaGaman4 1
          return ([Bocon323 fratachar] ++
                  opio7 ++
                  [NaboLa26 abrancar] ++
                  [Quilombo4 fratachar] ++
                  masa8 ++
                  [Quilombo4 abrancar] ++
                  [BrzarroEmpapelar cortadaVisteTrompaJirafa0])
        biabaMorfetear518 SeseraChe35 = do
          lechuzaArmarse91 <- sesentaChupamedias1
          cortadaVisteTrompaJirafa0 <-
            sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02
          opio7 <- azoteaGaman4 0
          return $ opio7 ++
                   [BrzarroEmpapelar cortadaVisteTrompaJirafa0]
        biabaMorfetear518 QuiaEnculado8 = do
          (_, cincharAceiteDuro1) <- alacransar67
          return [BrzarroEmpapelar cincharAceiteDuro1]
        biabaMorfetear518 (MironAlce1 _) =
          return []

        guri80 :: Navo1 -> Bool
        guri80 ChupeCucha = True
        guri80 _          = False

        cocineroPifiarHembraje :: AlfajiaAl22
        cocineroPifiarHembraje =
          AlfajiaAl22
            (filter (not . guri80) salameFumante4) chupandina774

        monoFijaAchumado67 :: String
        monoFijaAchumado67 =
          case salameFumante4 of
            (MarcianoForro63 al7 : _) -> al7
            _ -> error (
                   "La declaración gringa del tipo de\n" ++
                   "    " ++ breca2 ++ "\n" ++
                   "debe tomar como primer parámetro un Pendorcho.")

        dragonearEntregarMambo0 :: AlfajiaAl22
        dragonearEntregarMambo0 =
          case salameFumante4 of
            (_ : mino) ->
              AlfajiaAl22 (filter (not . guri80) mino) chupandina774
            _ -> error (
                   "La declaración gringa del tipo de\n" ++
                   "    " ++ breca2 ++ "\n" ++
                   "debe tomar al menos un parámetro.")

        bomboJaulaGaita188 :: String
        bomboJaulaGaita188 =
          case chupandina774 of
            (MarcianoForro63 al7) -> al7
            _ -> error (
                   "La declaración gringa del tipo de\n" ++
                   "    " ++ breca2 ++ "\n" ++
                   "debe devolver un Pendorcho.")

        golpistaRajadoCaralisa3 :: AlfajiaAl22
        golpistaRajadoCaralisa3 =
          AlfajiaAl22
            (filter (not . guri80) salameFumante4) ChupeCucha

        ganchoPavaMate692 :: String -> La77 ([Vlm], [Vlm])
        ganchoPavaMate692 a39 =
          case words a39 of
            ["invokestatic", al7, de31] -> do
              lechuzaArmarse91 <- sesentaChupamedias1
              junarBuzarda5 <-
                sushetaGrata5 lechuzaArmarse91
                     (GuilaMejicaneada753 {
                          falopaCaraculicoGatoYuta2 = al7,
                          lanceroCanchereadaLleno4  = de31,
                          apuntadorAtorroCanaTragarCapo3 =
                            cocineroPifiarHembraje
                       })
              return ([], [BrzarroEmpapelar junarBuzarda5])
            ["getstatic", al7, opioOrto5] | null salameFumante4 -> do
              lechuzaArmarse91 <- sesentaChupamedias1
              alcaJunta3 <-
                perroBicho88 lechuzaArmarse91
                  (ChurrosGruyosPlomo {
                      pescadoGuitarrearChoclo5 = al7,
                      requintadoOrejudoVelas8 = opioOrto5,
                      najusarAtorraderoGuri17 = chupandina774
                  })
              return ([], [AfilarYapa220 alcaJunta3])
            [de31] | de31 /= "new" -> do
              lechuzaArmarse91 <- sesentaChupamedias1
              junarBuzarda5 <-
                sushetaGrata5 lechuzaArmarse91
                     (GuilaMejicaneada753 {
                          falopaCaraculicoGatoYuta2 =
                            monoFijaAchumado67,
                          lanceroCanchereadaLleno4  = de31,
                          apuntadorAtorroCanaTragarCapo3 =
                            dragonearEntregarMambo0
                       })
              return ([], [GuincheroSanata59 junarBuzarda5])
            ["new"] -> do
              lechuzaArmarse91 <- sesentaChupamedias1
              lompa136 <- guiyaFilo866 lechuzaArmarse91 bomboJaulaGaita188
              junarBuzarda5 <-
                sushetaGrata5 lechuzaArmarse91
                     (GuilaMejicaneada753 {
                          falopaCaraculicoGatoYuta2 =
                            bomboJaulaGaita188,
                          lanceroCanchereadaLleno4  = "<init>",
                          apuntadorAtorroCanaTragarCapo3 =
                            golpistaRajadoCaralisa3
                       })
              return ([Posta56 lompa136, Banda08],
                      [TrotadoraJeringa4 junarBuzarda5])
            _ -> error $
             "Declaraciones gringas posibles para la JVM:\n" ++
             "  \"invokestatic <nombre_de_la_clase> <nombre_del_método>\"\n" ++
             "  \"getstatic <nombre_de_la_clase> <nombre_del_campo>\"\n" ++
             "  \"<nombre_del_método>\"\n" ++
             "  \"new\"\n"
    gorra (ChivoA70 (RelacheInfante53 upa5 _ _ _) _ _ _) =
      error ("(compileToPy: lenguaje gringo no soportado: " ++
             show upa5 ++ ")")

    canutoChichipioBrutalNp56 :: Bacan8 -> Bacan8 -> La4 -> Liga2 ->
                                 [Vlm] -> La77 [Vlm]
    canutoChichipioBrutalNp56 gil8 reo2 id gula de26 = do
      lechuzaArmarse91 <- sesentaChupamedias1
      escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                        "java/lang/Integer"
      chamuyaFioloHinchadoMurga8 <-
        sushetaGrata5 lechuzaArmarse91 petisaEmpedarseMoscaMufa89
      cortadaVisteTrompaJirafa0 <-
        sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02
      raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
      sebon891 <- budin4 gil8
      titear46 <- budin4 reo2
      sacado20 <- gorra gula
      return (
          sebon891 ++
          [GronchoMelon5 escabiadoCupula66] ++
          [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
          titear46 ++
          [GronchoMelon5 escabiadoCupula66] ++
          [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
          de26 ++
          [BrzarroEmpapelar cortadaVisteTrompaJirafa0] ++
          [MachazoYeca61 raspa537] ++
          sacado20
        )

    guitaPorroLunfoDescuerearAl79 :: Bacan8 -> Bacan8 -> Liga2 -> Liga2 ->
                                     (Enaje7 -> Vlm) -> La77 [Vlm]
    guitaPorroLunfoDescuerearAl79 gil8 reo2 guila corno metido6 = do
      lechuzaArmarse91 <- sesentaChupamedias1
      escabiadoCupula66 <- guiyaFilo866 lechuzaArmarse91
                                        "java/lang/Integer"
      chamuyaFioloHinchadoMurga8 <-
        sushetaGrata5 lechuzaArmarse91 petisaEmpedarseMoscaMufa89
      sebon891 <- budin4 gil8
      titear46 <- budin4 reo2
      culo1 <- abrochar934
      pintar129 <- gorra guila
      fifarLa55 <- gorra corno
      return (
          sebon891 ++
          [GronchoMelon5 escabiadoCupula66] ++
          [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
          titear46 ++
          [GronchoMelon5 escabiadoCupula66] ++
          [GuincheroSanata59 chamuyaFioloHinchadoMurga8] ++
          [metido6 culo1] ++
          fifarLa55 ++
          [Quilombo4 culo1] ++
          pintar129
        )

    rayeTeloEntubado9 :: [La4] -> La77 [Vlm]
    rayeTeloEntubado9 [] = return []
    rayeTeloEntubado9 [id] = do
      lechuzaArmarse91 <- sesentaChupamedias1
      raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
      opio7 <- budin4 (RayadoAl1 (Ranero2 0))

      return (
          opio7 ++
          [MachazoYeca61 raspa537]
        )

    budin4 :: Bacan8 -> La77 [Vlm]
    budin4 (Pingo7 culo1) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      malevajeFatigar <- guiyaFilo866 lechuzaArmarse91
                                      (alcanciaChoto5 culo1)
      matufiaAtorrar1 <-
        sushetaGrata5
          lechuzaArmarse91
          (GuilaMejicaneada753 {
              falopaCaraculicoGatoYuta2 = alcanciaChoto5 culo1,
              lanceroCanchereadaLleno4  = "<init>",
              apuntadorAtorroCanaTragarCapo3 = AlfajiaAl22 [] ChupeCucha
          })
      return [
         Posta56 malevajeFatigar,
         Banda08,
         TrotadoraJeringa4 matufiaAtorrar1
       ]
    budin4 (Naso id) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
      return [
        AfilarYapa220 raspa537
       ]
    budin4 (RayadoAl1 (Ranero2 l)) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      cortadaVisteTrompaJirafa0 <-
        sushetaGrata5 lechuzaArmarse91 fumistaTacheroMilongaAl02
      cana0 <- azoteaGaman4 l
      return $
          cana0 ++
          [BrzarroEmpapelar cortadaVisteTrompaJirafa0]
    budin4 (RayadoAl1 (Pirar r)) =
      budin4 (RayadoAl1 (Ranero2 (fromIntegral (ord r))))
    budin4 (Opa0 w id) = do
      lechuzaArmarse91 <- sesentaChupamedias1
      jai92 <- azoteaGaman4 w
      raspa537 <- cafeLarvaGaruferoDe38 lechuzaArmarse91 id
      sacadoSonatina15 <- guiyaFilo866 lechuzaArmarse91
                                       "[Ljava/lang/Object;"
      return (
          [AfilarYapa220 raspa537] ++
          [GronchoMelon5 sacadoSonatina15] ++
          jai92 ++
          [GigoloLa94]
        )

    azoteaGaman4 :: Integer -> La77 [Vlm]
    azoteaGaman4 0 = return [NasoNeura288]
    azoteaGaman4 1 = return [QueserasDe00]
    azoteaGaman4 2 = return [FanguyosA416]
    azoteaGaman4 3 = return [SequeiraLa23]
    azoteaGaman4 4 = return [CocineroDe98]
    azoteaGaman4 5 = return [CartonCoco95]
    azoteaGaman4 l
      | 0 <= l && l < 2^7  = return [Chafalote5 l]
      | 0 <= l && l < 2^15 = return [Sonatina86 l]
      | 0 <= l && l < 2^31 = do
        lechuzaArmarse91 <- sesentaChupamedias1
        coco2 <- mancusadoAl53 lechuzaArmarse91 (LompaGulaSonado90 l)
        return [Chapas5 coco2]

    sesentaChupamedias1 :: La77 BurroRula2
    sesentaChupamedias1 = do
      nasun <- get
      return $ chupadinBasuriar550 nasun

    hacerFanguyosCable5 :: BurroRula2 -> La77 ()
    hacerFanguyosCable5 alGaga8 = do
      modify (\ nasun -> nasun {
          chupadinBasuriar550 = alGaga8
      })

    cafeLarvaGaruferoDe38 :: BurroRula2 -> Integer -> La77 BoladaA329
    cafeLarvaGaruferoDe38 alGaga8 macheteFuelle1 = do
      nasun <- get
      case Map.lookup macheteFuelle1 (bolazoPelpaPosta932 nasun) of
        Just _  -> return ()
        Nothing -> do
          anduma003 esputzaVivo75
              (ChupadoBuzarda4 {
                  bostaEsquilloCheAl12  = changuiMufa2,
                  ranunFaloperoFeites60 = [LevantarRanchitos4],
                  clavarseCoceoFato872  = MarcianoForro63
                                            "java/lang/Object",
                  sacudirChalaChotoFragotero = []
              })
          modify (\ nasun -> nasun {
              bolazoPelpaPosta932 =
                Map.insert macheteFuelle1 () (bolazoPelpaPosta932 nasun)
          })
      perroBicho88
          alGaga8
          (ChurrosGruyosPlomo {
              pescadoGuitarrearChoclo5 = esputzaVivo75,
              requintadoOrejudoVelas8 = changuiMufa2,
              najusarAtorraderoGuri17 =
                MarcianoForro63 "java/lang/Object"
          })
      where
        changuiMufa2 :: String
        changuiMufa2 = if macheteFuelle1 == -1
                        then "continuation"
                        else "reg" ++ show macheteFuelle1

tamboTarado3 :: CalorBate3 -> [Canoa5] -> String -> Liga2 -> String
tamboTarado3 acamala678 blanca6 esputzaVivo75 gula =
    al48 . reventar $ Al89 {
      libretoMamerto = esputzaVivo75,
      tacheriaNp04 = sonatinaFlash8 acamala678 blanca6 esputzaVivo75 gula
    }
  where
    al48 :: [Integer] -> String
    al48 = map (chr . fromIntegral)

