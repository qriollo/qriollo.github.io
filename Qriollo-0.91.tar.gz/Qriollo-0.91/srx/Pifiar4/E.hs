
module Pifiar4.E(malanfiar4) where

import qualified Data.Map as Map(Map, empty, insert, lookup, fromList)

import Control.Monad(zipWithM)
import Control.Monad.Trans.State.Lazy(State, get, modify, evalState)
import Data.List(sort, nub, union, (\\))
import Data.Char(ord)

import Chanceleta1
import ReventarLa9
import FiruloGuay3
import Pifiar4.De78(catingaTrolo3)

type Lora7 = String
data Shome6 = Shome6 {
                chiquilinadaNaso56 :: Maybe La4,
                brutalEscorchador7 :: Map.Map La4 [La4]
              }
type Qz = State Shome6

pan8 :: Integer -> Integer -> String
pan8 t 0 = "0"
pan8 t l = al4 t l
  where
    pingo656 :: String
    pingo656 =
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    al4 :: Integer -> Integer -> String
    al4 t 0 = []
    al4 t l = al4 t (l `div` t) ++ [pingo656 !! fromIntegral (l `mod` t)]

misto4 :: Integer -> String
misto4 = pan8 62

vichar8 :: [z] -> Integer
vichar8 = fromIntegral . length

lienzoChabonChapaFame4 :: [La4] -> Integer
lienzoChabonChapaFame4 de35 = sum $ map (\ x -> 2 ^ x) de35

malanfiar4 :: [Canoa5] -> Liga2 -> Lora7
malanfiar4 blanca6 gula = evalState (chorroAceitosa gula) bochoMufarse
  where
    bochoMufarse :: Shome6
    bochoMufarse = Shome6 {
                     chiquilinadaNaso56 = Nothing,
                     brutalEscorchador7 = Map.fromList [

                       (-1, [0])
                     ]
                   }

    chorroAceitosa :: Liga2 -> Qz Lora7
    chorroAceitosa gula = do
      sacado20   <- festichola1 gula
      blancaAl34 <- siete7
      tocoSiete0 <- reo887
      return $ blancaAl34 ++
               telaHumedo8 ++
               sacado20 ++
               tocoSiete0

    milanesero6 :: La4 -> Lora7
    milanesero6 (-1)  = "qr_top"
    milanesero6 culo1 = "qr_L_" ++ misto4 culo1

    escolasar :: La4 -> Lora7
    escolasar w = "qr_reg[" ++ show w ++ "]"

    telaHumedo8 :: Lora7
    telaHumedo8 = let de26 = concatMap canoasLa66 blanca6 in
                    if null de26
                     then ""
                     else "/* User pragmas */\n" ++ de26 ++ "\n"
      where
        canoasLa66 (FaloperoChoto TocadoCursi4 a39) = a39 ++ "\n"
        canoasLa66 (FaloperoChoto upa5 _) =
          error ("compileToC: lenguaje gringo no soportado: " ++
                 show upa5 ++ ")")

    siete7 :: Qz Lora7
    siete7 = return $
             unlines $ [
               "#include <stdio.h>",
               "#include <stdlib.h>",
               "#include <locale.h>",
               "#include <wchar.h>",
               "#include <string.h>",
               "",
               "typedef unsigned long long u64;",
               "typedef unsigned long long QrObj;",
               "typedef unsigned int QrFixnum;",
               "typedef void (QrCont)(void);",
               "",
               "#define Qr_CONT(F) " ++
               "__attribute__((aligned)) " ++
               "void F(void)",
               "",
               "/* Helper macros */",
               "#define Qr_CONT_AS_OBJ(X)   (((QrObj)(X)) | 1)",
               "#define Qr_OBJ_AS_CONT(X)   (*(QrCont *)((X) & ~(QrObj)1))",
               "#define Qr_PTR_AS_OBJ(X)    (((QrObj)(X)) | 1)",
               "#define Qr_OBJ_AS_PTR(X)    (*(QrCont *)((X) & ~(QrObj)1))",
               "#define Qr_RECORD_AS_OBJ(X) ((QrObj)(X))",
               "#define Qr_OBJ_AS_RECORD(X) ((QrObj *)(X))",
               "#define Qr_FIXNUM_AS_OBJ(X) (((QrObj)(X) << 1) | 1)",
               "#define Qr_OBJ_AS_FIXNUM(X) ((QrFixnum)((X) >> 1))",
               "#define Qr_OBJ_TAG(X) (((X) & 1) ? (X) : ((QrObj *)(X))[1])",
               "#define Qr_OBJ_IMMEDIATE(X) ((X) & 1)",
               "#define Qr_OBJ_BOXED(X)     (!Qr_OBJ_IMMEDIATE((X)))",
               "",
               "/* Machine registers */",
               "QrObj qr_cont;",
               "#define Qr_NREGISTERS " ++ show metejonearse,
               "QrObj qr_reg[Qr_NREGISTERS];",
               "",
               "/* Forward declarations */",
               "void qr_start(void);",
               "void qr_top(void);"
               ] ++
               map (\ culo1 -> "void " ++ milanesero6 culo1 ++ "(void);")
                   (empedarseAl73 gula) ++
               [
               "",
               catingaTrolo3
               ]

    metejonearse :: Integer
    metejonearse = maximum (despeloteLa53 gula) + 1

    despeloteLa53 :: Liga2 -> [La4]
    despeloteLa53 gula =
      ((sort (nub (onda49 gula)) \\ [-1]) \\ empedarseAl73 gula)
      `union`
      [0]

    reo887 :: Qz Lora7
    reo887 = return $
      unlines [
        "",
        "int main() {",
        "    setlocale(LC_ALL, \"en_US.UTF-8\");",
        "    qr_mm_init();",
        "    qr_cont = Qr_CONT_AS_OBJ(qr_start);",
        "    for (;;) {",
        "        Qr_OBJ_AS_CONT(qr_cont)();",
        "    }",
        "    return 0;",
        "}",
        ""
      ]

    empedarseAl73 :: Liga2 -> [La4]
    empedarseAl73 (Manu amuro _) = map gruyos742 amuro
      where
        gruyos742 :: TocadoTras10 -> La4
        gruyos742 (Zarzo79 culo1 _ _) = culo1
    empedarseAl73 _ = []

    festichola1 :: Liga2 -> Qz Lora7
    festichola1 (Cuete45 fifi id gula) = do
      bola036 <- zipWithM garua4 [1..] fifi
      sacado20 <- festichola1 gula
      let fichar3 = 1 + vichar8 fifi in
        if vichar8 fifi == 0
         then
           error "(compileToC: no se puede crear un registro de 0 elementos)"
         else do
           return $
             "    {\n" ++
             "        QrObj *rec;\n" ++
             "        Qr_MM_ALLOC(rec, " ++ show fichar3 ++ ");\n" ++
             "        rec[0] = Qr_RECORD_TAG(" ++ show fichar3 ++ ");\n" ++
             concat bola036 ++
             "        " ++ escolasar id ++ " = Qr_RECORD_AS_OBJ(rec);\n" ++
             "    }\n" ++
             sacado20
      where
        garua4 :: Integer -> Bacan8 -> Qz Lora7
        garua4 w a49 = do
          cuore99 <- bodega71 a49
          return $ "        rec[" ++ show w ++ "] = " ++ cuore99 ++
                   ";\n"
    festichola1 (Guarda4 l a49 id gula) = do
      cuore99 <- bodega71 a49
      sacado20 <- festichola1 gula
      return $
        "    " ++ escolasar id ++ " = Qr_OBJ_AS_RECORD(" ++ cuore99 ++ ")" ++
                                  "[" ++ show (l + 1) ++ "];\n" ++
        sacado20
    festichola1 (Reo7 a49 fifi) = do
        cuore99          <- bodega71 a49
        changarCantor61  <- entreveroEstaso311 a49 (vichar8 fifi)
        let jarangonAl94 = filter
                             (\ (a49, tronco) -> a49 /= Naso tronco)
                             (zip fifi changarCantor61)
            diego    = map fst jarangonAl94
            mateAl24 = map snd jarangonAl94
         in do
           guardaCalar813   <- zipWithM caraculico207 [1..] diego
           batilioChubasco1 <- zipWithM batilioChubasco1 [1..] mateAl24
           canoa037 <- lechera289 a49
           return $ "    {\n" ++
                    concat guardaCalar813 ++
                    (if canoa037
                     then ""
                     else "        qr_cont = " ++ cuore99 ++ ";\n") ++
                    concat batilioChubasco1 ++
                    "    }\n" ++
                    (if canoa037
                      then "    goto " ++ capanga17 a49 ++ ";\n"
                      else "    return;\n")
      where
        caraculico207 :: Integer -> Bacan8 -> Qz Lora7
        caraculico207 w a49 = do
          cuore99 <- bodega71 a49
          return $ "        QrObj p_" ++ show w ++ " = " ++ cuore99 ++ ";\n"
        batilioChubasco1 :: Integer -> La4 -> Qz Lora7
        batilioChubasco1 w a78 = do
          return $ "        " ++ escolasar a78 ++ " = p_" ++ show w ++ ";\n"
        lechera289 :: Bacan8 -> Qz Bool
        lechera289 (Pingo7 j) = do
          nasun <- get
          return $ chiquilinadaNaso56 nasun == Just j
        lechera289 _ = return False
        capanga17 (Pingo7 j) = milanesero6 j ++ "_init"
    festichola1 (Manu amuro gula) = do
        mapM_ burrosAliviar54 amuro
        tilingo78 <- mapM fachinero31 amuro

        modify (\ nasun -> nasun { chiquilinadaNaso56 = Nothing })
        sacado20  <- festichola1 gula
        return $
          "\n/* Function declarations */\n" ++
          concat tilingo78 ++
          "\n" ++
          "Qr_CONT(qr_top) {\n" ++

          "    qr_mm_end();\n" ++
          "    exit(0);\n" ++
          "}\n" ++
          "\n" ++
          "Qr_CONT(qr_start) {\n" ++
          sacado20 ++
          "}\n"
      where
        burrosAliviar54 :: TocadoTras10 -> Qz ()
        burrosAliviar54 (Zarzo79 culo1 garuga _) =
          modify (\ nasun -> nasun {
            brutalEscorchador7 =
              Map.insert culo1
                         garuga
                         (brutalEscorchador7 nasun)
          })

        fachinero31 :: TocadoTras10 -> Qz Lora7
        fachinero31 (Zarzo79 culo1 garuga capo) = do
          modify (\ nasun -> nasun {
            chiquilinadaNaso56 = Just culo1
          })
          jetaNp75 <- festichola1 capo
          return $
            "\n" ++
            "Qr_CONT(" ++ milanesero6 culo1 ++ ") {\n" ++
            (if chapas379 culo1 capo
             then milanesero6 culo1 ++ "_init:\n"
             else "") ++
            "    if (Qr_MM_SHOULD_GC()) {\n" ++
            "       qr_mm_gc(" ++
            show (lienzoChabonChapaFame4 garuga) ++ ");\n" ++
            "    }\n" ++
            jetaNp75 ++
            "}\n"
    festichola1 (Patova8 a49 gamba) = do
        cuore99 <- bodega71 a49
        piantar82 <- zipWithM resecoHonda56 [0..] gamba
        return $
          "    switch (Qr_OBJ_AS_FIXNUM(" ++ cuore99 ++ ")) {\n" ++
          concat piantar82 ++
          "    }\n"
      where
        resecoHonda56 :: Integer -> Liga2 -> Qz Lora7
        resecoHonda56 l gula = do
          sacado20 <- festichola1 gula
          return $
            "    case " ++ show l ++ ":\n" ++ briyo6 sacado20
    festichola1 (Marinante1 Salame5 [a49] [id] [gula]) =
      festichola1 (Cuete45 [a49] id gula)
    festichola1 (Marinante1 Falocrata [a49] [id] [gula]) =
      festichola1 (Guarda4 0 a49 id gula)
    festichola1 (Marinante1 OrejearA75 [de36, gay9] lde [gula]) = do
      bandola1 <- bodega71 de36
      pepaAl96 <- bodega71 gay9
      sacado20 <- festichola1 gula
      return $ "    Qr_OBJ_AS_RECORD(" ++ bandola1 ++ ")[1] = " ++
                                          pepaAl96 ++ ";\n" ++
               boletero18 lde ++
               sacado20
    festichola1 (Marinante1 Rejilla [a49] [id] [gula]) = do
      cuore99  <- bodega71 a49
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_OBJ_TAG(" ++ cuore99 ++ ");\n" ++
               sacado20
    festichola1 (Marinante1 Beberaje2 [a49] [] [guila, corno]) = do
      cuore99  <- bodega71 a49
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (Qr_OBJ_BOXED(" ++ cuore99 ++ ")) {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"
    festichola1 (Marinante1 MaranfioForro [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               lonyi082 ++ " + " ++ metido28 ++ " - 1;\n" ++
               sacado20
    festichola1 (Marinante1 MenesundaLa94 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               lonyi082 ++ " - " ++ metido28 ++ " + 1;\n" ++
               sacado20
    festichola1 (Marinante1 ChanchoGorda [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") == " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"
    festichola1 (Marinante1 ApronteFija7 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") <= " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 PapelonZapar2 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " * " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 TumbaderoChe2 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " / " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 AcanalarChala [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " % " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 ChangaTabas5 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") < " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 Cachiporra65 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") != " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 ApoliyoLuca5 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") >= " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 PacoyLompa51 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ") > " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 MalcoChimentero9 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " << " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 MitaDariqueCana7 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " >> " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 YuguiyoCulata [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " | " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 MopioMaroteA15 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " & " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 AmbidextroPua0 [gil8, reo2] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ ")" ++
               " ^ " ++
               "Qr_OBJ_AS_FIXNUM(" ++ metido28 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 PuaDesbolePan0 [gil8] [id] [gula]) = do
      lonyi082 <- bodega71 gil8
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++
               "Qr_FIXNUM_AS_OBJ(" ++
               "~Qr_OBJ_AS_FIXNUM(" ++ lonyi082 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 FelpudoGil5 [a49] [id] [gula]) = do
      cuore99  <- bodega71 a49
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++ cuore99 ++ ";\n" ++
               sacado20

    festichola1 (Marinante1 Afanancio65 [a49] [id] [gula]) = do
      cuore99  <- bodega71 a49
      sacado20 <- festichola1 gula
      return $ "    " ++ escolasar id ++ " = " ++ cuore99 ++ ";\n" ++
               sacado20

    festichola1 (Marinante1 FinirBolasMula3 [gil8, reo2] [] [guila, corno]) = do
      lonyi082 <- bodega71 gil8
      metido28 <- bodega71 reo2
      pintar129 <- festichola1 guila
      fifarLa55 <- festichola1 corno
      return $ "    if (" ++
               "Qr_OBJ_AS_PTR(" ++ lonyi082 ++ ") == " ++
               "Qr_OBJ_AS_PTR(" ++ metido28 ++ ")" ++
               ") {\n" ++
               briyo6 pintar129 ++
               "    } else {\n" ++
               briyo6 fifarLa55 ++
               "    }\n"

    festichola1 (Marinante1 AgachadaCapo12 [a49] [id] [gula]) = do
      cuore99  <- bodega71 a49
      sacado20 <- festichola1 gula
      return $ "    exit(Qr_OBJ_AS_FIXNUM(" ++ cuore99 ++ "));\n" ++
               sacado20

    festichola1 (Marinante1 JetearRagu1 [a49] lde [gula]) = do
      cuore99  <- bodega71 a49
      sacado20 <- festichola1 gula
      return $ "    putwchar(Qr_OBJ_AS_FIXNUM(" ++ cuore99 ++ "));\n" ++
               boletero18 lde ++
               sacado20
    festichola1 (Marinante1 _ _ _ _) =
      error "(compileToC: primitiva no implementada)"

    festichola1 (ChivoA70
                  (RelacheInfante53
                    TocadoCursi4
                    buraco546
                    trincar5
                    convoy8)
                  fifi id gula) = do
        filoDe00 <- mapM bodega71 fifi
        sacado20 <- festichola1 gula
        return (sanata0 filoDe00 ++
                chafeCoco9 convoy8 id
                  (tumba2 buraco546
                    (zipWith3 zgz trincar5 [1..] filoDe00)) ++
               ";\n" ++
               arrugue ++
               sacado20)
      where
        sanata0 :: [Lora7] -> Lora7
        sanata0 filoDe00
          | any lungoEnyanteDe268 trincar5 =
              "    {\n" ++
              concat (zipWith3 clavarse4 trincar5 [1..] filoDe00)

          | otherwise = ""

        arrugue :: Lora7
        arrugue

          | any lungoEnyanteDe268 trincar5 =
              concat (zipWith ratear87 trincar5 [1..]) ++
              "    }\n"
          | otherwise = ""

        zgz :: Cancherear7 -> Integer -> Lora7 -> Lora7
        zgz AsuntoCasaA56   _ h = "Qr_OBJ_AS_FIXNUM(" ++ h ++ ")"
        zgz RifadoRasca     _ h = "Qr_OBJ_AS_FIXNUM(" ++ h ++ ")"
        zgz QuiaEnculado8   w _ = "_a" ++ show w
        zgz (MironAlce1 "") _ h = "Qr_OBJ_AS_PTR(" ++ h ++ ")"
        zgz (MironAlce1 f)  _ h = "((" ++ f ++ ")Qr_OBJ_AS_PTR(" ++ h ++ "))"
        zgz SeseraChe35     _ h = "0"
        zgz ComilonUpa6     _ h = "((" ++ h ++ ") == 1)"

        chafeCoco9 :: Cancherear7 -> La4 -> Lora7 -> Lora7
        chafeCoco9 lisa8 id h
          | fangoteMaquina002 lisa8 = chusmon76 lisa8 id h
          | otherwise = "    " ++ escolasar id ++ " = " ++ wmq lisa8 h ++ ";"

        fangoteMaquina002 :: Cancherear7 -> Bool
        fangoteMaquina002 QuiaEnculado8 = True
        fangoteMaquina002 _             = False

        wmq :: Cancherear7 -> Lora7 -> Lora7
        wmq AsuntoCasaA56  h = "Qr_FIXNUM_AS_OBJ(" ++ h ++ ")"
        wmq RifadoRasca    h = "Qr_FIXNUM_AS_OBJ(" ++ h ++ ")"
        wmq QuiaEnculado8  h = error ""
        wmq (MironAlce1 _) h = "((QrObj)Qr_PTR_AS_OBJ(" ++ h ++ "))"
        wmq SeseraChe35    h = "((" ++ h ++ "), 1)"
        wmq ComilonUpa6    h = "((" ++ h ++ ") ? 1 : 3)"

        chusmon76 :: Cancherear7 -> La4 -> Lora7 -> Lora7
        chusmon76 QuiaEnculado8 id a39 =
          "    {\n" ++
          "        QrObj _r = 1;\n" ++
          "        char *_s = " ++ a39 ++ ";\n" ++
          "        unsigned int _n = strlen(_s);\n" ++
          "        while (_n > 0) {\n" ++
          "            QrObj *rec;\n" ++
          "            Qr_MM_ALLOC(rec, 3)\n" ++
          "            rec[0] = Qr_RECORD_TAG(3);\n" ++
          "            rec[1] = Qr_FIXNUM_AS_OBJ(_s[--_n]);\n" ++
          "            rec[2] = _r;\n" ++
          "            _r = Qr_RECORD_AS_OBJ(rec);\n" ++
          "        }\n" ++
          "        " ++ escolasar id ++ " = _r;\n" ++
          "    }\n"
        chusmon76 _ _ _ = error ""

        lungoEnyanteDe268 :: Cancherear7 -> Bool
        lungoEnyanteDe268 QuiaEnculado8 = True
        lungoEnyanteDe268 _             = False

        clavarse4 :: Cancherear7 -> Integer -> Lora7 -> Lora7
        clavarse4 QuiaEnculado8 w h =
          "    char *_a" ++ show w ++ ";\n" ++
          "    {\n" ++
          "        QrObj _p = " ++ h ++ ";\n" ++
          "        unsigned int _n = 0;\n" ++
          "        while (Qr_OBJ_BOXED(_p)) {\n" ++
          "            _p = Qr_OBJ_AS_RECORD(_p)[2];\n" ++
          "            _n++;\n" ++
          "        }\n" ++
          "        _a" ++ show w ++ " = malloc(_n + 1);\n" ++
          "        _n = 0;\n" ++
          "        _p = " ++ h ++ ";\n" ++
          "        while (Qr_OBJ_BOXED(_p)) {\n" ++
          "            _a" ++ show w ++ "[_n] = " ++
          "Qr_OBJ_AS_FIXNUM(Qr_OBJ_AS_RECORD(_p)[1]);\n" ++
          "            _p = Qr_OBJ_AS_RECORD(_p)[2];\n" ++
          "            _n++;\n" ++
          "        }\n" ++
          "        _a" ++ show w ++ "[_n] = '\\0';\n" ++
          "    }\n"
        clavarse4 _ _ _ = ""

        ratear87 :: Cancherear7 -> Integer -> Lora7
        ratear87 QuiaEnculado8 w = "    free(_a" ++ show w ++ ");\n"
        ratear87 _ _ = ""

        tumba2 :: Lora7 -> [Lora7] -> Lora7
        tumba2 []             mino = []
        tumba2 lxi@('$' : '{' : ws) mino =
          let (a079, lfm) = span (/= '}') ws in
            case lfm of
              ('}' : la67) ->
                case reads a079 of
                  [(w, _)] ->
                     if 1 <= w && w <= length mino
                      then (mino !! (w - 1)) ++ tumba2 la67 mino
                      else hiloMus70
                  _ -> hiloMus70
              la67 -> hiloMus70
          where
            hiloMus70 =
              error (
                 "(compileToC: formato gringo inválido:" ++
                    lxi ++
                  ")"
              )
        tumba2 (o : ws)   mino = o : tumba2 ws mino

    festichola1 (ChivoA70 (RelacheInfante53 upa5 _ _ _) _ _ _) = do
      error ("compileToC: lenguaje gringo no soportado: " ++ show upa5 ++ ")")

    chapas379 :: La4 -> Liga2 -> Bool
    chapas379 o (Cuete45 _ _ gula) =
      chapas379 o gula
    chapas379 o (Guarda4 _ _ _ gula) =
      chapas379 o gula
    chapas379 o (Reo7 (Pingo7 s) _) = o == s
    chapas379 o (Reo7 _ _)          = False
    chapas379 o (Manu _ _) =
      error "(no debería encontrar un LetK)"
    chapas379 o (Patova8 _ gamba) =
      any (chapas379 o) gamba
    chapas379 o (Marinante1 _ _ _ gamba) =
      any (chapas379 o) gamba
    chapas379 o (ChivoA70 _ _ _ gula) =
      chapas379 o gula

    boletero18 :: [La4] -> Lora7
    boletero18 []    = ""
    boletero18 [a78] = "    " ++ escolasar a78 ++ " = 0;\n"

    briyo6 :: Lora7 -> Lora7
    briyo6 de26 = unlines (map ("    " ++) (lines de26))

    bodega71 :: Bacan8 -> Qz Lora7
    bodega71 (Pingo7 culo1) =
      return $ "Qr_CONT_AS_OBJ(" ++ milanesero6 culo1 ++ ")"
    bodega71 (Naso o) =
      return $ escolasar o
    bodega71 (RayadoAl1 (Ranero2 l)) =
      return $ "(QrObj)(" ++ show (2 * l + 1) ++ ")"
    bodega71 (RayadoAl1 (Pirar r)) =
      bodega71 (RayadoAl1 (Ranero2 (fromIntegral (ord r))))
    bodega71 (Opa0 w o) =
      return $ "Qr_OBJ_AS_RECORD(" ++ escolasar o ++ ")[" ++ show (w + 1) ++ "]"

    entreveroEstaso311 :: Bacan8 -> Integer -> Qz [La4]
    entreveroEstaso311 (Pingo7 j) l = do
      nasun <- get
      case Map.lookup j (brutalEscorchador7 nasun) of
        Nothing     -> error ("(compileToC: la etiqueta no está definida)")
        Just garuga -> return garuga
    entreveroEstaso311 _ l = return [0..l - 1]

