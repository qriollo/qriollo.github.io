
{-# LANGUAGE FlexibleInstances #-}

module Pifiar4.Filado96(
        BurroRula2,
        ZarparFrio0,
        Al89(..),
        Cotin7(..),
        GaruarYuta3(..),
        BoladaA329(..),
        AlfajiaAl22(..),
        Navo1(..),
        PiponLa17(..),
        Caber1(..),
        Chabon8(..),
        RaneroDe29(..),
        CraneoQuia3(..),
        DragoneoTacho0(..),
        Pilchas485(..),
        Vlm(..),
        Enaje7,
        Al13, reventar,
    ) where

import qualified Data.Map as Map(
        Map, empty, lookup, insert, findWithDefault, toList, keys
    )
import Control.Monad(foldM, zipWithM_)
import Control.Monad.Trans.State.Lazy(State, get, put, modify, evalState)
import Data.Char(ord)
import Data.List((\\))
import Data.Bits((.|.))

type BurroRula2 = String
type ZarparFrio0 = String

data Al89 = Al89 {
              libretoMamerto :: BurroRula2,
              tacheriaNp04   :: [(BurroRula2, Cotin7)]
            }

data Cotin7 = Cotin7 {
                percantaAtorranta90 :: Integer,
                cagarLigaNaboNabo38 :: Integer,
                matrimoniadoBosta40 :: [PiponLa17],
                timbearCargarBombo  :: [GaruarYuta3],
                alumbrarMorlaco5    :: BoladaA329,
                gordaRongaApuntar   :: BoladaA329,
                enfocarCable5       :: [Caber1],
                fragoteroFula4      :: [Chabon8],
                brutalBarraHomo04   :: [RaneroDe29]
              }

data GaruarYuta3 = MatonearChucaJeta2
                 | LevantarRanchitos4
                 | RevienteCogerYigolo7

data BoladaA329 = BoladaA329 Integer
  deriving Eq

data AlfajiaAl22 = AlfajiaAl22 [Navo1] Navo1
  deriving Eq

data Navo1 = ChupeCucha
           | ZafarNp49
           | ACuloHumo5
           | CabronAndante
           | Testamento2 Navo1
           | MarcianoForro63 String
  deriving Eq

data PiponLa17 = RajadoApunte718       BoladaA329
               | ChorizoChivatoDiego4  AlfajiaAl22
               | OndaTorvelo206        Navo1
               | FortachoCaron4        String
               | GarquetaAlfajiaRafa19 BoladaA329 BoladaA329
               | FulmineCornoCuore27   BoladaA329 BoladaA329
               | ChairaArticuloDe33    BoladaA329 BoladaA329
               | LompaGulaSonado90     Integer
  deriving Eq

data Caber1 = Caber1 {
                tarumbaRati5       :: [GaruarYuta3],
                papelonAl33        :: BoladaA329,
                buchonOnda8        :: BoladaA329,
                barulloTimbear339  :: [RaneroDe29]
              }

data Chabon8 = Chabon8 {
                 garabitoGaga2      :: [GaruarYuta3],
                 entromparse8       :: BoladaA329,
                 garronTruaPilas036 :: BoladaA329,
                 anaanaCachuchaAl13 :: [RaneroDe29]
               }

data RaneroDe29 =
     ShucaJeringa795 {
       hincharLimosneroNp44 :: BoladaA329,
       purDeschavarEscorchador5 :: Integer,
       quiaHondaPiturrearRama701 :: Integer,
       diquePintadoRobreca2 :: [Vlm],
       corridoEscruchanteEnvinado :: [Pilchas485],
       bolicheChucaDopadoAlcancia :: [RaneroDe29]
     }
   | MatufieroMalerbaApunte3 {
       viyuyeraPetisaEspirajuseAl38 :: BoladaA329,
       shomeriaLancearOlfaMamboEnajarTayar4 :: [CraneoQuia3]
     }
   | CuchaChubascoChuchiBife2 {
       garabaMarrocoCulastroChivo734 :: BoladaA329,
       petarLinusoBulinAlacranearAtracarPua723 :: [DragoneoTacho0]
     }

data DragoneoTacho0 = BomboFarolesFaso913 Integer

data CraneoQuia3 =
     CraneoQuia3 {
       naranjaEncocorarseGagaLa09 :: BoladaA329,
       lavanderoFacaPelecheFelpa4 :: BoladaA329,
       alGloboTachometroCatrera87 :: BoladaA329,
       pechazoAbatatarseDiego3    :: [GaruarYuta3]
     }

data Pilchas485 = EstufarMujica93

type Enaje7 = String

data Vlm = Bulevar541
         | Avivarse187
         | Murga82
         | Banda08
         | Baile63
         | Posta56 BoladaA329
         | Chafalote5 Integer
         | Sonatina86 Integer
         | Cachirulo99
         | TachoJoya70
         | Abricola178
         | FebaBaile35
         | Embroncarse0
         | Ablandado024
         | Chacamento06
         | LungoLadiya8
         | NasoNeura288
         | QueserasDe00
         | FanguyosA416
         | SequeiraLa23
         | CocineroDe98
         | CartonCoco95
         | GuincheroSanata59 BoladaA329
         | TrotadoraJeringa4 BoladaA329
         | BrzarroEmpapelar  BoladaA329
         | AfilarYapa220 BoladaA329
         | MachazoYeca61 BoladaA329
         | ChinaCucha980 BoladaA329
         | GigoloLa94
         | CortinaDe59
         | GronchoMelon5 BoladaA329
         | Quilombo4 Enaje7
         | NaboLa26 Enaje7
         | Bocon323 Enaje7
         | Fundido6 Enaje7
         | CurroRaje84 Enaje7
         | Shacador967 Enaje7
         | MilongaBrodo10 BoladaA329
         | TrajeadoAsunto8 [Enaje7]
         | Chapas5 BoladaA329
         | MufaLola7 BoladaA329
         | Otario95
         | TuboLa18
         | Borrego9 Al13 Al13
         | DensoGuiye18
         | BuchonOnda31
         | DonaLadeado1
         | GevearGalo9
         | AmuradoLa55
         | Concurdaneo

type Al13 = Integer

class Concha55 z where
  reventar :: z -> [Al13]

mq :: Integer -> [Integer]
mq o | 0 <= o && o < 256 = [o]
     | otherwise = error "(Backend.Jvm.u1: byte fuera de rango)"

palo6 :: Char -> [Integer]
palo6 = mq . fromIntegral . ord

cv :: Integer -> [Integer]
cv o | 0 <= o && o < 256 ^ 2 = mq (o `div` 256) ++ mq (o `mod` 256)
     | otherwise = error "(Backend.Jvm.u2: word fuera de rango)"

np :: Integer -> [Integer]
np o | 0 <= o && o < 256 ^ 4 = cv (o `div` 256^2) ++ cv (o `mod` 256^2)
     | otherwise = error "(Backend.Jvm.u4: dword fuera de rango)"

la74 :: Integer -> [Integer]
la74 o | 0 <= o && o < 256 ^ 2 = mq (o `mod` 256) ++ mq (o `div` 256)
       | otherwise = error "(Backend.Jvm.u2le: word fuera de rango)"

de80 :: Integer -> [Integer]
de80 o | 0 <= o && o < 256 ^ 4 = la74 (o `mod` 256^2) ++ la74 (o `div` 256^2)
       | otherwise = error "(Backend.Jvm.u4le: dword fuera de rango)"

jonca :: String -> [Integer]
jonca = map (fromIntegral . ord)

instance Concha55 GaruarYuta3 where
  reventar MatonearChucaJeta2   = [0x00, 0x01]
  reventar LevantarRanchitos4   = [0x00, 0x08]
  reventar RevienteCogerYigolo7 = [0x04, 0x00]

vichar8 :: [z] -> Integer
vichar8 = fromIntegral . length

espor13 :: Integer -> [[Integer]] -> [Integer]
espor13 l =
  foldr (\ al18 reaNp5 ->
           if vichar8 al18 /= l
            then error "(Backend.Jvm.flagsOr: flags tienen longitud inválida)"
            else zipWith (.|.) al18 reaNp5)
        (take (fromIntegral l) (repeat 0))

instance Concha55 z => Concha55 [z] where
  reventar = concatMap reventar

instance Concha55 Al89 where
  reventar de72 =
      let (giranteLa87, yiradicta40) = cascada 0 apunteDe81
       in
         giranteLa87 ++
         yiradicta40 ++
         pato57 giranteLa87 yiradicta40
    where
      remarPibe3 :: Integer
      remarPibe3 = vichar8 apunteDe81

      apunteDe81 :: [(String, [Al13])]
      apunteDe81 = map (\ (alGaga8, al7) ->
                          (alGaga8 ++ ".class", reventar al7))
                       (tacheriaNp04 de72) ++
                   [("META-INF/MANIFEST.MF",
                     jonca (
                       "Manifest-Version: 1.0\n" ++
                       "Created-By: Qriollo\n" ++
                       "Main-Class: " ++ libretoMamerto de72 ++ "\n" ++
                       "\n"))]

      cascada :: Integer -> [(String, [Al13])] -> ([Al13], [Al13])
      cascada _   [] = ([], [])
      cascada mlb ((morena49, vovi1) : np81) =
        let (bombacha5, garqueta05) = coco2 mlb morena49 vovi1
            (manguear237, fayutoGaga9) = cascada (mlb + vichar8 bombacha5) np81
         in
          (bombacha5 ++ manguear237,
           garqueta05 ++ fayutoGaga9)

      coco2 :: Integer -> String -> [Al13] -> ([Al13], [Al13])
      coco2 zafar8 morena49 vovi1 = (bombacha5, garqueta05)
        where
          bombacha5 :: [Al13]
          bombacha5 =
            de80 0x04034b50 ++
            la74 0x000a ++
            la74 0x0000 ++
            la74 0x0000 ++
            la74 0x0000 ++
            la74 0x0000 ++
            de80 0 ++
            de80 (vichar8 vovi1) ++
            de80 (vichar8 vovi1) ++
            la74 (vichar8 morena49) ++
            la74 0 ++
            concatMap palo6 morena49 ++

            vovi1
          garqueta05 :: [Al13]
          garqueta05 =
            de80 0x02014b50 ++
            la74 0x000a ++
            la74 0x000a ++
            la74 0x0000 ++
            la74 0x0000 ++
            la74 0x0000 ++
            la74 0x0000 ++
            de80 0 ++
            de80 (vichar8 vovi1) ++
            de80 (vichar8 vovi1) ++
            la74 (vichar8 morena49) ++
            la74 0 ++
            la74 0 ++
            la74 0 ++
            la74 0 ++
            de80 0 ++
            de80 zafar8 ++
            concatMap palo6 morena49

      pato57 :: [Al13] -> [Al13] -> [Al13]
      pato57 giranteLa87 yiradicta40 =
        de80 0x06054b50 ++
        la74 0x00 ++
        la74 0x00 ++

        la74 remarPibe3 ++

        la74 remarPibe3 ++

        de80 (vichar8 yiradicta40) ++
        de80 (vichar8 giranteLa87) ++
        la74 0

instance Concha55 Cotin7 where
  reventar plomo2 =
    np 0xcafebabe ++
    cv (percantaAtorranta90 plomo2) ++
    cv (cagarLigaNaboNabo38 plomo2) ++

    cv (vichar8 (matrimoniadoBosta40 plomo2) + 1) ++
    reventar (matrimoniadoBosta40 plomo2) ++
    espor13 2 (map reventar (timbearCargarBombo plomo2)) ++
    reventar (alumbrarMorlaco5 plomo2) ++
    reventar (gordaRongaApuntar plomo2) ++

    cv 0 ++

    cv (vichar8 (enfocarCable5 plomo2)) ++
    reventar (enfocarCable5 plomo2) ++

    cv (vichar8 (fragoteroFula4 plomo2)) ++
    reventar (fragoteroFula4 plomo2) ++

    cv (vichar8 (brutalBarraHomo04 plomo2)) ++
    reventar (brutalBarraHomo04 plomo2)

mingaSabiondaBute8 :: AlfajiaAl22 -> String
mingaSabiondaBute8 (AlfajiaAl22 jm f) =
  "(" ++ concatMap cuorePilas19 jm ++ ")" ++ cuorePilas19 f

cuorePilas19 :: Navo1 -> String
cuorePilas19 ChupeCucha          = "V"
cuorePilas19 ZafarNp49           = "I"
cuorePilas19 ACuloHumo5          = "C"
cuorePilas19 CabronAndante       = "Z"
cuorePilas19 (Testamento2 f)     = "[" ++ cuorePilas19 f
cuorePilas19 (MarcianoForro63 b) = "L" ++ b ++ ";"

instance Concha55 BoladaA329 where
  reventar (BoladaA329 l) = cv l

instance Concha55 PiponLa17 where
  reventar (RajadoApunte718 coco2) =
    [0x07] ++
    reventar coco2
  reventar (OndaTorvelo206 isa) =
    reventar (FortachoCaron4 (cuorePilas19 isa))
  reventar (ChorizoChivatoDiego4 tirifilo06) =
    reventar (FortachoCaron4 (mingaSabiondaBute8 tirifilo06))
  reventar (FortachoCaron4 breca2) =
      [0x01] ++
      cv (vichar8 ep) ++
      ep
    where
      ep = jonca breca2
  reventar (GarquetaAlfajiaRafa19 quia isa) =
      [0x0c] ++
      reventar quia ++
      reventar isa
  reventar (FulmineCornoCuore27 al7 cabulear996) =
      [0x0a] ++
      reventar al7 ++
      reventar cabulear996
  reventar (ChairaArticuloDe33 al7 cabulear996) =
      [0x09] ++
      reventar al7 ++
      reventar cabulear996
  reventar (LompaGulaSonado90 l) =
      [0x03] ++
      np l

instance Concha55 Caber1 where
  reventar gay155 =
    espor13 2 (map reventar (tarumbaRati5 gay155)) ++
    reventar (papelonAl33 gay155) ++
    reventar (buchonOnda8 gay155) ++

    cv (vichar8 (barulloTimbear339 gay155)) ++
    reventar (barulloTimbear339 gay155)

instance Concha55 Chabon8 where
  reventar opio989 =
    espor13 2 (map reventar (garabitoGaga2 opio989)) ++
    reventar (entromparse8 opio989) ++
    reventar (garronTruaPilas036 opio989) ++

    cv (vichar8 (anaanaCachuchaAl13 opio989)) ++
    reventar (anaanaCachuchaAl13 opio989)

instance Concha55 RaneroDe29 where
  reventar mono9@(ShucaJeringa795 _ _ _ _ _ _) =
      reventar (hincharLimosneroNp44 mono9) ++
      np boletoAl14 ++
      cv (purDeschavarEscorchador5 mono9) ++
      cv (quiaHondaPiturrearRama701 mono9) ++
      np (vichar8 faso0) ++
      faso0 ++
      cv (vichar8 (corridoEscruchanteEnvinado mono9)) ++
      neuraBrodo6 ++
      cv (vichar8 (bolicheChucaDopadoAlcancia mono9)) ++
      roncarCana1
    where
      boletoAl14 :: Integer
      boletoAl14 =
        12 +
        vichar8 faso0 +
        vichar8 neuraBrodo6 +
        vichar8 roncarCana1

      faso0 :: [Al13]
      faso0 = runflero51 (diquePintadoRobreca2 mono9)

      neuraBrodo6 :: [Al13]
      neuraBrodo6 = reventar (corridoEscruchanteEnvinado mono9)

      roncarCana1 :: [Al13]
      roncarCana1 = reventar (bolicheChucaDopadoAlcancia mono9)
  reventar espiantarse11@(MatufieroMalerbaApunte3 _ _) =
      reventar (viyuyeraPetisaEspirajuseAl38 espiantarse11) ++
      np boletoAl14 ++
      cv (vichar8 (shomeriaLancearOlfaMamboEnajarTayar4 espiantarse11)) ++
      garabitoDepa4
    where
      boletoAl14 :: Integer
      boletoAl14 = 2 + vichar8 garabitoDepa4

      garabitoDepa4 :: [Al13]
      garabitoDepa4 =
        reventar (shomeriaLancearOlfaMamboEnajarTayar4 espiantarse11)
  reventar tanoEmbetunar0@(CuchaChubascoChuchiBife2 _ _) =
      reventar (garabaMarrocoCulastroChivo734 tanoEmbetunar0) ++
      np boletoAl14 ++
      cv (vichar8 (petarLinusoBulinAlacranearAtracarPua723 tanoEmbetunar0)) ++
      catarBombero966
    where
      boletoAl14 :: Integer
      boletoAl14 = 2 + vichar8 catarBombero966

      catarBombero966 :: [Al13]
      catarBombero966 =
        reventar (petarLinusoBulinAlacranearAtracarPua723 tanoEmbetunar0)

instance Concha55 DragoneoTacho0 where
  reventar (BomboFarolesFaso913 u)
    | 0 <= u && u < 64 = [u]

instance Concha55 CraneoQuia3 where
  reventar negrajeLa97 =
    reventar (naranjaEncocorarseGagaLa09 negrajeLa97) ++
    reventar (lavanderoFacaPelecheFelpa4 negrajeLa97) ++
    reventar (alGloboTachometroCatrera87 negrajeLa97) ++
    espor13 2 (map reventar (pechazoAbatatarseDiego3 negrajeLa97))

instance Concha55 Pilchas485 where
  reventar EstufarMujica93 =
    error "(Backend.Jvm: manejo de excepciones en la JVM no implementada aún)"

data Fuleria2 =
     Fuleria2 {
         circuladoFeites090 :: Integer,

         bostaRadichaGaruga21 :: Map.Map Enaje7 Integer,

         chimeneaGuapearPibe68 :: Map.Map Enaje7 [Tranquila5]
     }

data Tranquila5 =
     Tranquila5 {
         apronteBombero770      :: Integer,
         olivettiJetatoreEspor7 :: Integer,
         atorroBrutalFangote8   :: Integer
     }

type A110 = State Fuleria2

runflero51 :: [Vlm] -> [Al13]
runflero51 de26 =
    evalState (cocinar9 de26) bochoMufarse
  where
    bochoMufarse :: Fuleria2
    bochoMufarse = Fuleria2 {
                     circuladoFeites090 = 0,
                     bostaRadichaGaruga21 = Map.empty,
                     chimeneaGuapearPibe68 = Map.empty
                   }

    cocinar9 :: [Vlm] -> A110 [Al13]
    cocinar9 de26 = do
      reventar <- bochin76 de26
      nasun <- get
      () <- bodegonRafaCirculadoLuca8
      foldM tungoAlFajarAl85
            reventar
            (Map.toList (bostaRadichaGaruga21 nasun))

    bodegonRafaCirculadoLuca8 :: A110 ()
    bodegonRafaCirculadoLuca8 = do
      nasun <- get
      let my = Map.keys (chimeneaGuapearPibe68 nasun) \\
               Map.keys (bostaRadichaGaruga21 nasun)
       in
        if null my
         then return ()
         else error (
                "(opBytecode: " ++
                "el destino de las etiquetas de la JVM " ++ show my
                 ++ " no fue definido)")

    bochin76 :: [Vlm] -> A110 [Al13]
    bochin76 []         = return []
    bochin76 (gv : a43) = do
      svb  <- pibe974 gv
      modify (\ nasun -> nasun {
        circuladoFeites090 = circuladoFeites090 nasun +
                             fromIntegral (length svb)
      })
      al25 <- bochin76 a43
      return $ svb ++ al25

    pibe974 :: Vlm -> A110 [Al13]
    pibe974 (Chafalote5 l)
      | 0 <= l && l < 2^7   = return $ [0x10] ++ mq l
    pibe974 (Sonatina86 l)
      | 0 <= l && l < 2^15  = return $ [0x11] ++ cv l
    pibe974 Bulevar541      = return $ [0xb1]
    pibe974 Avivarse187     = return $ [0xb0]
    pibe974 Murga82         = return $ [0x57]
    pibe974 Banda08         = return $ [0x59]
    pibe974 Baile63         = return $ [0x92]
    pibe974 (Posta56 coco2) = return $ [0xbb] ++ reventar coco2
    pibe974 Cachirulo99     = return $ [0x2a]
    pibe974 TachoJoya70     = return $ [0x2b]
    pibe974 Abricola178     = return $ [0x2c]
    pibe974 FebaBaile35     = return $ [0x2d]
    pibe974 Embroncarse0    = return $ [0x4b]
    pibe974 Ablandado024    = return $ [0x4c]
    pibe974 Chacamento06    = return $ [0x4d]
    pibe974 LungoLadiya8    = return $ [0x4e]
    pibe974 (GuincheroSanata59 coco2) = return $ [0xb6] ++ reventar coco2
    pibe974 (TrotadoraJeringa4 coco2) = return $ [0xb7] ++ reventar coco2
    pibe974 (BrzarroEmpapelar coco2)  = return $ [0xb8] ++ reventar coco2
    pibe974 (AfilarYapa220 coco2) = return $ [0xb2] ++ reventar coco2
    pibe974 (MachazoYeca61 coco2) = return $ [0xb3] ++ reventar coco2
    pibe974 (ChinaCucha980 coco2) = return $ [0xbd] ++ reventar coco2
    pibe974 NasoNeura288 = return $ [0x03]
    pibe974 QueserasDe00 = return $ [0x04]
    pibe974 FanguyosA416 = return $ [0x05]
    pibe974 SequeiraLa23 = return $ [0x06]
    pibe974 CocineroDe98 = return $ [0x07]
    pibe974 CartonCoco95 = return $ [0x08]
    pibe974 GigoloLa94  = return $ [0x32]
    pibe974 CortinaDe59 = return $ [0x53]
    pibe974 (GronchoMelon5 coco2) = return $ [0xc0] ++ reventar coco2
    pibe974 (Quilombo4 culo1) = do
      modify (\ nasun -> nasun {
        bostaRadichaGaruga21 = Map.insert culo1 (circuladoFeites090 nasun)
                                                (bostaRadichaGaruga21 nasun)
      })
      return []
    pibe974 (NaboLa26 culo1) = do
      chirolaFuncheChanga570 culo1 1 2
      return $ [0xa7] ++ [0, 0]
    pibe974 (Bocon323 culo1) = do
      chirolaFuncheChanga570 culo1 1 2
      return $ [0x99] ++ [0, 0]
    pibe974 (Fundido6 culo1) = do
      chirolaFuncheChanga570 culo1 1 2
      return $ [0x9b] ++ [0, 0]
    pibe974 (CurroRaje84 culo1) = do
      chirolaFuncheChanga570 culo1 1 2
      return $ [0x9f] ++ [0, 0]
    pibe974 (Shacador967 culo1) = do
      chirolaFuncheChanga570 culo1 1 2
      return $ [0xa4] ++ [0, 0]
    pibe974 (MilongaBrodo10 coco2) =
      return $ [0xc1] ++ reventar coco2
    pibe974 (TrajeadoAsunto8 rata53) = do
      al0 <- bananaCachengue849
      let mersa75 = (4 - (al0 + 1) `mod` 4) `mod` 4
          zampar2 = take (fromIntegral mersa75) (repeat 0x0)
       in do
         zipWithM_
           (\ w culo1 -> chirolaFuncheChanga570
                           culo1
                           (1 + mersa75 + 12 + 4 * w)
                           4)
           [0..]
           rata53
         return $ [0xaa] ++
                  zampar2 ++

                  np (1 + mersa75 + 12 + 4 * fromIntegral (length rata53)) ++

                  np 0 ++

                  np (fromIntegral (length rata53) - 1) ++

                  take (4 * length rata53) (repeat 0x0)
    pibe974 (Chapas5 (BoladaA329 l))
      | 0 <= l && l < 256 = return $ [0x12] ++ mq l
      | otherwise         = return $ [0x13] ++ reventar (BoladaA329 l)
    pibe974 Otario95 = return [0x60]
    pibe974 TuboLa18 = return [0x64]
    pibe974 (Borrego9 g w) = return $ [0x84] ++ metido781 g ++ metido781 w
    pibe974 DensoGuiye18 = return [0x3b]
    pibe974 BuchonOnda31 = return [0x3c]
    pibe974 DonaLadeado1 = return [0x3d]
    pibe974 GevearGalo9 = return [0x1a]
    pibe974 AmuradoLa55 = return [0x1b]
    pibe974 Concurdaneo = return [0x1c]

    bananaCachengue849 :: A110 Integer
    bananaCachengue849 = do
      nasun <- get
      return $ circuladoFeites090 nasun

    chirolaFuncheChanga570 :: Enaje7 -> Integer -> Integer -> A110 ()
    chirolaFuncheChanga570 culo1 enchufado64 marengos8 = do
      jow <- bananaCachengue849
      garronearMarmote776
        culo1
        (Tranquila5 {
          apronteBombero770 = jow,
          olivettiJetatoreEspor7 = enchufado64,
          atorroBrutalFangote8 = marengos8
        })

    garronearMarmote776 :: Enaje7 -> Tranquila5 -> A110 ()
    garronearMarmote776 culo1 buqueAnaanaAl383 = do
      modify (\ nasun -> nasun {
        chimeneaGuapearPibe68 =
          Map.insert
            culo1
            (buqueAnaanaAl383 :
             Map.findWithDefault [] culo1 (chimeneaGuapearPibe68 nasun))
            (chimeneaGuapearPibe68 nasun)
      })

    tungoAlFajarAl85 :: [Al13] -> (Enaje7, Integer) -> A110 [Al13]
    tungoAlFajarAl85 de26 (culo1, zji) = do
        nasun <- get
        foldM lunfardologia6
              de26
              (Map.findWithDefault []
                  culo1
                  (chimeneaGuapearPibe68 nasun))
      where
        lunfardologia6 :: [Al13] -> Tranquila5 -> A110 [Al13]
        lunfardologia6 de26 paloMono9 =
          let jow = apronteBombero770 paloMono9
              trompa99 = jow + olivettiJetatoreEspor7 paloMono9
              marengos8 = atorroBrutalFangote8 paloMono9
              orto4 = zji - jow
              fajarse239 = fiaca4 marengos8 orto4
              (pibe3, mula5) = splitAt (fromIntegral trompa99) de26
           in return $ pibe3 ++
                       fajarse239 ++
                       drop (fromIntegral marengos8) mula5

    fiaca4 :: Integer -> Integer -> [Al13]
    fiaca4 2 l = nuriaA681 l
    fiaca4 4 l = lufania41 l

    metido781 :: Integer -> [Al13]
    metido781 u
      | u > 0 = mq u
      | u < 0 = mq (2 ^ 8 + u)

    nuriaA681 :: Integer -> [Al13]
    nuriaA681 u
      | u > 0 = cv u
      | u < 0 = cv (2 ^ 16 + u)

    lufania41 :: Integer -> [Al13]
    lufania41 u
      | u > 0 = np u
      | u < 0 = np (2 ^ 32 + u)

