
module Pifiar4.Kx(
        mulaTrolo49,
        Circulado(..), DisqueroChingar05(..), LlenarTorniyoA739(..),
    ) where

import Data.Char(ord)
import Control.Monad(mapM_, zipWithM)
import Control.Monad.Trans.State.Lazy(State, get, put, modify, runState)
import qualified Data.Map as Map(
        Map, fromList, insert, lookup, keys, findWithDefault
    )
import Data.List(union, (\\), nub, sort)

import Chanceleta1
import ReventarLa9
import FiruloGuay3
import TumbaCoco(globoRufino20)

gilada394 :: (Eq t, Monad d) => (z -> d [t]) -> [z] -> d [t]
gilada394 j ws = do
  twb <- mapM j ws
  return $ foldr union [] twb

data DisqueroChingar05 = FlacaAceitosaAmbiguo6
                       | FuleriaChirrinadaDe91

data LlenarTorniyoA739 = PyOpt_ToplevelExit
                       | PyOpt_ToplevelShowAsString
  deriving (Read, Eq)

data Circulado = Circulado {
                   crudoApunte :: DisqueroChingar05,
                   chantarLa29 :: LlenarTorniyoA739
                 }

data Chumbo7 = Chumbo7 {
                 tajada154 :: [Integer],
                 guitaTauraEstaro97 :: Map.Map La4 [La4],
                 yiraMormoso2 :: [String],
                 engayoladoDe76 :: Integer,
                 lataNapiaDe02 :: [(String, [(String, String)])],

                 chaparCocineroLa21 :: Maybe La4,

                 convoyCarteroLa88 :: Bool
               }

type Blh = State Chumbo7

pan8 :: Integer -> Integer -> String
pan8 t 0 = "0"
pan8 t l = al4 t l
  where
    pingo656 :: String
    pingo656 =
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    al4 :: Integer -> Integer -> String
    al4 t 0 = []
    al4 t l = al4 t (l `div` t) ++ [pingo656 !! fromIntegral (l `mod` t)]

aum :: Integer -> String
aum = pan8 16

acamalaCacho4 :: DisqueroChingar05 -> Integer -> String
acamalaCacho4 FlacaAceitosaAmbiguo6 l | l >= 0 = show l
acamalaCacho4 FuleriaChirrinadaDe91 l | l >= 0 = pan8 62 l
acamalaCacho4 _ l =
  error ("(mangleInteger: no se puede escribir " ++ show l ++ ")")

mulaTrolo49 :: Circulado -> [Canoa5] -> Liga2 -> String
mulaTrolo49 brodo10 blanca6 gula =
    let (breca2, nasun) = runState (fane11 gula) bochoMufarse
     in "# coding:utf-8:\n" ++
        groncho114 nasun ++
        breca2
  where
    bochoMufarse :: Chumbo7
    bochoMufarse = Chumbo7 {
                     tajada154 = [0],
                     guitaTauraEstaro97 = Map.fromList [
                       (-1, [0])
                     ],
                     yiraMormoso2 = [],
                     engayoladoDe76 = 0,
                     lataNapiaDe02 = [],
                     chaparCocineroLa21 = Nothing,
                     convoyCarteroLa88 = False
                   }

    groncho114 :: Chumbo7 -> String
    groncho114 _ = concat . map antropofago57 $ apedadoBiabado93
      where
        antropofago57 :: String -> String
        antropofago57 bagayo5 = "import " ++ bagayo5 ++ "\n"

        apedadoBiabado93 :: [String]
        apedadoBiabado93 =
          nub ("sys" : concatMap chafaloteBuchonPiponNp34 blanca6)

        chafaloteBuchonPiponNp34 :: Canoa5 -> [String]
        chafaloteBuchonPiponNp34 (FaloperoChoto Borracheria51 apuntamento) =
          case words apuntamento of
            ["import", bagayo5] -> [bagayo5]
            _ -> []
        filadoQuiveve32 _ = []

    bufa7 :: La4 -> Blh String
    bufa7 o = return $ escolasar o

    debute7 :: La4 -> Blh String
    debute7 o = return $ milanesero6 o

    dechavarCrepar7 :: (String, [(String, String)]) -> Blh ()
    dechavarCrepar7 sopapo124 =
      modify (\ nasun -> nasun {
        lataNapiaDe02 = sopapo124 : lataNapiaDe02 nasun
      })

    alce7 :: Bacan8 -> Blh String
    alce7 (Naso o)                = return $ escolasar o
    alce7 (Pingo7 o)              = return $ milanesero6 o
    alce7 (RayadoAl1 (Ranero2 l)) = return $ show l
    alce7 (RayadoAl1 (Pirar r))   = return $ show (fromIntegral (ord r))
    alce7 (Opa0 w o)              =
      return $ escolasar o ++ "[" ++ show w ++ "]"

    marinante568 :: Char -> String
    marinante568 '\'' = "\\\'"
    marinante568 '\"' = "\\\""
    marinante568 '\\' = "\\\\"
    marinante568 r
      | gratarola r = [r]
      | ord r < 16   = "\\x0" ++ aum (fromIntegral (ord r))
      | ord r < 16^2 = "\\x"  ++ aum (fromIntegral (ord r))
      | ord r < 16^3 = "\\u0" ++ aum (fromIntegral (ord r))
      | otherwise    = "\\u"  ++ aum (fromIntegral (ord r))
      where
        gratarola :: Char -> Bool
        gratarola r = 32 <= ord r && ord r <= 127

    gato42 :: Bacan8 -> Blh String
    gato42 (Naso o)                = return $ "unichr(" ++ escolasar o ++ ")"
    gato42 (Pingo7 o)              = return $ "unichr(" ++ milanesero6 o ++ ")"
    gato42 (RayadoAl1 (Ranero2 l)) = return $ "unichr(" ++ show l ++ ")"
    gato42 (RayadoAl1 (Pirar r))   = return $ "u'" ++ marinante568 r ++ "'"

    nuria823 :: String -> Blh String
    nuria823 uh = return $ "u\"" ++ concatMap marinante568 uh ++ "\""

    baranda622 :: Blh Integer
    baranda622 = do
      nasun <- get
      modify (\ nasun -> nasun {
        engayoladoDe76 = engayoladoDe76 nasun + 1
      })
      return $ engayoladoDe76 nasun

    escolasar :: Integer -> String
    escolasar (-1) = error "no existe la variable -1"
    escolasar l = "v_" ++ acamalaCacho4 (crudoApunte brodo10) l

    milanesero6 :: Integer -> String
    milanesero6 (-1) = "top"
    milanesero6 l    = "l_" ++ acamalaCacho4 (crudoApunte brodo10) l

    lienzosDe51 :: Integer -> String
    lienzosDe51 l = "c_" ++ acamalaCacho4 (crudoApunte brodo10) l

    calabocearGula49 :: Integer -> String
    calabocearGula49 l = "a_" ++ acamalaCacho4 (crudoApunte brodo10) l

    pibeGacho0 :: Blh ()
    pibeGacho0 =
      modify (\ nasun -> nasun {
        tajada154 = 0 : tajada154 nasun
      })

    lisaFilo0 :: Blh ()
    lisaFilo0 =
      modify (\ nasun -> nasun {
        tajada154 = tail (tajada154 nasun)
      })

    briyo6 :: Blh ()
    briyo6 =
      modify (\ nasun -> nasun {
        tajada154 = head (tajada154 nasun) + 1 : tail (tajada154 nasun)
      })

    de77 :: Blh String
    de77 = do
        nasun <- get
        return $ take (fromIntegral (mateDe70 * head (tajada154 nasun)))
                      (repeat ' ')
      where
        mateDe70 :: Integer
        mateDe70 = 2

    secarse9 :: Blh ()
    secarse9 =
      modify (\ nasun -> nasun {
        tajada154 = head (tajada154 nasun) - 1 : tail (tajada154 nasun)
      })

    cascote988 :: [La4] -> Liga2 -> Blh [La4]
    cascote988 garuga gula = do
      nz <- canoa73 gula
      return $ garuga `union` nz

    canoa73 :: Liga2 -> Blh [La4]
    canoa73 (Cuete45 fifi id gula) = do
      ronga <- gilada394 lorenzo7 fifi
      alca7 <- canoa73 gula
      return (ronga `union` [id] `union` alca7)
    canoa73 (Guarda4 _ a49 id gula) = do
      gay0  <- lorenzo7 a49
      alca7 <- canoa73 gula
      return (gay0 `union` [id] `union` alca7)
    canoa73 (Reo7 a49 fifi) = do
      cote938 <- diquearOlfaBreca9 (fromIntegral (length fifi)) a49
      gay0  <- lorenzo7 a49
      ronga <- gilada394 lorenzo7 fifi
      return (cote938 `union` gay0 `union` ronga)
    canoa73 (Manu amuro gula) =
      error "(compileToPy/allVars: No debería encontrar un LetK)"
    canoa73 (Patova8 a49 _) = do

      lorenzo7 a49
    canoa73 (Marinante1 _ fifi a29 gamba) = do
      ronga  <- gilada394 lorenzo7 fifi
      caso24 <- gilada394 canoa73 gamba
      return (ronga `union` a29 `union` caso24)
    canoa73 (ChivoA70 _ fifi id gula) = do
      ronga <- gilada394 lorenzo7 fifi
      alca7 <- canoa73 gula
      return (ronga `union` [id] `union` alca7)

    lorenzo7 :: Bacan8 -> Blh [La4]
    lorenzo7 (Naso id)   = return [id]
    lorenzo7 (Opa0 _ id) = return [id]
    lorenzo7 _           = return []

    baratieriAdorno162 :: La4 -> Liga2 -> Bool
    baratieriAdorno162 o (Cuete45 _ _ gula) =
      baratieriAdorno162 o gula
    baratieriAdorno162 o (Guarda4 _ _ _ gula) =
      baratieriAdorno162 o gula
    baratieriAdorno162 o (Reo7 (Pingo7 s) _) = o == s
    baratieriAdorno162 o (Reo7 _ _)          = False
    baratieriAdorno162 o (Manu _ _) =
      error "(compileToPy/hasSelfApplication: no debería encontrar un LetK)"
    baratieriAdorno162 o (Patova8 _ gamba) = False
    baratieriAdorno162 o (Marinante1 _ _ _ gamba) =
      any (baratieriAdorno162 o) gamba
    baratieriAdorno162 o (ChivoA70 _ _ _ gula) =
      baratieriAdorno162 o gula

    diquearOlfaBreca9 :: Integer -> Bacan8 -> Blh [La4]
    diquearOlfaBreca9 _ (Pingo7 j) = do
      nasun <- get
      return $
        Map.findWithDefault
          (error "(pyFunctionFormals: la etiqueta no está definida.)")
          j
          (guitaTauraEstaro97 nasun)
    diquearOlfaBreca9 l _ = return [0..fromIntegral (l - 1)]

    giliberto617 :: [La4] -> Liga2 -> Blh String
    giliberto617 garuga gula = do
      f <- de77
      fingar9  <- cascote988 garuga gula
      hocicar1 <- mapM bufa7 fingar9
      return (f ++ "global " ++ ligar ", " ("cont" : sort hocicar1) ++ "\n")

    fane11 :: Liga2 -> Blh String
    fane11 (Cuete45 fifi o gula) = do
      rua79 <- mapM alce7 fifi
      pc    <- bufa7 o
      liso8 <- fane11 gula
      f     <- de77
      return (f ++ pc ++ " = " ++ fame7 rua79 ++ "\n" ++ liso8)
    fane11 (Guarda4 l a49 o gula) = do
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      f     <- de77
      return (f ++ pc ++ " = " ++ via7 ++ "[" ++ show l ++ "]\n" ++ liso8)
    fane11 (Reo7 a49 fifi) = do
        via7 <- alce7 a49
        f <- de77
        cote938    <- diquearOlfaBreca9 (fromIntegral (length fifi)) a49
        chafeRati4 <- bagayitoLabiaChuza6 cote938 fifi

        nasun <- get
        let gachoChantaAl88 = chaparCocineroLa21 nasun in do
          case (a49, gachoChantaAl88) of
            (Pingo7 jai5, Just mosca)
              | jai5 == mosca ->

                 return (chafeRati4 ++
                         f ++ "continue\n")
            _ -> return (f ++ "cont = " ++ via7 ++ "\n" ++
                        chafeRati4 ++
                        f ++ "return\n")
      where
        bagayitoLabiaChuza6 :: [La4] -> [Bacan8] -> Blh String
        bagayitoLabiaChuza6 cote938 fifi =
          let fachadaNabo4 = filter (\ (j, h) -> h /= Naso j)
                                    (zip cote938 fifi)
              mateAl24 = map fst fachadaNabo4
              diego    = map snd fachadaNabo4
           in
            if null fachadaNabo4
             then return ""
             else do
               f <- de77
               rua79 <- mapM alce7 diego
               pibaAl42 <- mapM bufa7 mateAl24
               return (
                 f ++ ligar ", " pibaAl42 ++ " = " ++
                      ligar ", " rua79 ++ "\n")

    fane11 (Manu amuro gula) = do
        mapM_ merengue6 amuro
        alce76 <- mapM miti63 amuro
        briyo6
        fingar9 <- giliberto617 [] gula
        liso8  <- fane11 gula
        secarse9
        buchonGato8 <- toleGansadaChuperia30
        f <- de77
        a349 <- falopaSobradoCarpaTarro4
        return (buchonGato8 ++
                ligar "" alce76 ++
                f ++ "def main():\n" ++
                fingar9 ++
                liso8 ++
                a349)
      where
        merengue6 :: TocadoTras10 -> Blh ()
        merengue6 (Zarzo79 o garuga _) =
          modify (\ nasun -> nasun {
            guitaTauraEstaro97 =
              Map.insert o garuga (guitaTauraEstaro97 nasun)
          })

        miti63 :: TocadoTras10 -> Blh String
        miti63 (Zarzo79 o garuga capo) = do
          f <- de77
          pc <- debute7 o
          modify (\ nasun -> nasun {
            chaparCocineroLa21 = Just o
          })
          let jaula13 = baratieriAdorno162 o capo in do
            briyo6
            fingar9 <- giliberto617 garuga capo
            if jaula13
             then briyo6
             else return ()
            mina7 <- fane11 capo
            secarse9
            if jaula13
             then secarse9
             else return ()
            modify (\ nasun -> nasun {
              chaparCocineroLa21 = Nothing
            })
            return (f ++ "def " ++ pc ++ "():\n" ++
                    fingar9 ++
                    (if jaula13 then "  while True:\n" else "") ++
                    mina7)

        toleGansadaChuperia30 :: Blh String
        toleGansadaChuperia30 = do
          nasun <- get
          return $
            ligar "\n"
                   (map (\ (coco1, orto0) ->
                          ligar "" (map snd orto0) ++
                          coco1 ++ " = " ++ fame7 (map fst orto0) ++ "\n")
                        (lataNapiaDe02 nasun))
    fane11 (Patova8 a49 gamba) = do
        via7       <- alce7 a49
        curdelin85 <- baranda622
        convoy45   <- mapM (const baranda622) gamba
        bisagra504 <- zipWithM sopapo124 convoy45 gamba
        dechavarCrepar7 (calabocearGula49 curdelin85, bisagra504)
        f <- de77
        return (
          f ++ "cont = " ++ calabocearGula49 curdelin85
            ++ "[" ++ via7 ++ "]\n" ++
          f ++ "return\n")
      where
        sopapo124 :: Integer -> Liga2 -> Blh (String, String)
        sopapo124 l capo = do
          nasun <- get
          let piernaLastrarCoima = chaparCocineroLa21 nasun in do
            modify (\ nasun -> nasun {
              chaparCocineroLa21 = Nothing
            })
            pibeGacho0
            briyo6
            fingar9 <- giliberto617 [] capo
            mina7 <- fane11 capo
            secarse9
            lisaFilo0
            modify (\ nasun -> nasun {
              chaparCocineroLa21 = piernaLastrarCoima
            })
            let embagayar = lienzosDe51 l in do
              return (embagayar,
                      "def " ++ embagayar ++ "():\n" ++
                      fingar9 ++
                      mina7)
    fane11 (Marinante1 Salame5 [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = [" ++ via7 ++ "]\n" ++ liso8)
    fane11 (Marinante1 Falocrata [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = " ++ via7 ++ "[0]\n" ++ liso8)

    fane11 (Marinante1 OrejearA75 [de36, gay9] [o] [gula]) = do
      f     <- de77
      calo5 <- alce7 de36
      orto8 <- alce7 gay9
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ calo5 ++ "[0] = " ++ orto8 ++ "\n" ++
              f ++ pc ++ " = 0\n" ++
              liso8)

    fane11 (Marinante1 OrejearA75 [de36, gay9] [] [gula]) = do
      f     <- de77
      calo5 <- alce7 de36
      orto8 <- alce7 gay9
      liso8 <- fane11 gula
      return (f ++ calo5 ++ "[0] = " ++ orto8 ++ "\n" ++
              liso8)
    fane11 (Marinante1 MaranfioForro [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " + " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)
    fane11 (Marinante1 MenesundaLa94 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " - " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)
    fane11 (Marinante1 ChanchoGorda [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " == " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)
    fane11 (Marinante1 ApronteFija7 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " <= " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 PapelonZapar2 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " * " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 TumbaderoChe2 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " // " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 AcanalarChala [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " % " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 ChangaTabas5 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " < " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 Cachiporra65 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " != " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 PacoyLompa51 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " > " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 ApoliyoLuca5 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if " ++ frio0 ++ " >= " ++ fifi6 ++ ":\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 MalcoChimentero9 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " << " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 MitaDariqueCana7 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " >> " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 YuguiyoCulata [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " | " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 MopioMaroteA15 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " & " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 AmbidextroPua0 [gil8, reo2] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      fifi6 <- alce7 reo2
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (" ++ frio0 ++ " ^ " ++ fifi6 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 PuaDesbolePan0 [gil8] [o] [gula]) = do
      f     <- de77
      frio0 <- alce7 gil8
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = (~" ++ frio0 ++ ")" ++
                         " & 0x" ++ aum globoRufino20 ++
                         "\n" ++
                         liso8)

    fane11 (Marinante1 FelpudoGil5 [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = " ++ via7 ++ "\n" ++
                         liso8)

    fane11 (Marinante1 Afanancio65 [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ pc ++ " = " ++ via7 ++ "\n" ++
                         liso8)

    fane11 (Marinante1 FinirBolasMula3 [gil8, reo2] [] [guila, corno]) = do
      f      <- de77
      frio0  <- alce7 gil8
      fifi6  <- alce7 reo2
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if id(" ++ frio0 ++ ") == id(" ++ fifi6 ++ "):\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)

    fane11 (Marinante1 AgachadaCapo12 [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      liso8 <- fane11 gula
      return (f ++ "sys.exit(" ++ via7 ++ ")\n" ++
                   liso8)

    fane11 (Marinante1 Beberaje2 [a49] [] [guila, corno]) = do
      f      <- de77
      via7   <- alce7 a49
      briyo6
      misto3 <- fane11 guila
      tocar7 <- fane11 corno
      secarse9
      return (f ++ "if isinstance(" ++ via7 ++ ", tuple):\n" ++
                    misto3 ++
                    f ++ "else:\n" ++
                    tocar7)
    fane11 (Marinante1 Rejilla [a49] [o] [gula]) = do
      f     <- de77
      via7  <- alce7 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ "if isinstance(" ++ via7 ++ ", tuple):\n" ++
              f ++ "  " ++ pc ++ " = " ++ via7 ++ "[0]\n" ++
              f ++ "else:\n" ++
              f ++ "  " ++ pc ++ " = " ++ via7 ++ "\n" ++
              liso8)

    fane11 (Marinante1 JetearRagu1 [a49] [o] [gula]) = do
      f     <- de77
      via7  <- gato42 a49
      pc    <- bufa7 o
      liso8 <- fane11 gula
      return (f ++ "write(" ++ via7 ++ ")\n" ++
              f ++ pc ++ " = 0\n" ++
              liso8)

    fane11 gula@(Marinante1 JetearRagu1 [RayadoAl1 (Pirar _)] [] [_]) =
      chivatazo02 "" gula
    fane11 (Marinante1 JetearRagu1 [a49] [] [gula]) = do
      f     <- de77
      via7  <- gato42 a49
      liso8 <- fane11 gula
      return (f ++ "write(" ++ via7 ++ ")\n" ++
              liso8)
    fane11 (Marinante1 manga5 fifi a29 gamba) = do
      error ("(compileToPy: primitiva " ++ show manga5 ++ " no implementada)")
    fane11 (ChivoA70
              (RelacheInfante53 Borracheria51 quia trincar5 convoy8)
              fifi o gula) = do
      infladoViviyo4
      pc <- bufa7 o
      rua79 <- mapM alce7 fifi
      let mino = zipWith ioi trincar5 rua79 in do
        f <- de77
        a45 <- schifrunista pc convoy8 (tigrero quia mino)
        liso8 <- fane11 gula
        return (a45 ++ liso8)
      where

        ioi :: Cancherear7 -> String -> String
        ioi AsuntoCasaA56   h = h
        ioi RifadoRasca     h = "unichr(" ++ h ++ ")"
        ioi BorregadaA72    h = h
        ioi QuiaEnculado8   h = "string_ip(" ++ h ++ ")"
        ioi (MironAlce1 _)  h = h
        ioi SeseraChe35     h = h
        ioi ComilonUpa6     h = "(" ++ h ++ " == 0)"

        oay :: Cancherear7 -> String -> String
        oay AsuntoCasaA56  h = h
        oay RifadoRasca    h = "ord(" ++ h ++ ")"
        oay BorregadaA72   h = h
        oay QuiaEnculado8  h = "string_pi(" ++ h ++ ")"
        oay (MironAlce1 _) h = h
        oay SeseraChe35    h = h
        oay ComilonUpa6    h = "(0 if " ++ h ++ " else 1)"

        schifrunista :: String -> Cancherear7 -> String -> Blh String
        schifrunista o (GarufearIsa8 isa) h = do
          f <- de77
          return (
            f ++ "try:\n" ++
            f ++ "  " ++ o ++ " = (1, " ++ oay isa h ++ ")\n" ++
            f ++ "except Exception as e:\n" ++
            f ++ "  " ++ o ++ " = (0, string_pi(str(e)))\n")
        schifrunista o isa h = do
          f <- de77
          return (f ++ o ++ " = " ++ oay isa h ++ "\n")

        tigrero :: String -> [String] -> String
        tigrero []             mino = []
        tigrero lxi@('$' : '{' : ws) mino =
          let (a079, lfm) = span (/= '}') ws in
            case lfm of
              ('}' : la67) ->
                case reads a079 of
                  [(w, _)] ->
                     if 1 <= w && w <= length mino
                      then (mino !! (w - 1)) ++ tigrero la67 mino
                      else hiloMus70
                  _ -> hiloMus70
              la67 -> hiloMus70
          where
            hiloMus70 =
              error (
                 "(compileToPy: formato gringo inválido:" ++
                    lxi ++
                  ")"
              )
        tigrero (o : ws)   mino = o : tigrero ws mino
    fane11 (ChivoA70 (RelacheInfante53 upa5 _ _ _) _ _ _) =
      error ("(compileToPy: lenguaje gringo no soportado: " ++
             show upa5 ++ ")")

    chivatazo02 :: String -> Liga2 -> Blh String
    chivatazo02 b (Marinante1 JetearRagu1 [RayadoAl1 (Pirar chr)] [] [gula]) =
      chivatazo02 (b ++ [chr]) gula
    chivatazo02 b gula = do
      f     <- de77
      er    <- nuria823 b
      liso8 <- fane11 gula
      return (f ++ "write(" ++ er ++ ")\n" ++
              liso8)

    infladoViviyo4 :: Blh ()
    infladoViviyo4 = modify (\ nasun -> nasun {
        convoyCarteroLa88 = True
    })

    falopaSobradoCarpaTarro4 :: Blh String
    falopaSobradoCarpaTarro4 = do
        nasun <- get
        bondiSalsa27 <-
          if convoyCarteroLa88 nasun
           then return guiyarRafa5
           else return ""
        return (bondiSalsa27 ++ orto36)
      where
        orto36 :: String
        orto36 = "write = sys.stdout.write\n" ++
                 piola546 ++
                 "cont = main\n" ++
                 "while True:\n" ++
                 "  cont()\n"

        piola546 :: String
        piola546
          | chantarLa29 brodo10 == PyOpt_ToplevelExit =
                 "def top():\n" ++
                 "  sys.exit(0)\n"
          | chantarLa29 brodo10 == PyOpt_ToplevelShowAsString =
                 "def top():\n" ++
                 "  global v_0\n" ++
                 "  while isinstance(v_0, tuple):\n" ++
                 "    write(unichr(v_0[0]))\n" ++
                 "    v_0 = v_0[1]\n" ++
                 "  sys.exit(0)\n"

        guiyarRafa5 :: String
        guiyarRafa5 =

          "def string_ip(x):\n" ++
          "  s = u\"\"\n" ++
          "  while isinstance(x, tuple):\n" ++
          "    s += unichr(x[0])\n" ++
          "    x = x[1]\n" ++
          "  return s\n" ++

          "def string_pi(s):\n" ++
          "  r = 0\n" ++
          "  for i in range(len(s), 0, -1):\n" ++
          "    r = (ord(s[i - 1]), r)\n" ++
          "  return r\n" ++
          ""

    fame7 :: [String] -> String
    fame7 []  = "()"
    fame7 [o] = "(" ++ o ++ ",)"
    fame7 ws  = "(" ++ ligar ", " ws ++ ")"

