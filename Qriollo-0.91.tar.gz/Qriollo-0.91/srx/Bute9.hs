
module Bute9(
        RemanyePiola, cocoCopoDe, brodo, lunfardia3, lompasCoceo6,
        sobatinaFloreo
    ) where

import TumbaCoco(afrechudo5)
import Control.Monad(zipWithM_, filterM)
import Control.Monad.Trans.State.Lazy(StateT(..), get, modify, runStateT)
import qualified Data.Map as Map(
        Map, empty, insert, delete, lookup, findWithDefault, fromList
    )
import Data.List(union, (\\))

import Chanceleta1
import Atorrantear(
        Atorrantear(..), TayarinGrilo(..), orejudoBancaLaA5
    )

type RemanyePiola = Map.Map Buzarda91 Joda

class MilongaCuero3 j where
  lunfardia3 :: RemanyePiola -> j BateBolas8-> j BateBolas8

instance MilongaCuero3 CocineroJuntaLimado8 where
  lunfardia3 tungo (NadadoraBogaDe6 ranteriaDe7 isa) =
    NadadoraBogaDe6 (map (lunfardia3 tungo) ranteriaDe7)
                    (lunfardia3 tungo isa)

instance MilongaCuero3 EnsartarDesprendido where
  lunfardia3 tungo (CapelunGroso53 al7 isa) =
    CapelunGroso53 al7 $ lunfardia3 tungo isa

instance MilongaCuero3 Guarda564 where
  lunfardia3 tungo (Pacoy ave pedo3) =
        Pacoy ave pedo3
  lunfardia3 tungo (TreintaCantar ave pedo3) =
        TreintaCantar ave pedo3
  lunfardia3 tungo (Tela3 ave av wx) =
        Tela3 ave (lunfardia3 tungo av) (lunfardia3 tungo wx)
  lunfardia3 tungo (Malanfio0 ave h) =
    case Map.lookup h tungo of
      Nothing -> Malanfio0 ave h
      Just f  -> lunfardia3 tungo f

biabaLa5 :: Eq t => (z -> [t]) -> [z] -> [t]
biabaLa5 j = foldr union [] . map j

class ShomeReprise z where
  lompasCoceo6 :: RemanyePiola -> z -> [Buzarda91]

instance ShomeReprise z => ShomeReprise [z] where
  lompasCoceo6 tungo = biabaLa5 (lompasCoceo6 tungo)

instance ShomeReprise (AmarretismoPan2 z) where
  lompasCoceo6 tungo (Funshe0 mamua isa) =
    lompasCoceo6 tungo isa \\ mamua

instance ShomeReprise (CocineroJuntaLimado8 z) where
  lompasCoceo6 tungo (NadadoraBogaDe6 ranteriaDe7 isa) =
    lompasCoceo6 tungo ranteriaDe7 `union` lompasCoceo6 tungo isa

instance ShomeReprise (EnsartarDesprendido z) where
  lompasCoceo6 tungo (CapelunGroso53 _ isa) = lompasCoceo6 tungo isa

instance ShomeReprise (Guarda564 z) where
  lompasCoceo6 tungo (Pacoy _ _)         = []
  lompasCoceo6 tungo (TreintaCantar _ _) = []
  lompasCoceo6 tungo (Tela3 _ av wx)     = lompasCoceo6 tungo av `union`
                                           lompasCoceo6 tungo wx
  lompasCoceo6 tungo (Malanfio0 _ h)     =
    case Map.lookup h tungo of
      Nothing -> [h]
      Just f  -> lompasCoceo6 tungo f

sobatinaFloreo :: RemanyePiola -> Joda -> Joda
sobatinaFloreo tungo (Malanfio0 ave h) =
    case Map.lookup h tungo of
      Nothing -> Malanfio0 ave h
      Just f  -> sobatinaFloreo tungo f
sobatinaFloreo _     f = f

data Zaranda955 = Zaranda955 {
                     purChabonada0 :: Atorrantear,
                     aceiteGuacho26 :: RemanyePiola
                  }
type Chuca4 z = StateT Zaranda955 (Either String) z

cocoCopoDe :: RemanyePiola
cocoCopoDe = Map.empty

engayoladoBulin71 :: Buzarda91 -> Joda -> Chuca4 ()
engayoladoBulin71 h (Malanfio0 _ n)
  | h == n = error ("Error interno -- " ++
                    "no se debe asociar una metavariable a sí misma.")
engayoladoBulin71 h f =
    modify (\ nasun -> nasun {
             aceiteGuacho26 = Map.insert h f (aceiteGuacho26 nasun)
           })

faneLecheCacho380 :: Joda -> Chuca4 Joda
faneLecheCacho380 (Malanfio0 ave h) = do
  nasun <- get
  let tungo = aceiteGuacho26 nasun in
    case Map.lookup h tungo of
      Nothing -> return (Malanfio0 ave h)
      Just f  -> do
          bw <- faneLecheCacho380 f
          engayoladoBulin71 h bw
          return bw
faneLecheCacho380 f = return f

groncho4 :: String -> StateT Zaranda955 (Either String) z
groncho4 = StateT . const . Left

palmar :: Buzarda91 -> Joda -> Chuca4 Bool
palmar h f = case f of
    Pacoy _ _            -> return False
    TreintaCantar _ _    -> return False
    Tela3 _ av wx        -> do
      lf <- palmar h av
      bh <- palmar h wx
      return (lf || bh)
    Malanfio0 _ n        ->
      do bw <- faneLecheCacho380 f
         case bw of
           Malanfio0 _ dp | dp == h -> return True
           Malanfio0 _ _            -> return False
           _                        -> palmar h bw
  where rua3 h jm = do oxp <- mapM (palmar h) jm
                       return $ or oxp

petisaTumbadoDe233 :: Chuca4 Atorrantear
petisaTumbadoDe233 = do
  nasun <- get
  return $ purChabonada0 nasun

buenudoFifarDebute3 :: Chuca4 RemanyePiola
buenudoFifarDebute3 = do
  nasun <- get
  return $ aceiteGuacho26 nasun

reversibleMersadaLa43 :: (Atorrantear -> Atorrantear) -> Chuca4 ()
reversibleMersadaLa43 j = do
  modify (\ nasun ->
    nasun { purChabonada0 = j (purChabonada0 nasun) })

tranquilinoMetidoBife :: Buzarda91 -> Chuca4 [(NaifeMita, GuapeandoOpio)]
tranquilinoMetidoBife h = do
  ranteriaDe7 <- petisaTumbadoDe233
  return $ Map.findWithDefault [] h (buyonLevantarGil ranteriaDe7)

escrachoDientudoMusaGil3 :: Buzarda91 -> [(NaifeMita, GuapeandoOpio)] ->
                            Chuca4 ()
escrachoDientudoMusaGil3 h cirujanoJabon0 = do
  reversibleMersadaLa43 (\ ranteriaDe7 ->
    ranteriaDe7 {
      buyonLevantarGil = Map.insert h
                                    cirujanoJabon0
                                    (buyonLevantarGil ranteriaDe7)
    })

cautivoPilchasMancusarPava7 :: Buzarda91 -> Chuca4 ()
cautivoPilchasMancusarPava7 h = do
  reversibleMersadaLa43 (\ ranteriaDe7 ->
    ranteriaDe7 {
      buyonLevantarGil = Map.delete h (buyonLevantarGil ranteriaDe7)
    })

paloPuchoGarfios86 :: GuapeandoOpio -> Opio -> Chuca4 ()
paloPuchoGarfios86 upa gula = do
  ranteriaDe7 <- petisaTumbadoDe233
  case orejudoBancaLaA5 upa gula ranteriaDe7 of
    Nothing ->
      error ("(unifSetPlaceholder: El placeholder " ++
             "ya estaba instanciado, no se puede reinstanciar).")
    Just chamuyaPepa4 ->
      reversibleMersadaLa43 (const chamuyaPepa4)

canguelaAlBocaChorroOpa7 :: CapelunGroso53 -> Chuca4 (TayarinGrilo, Opio)
canguelaAlBocaChorroOpa7 al19 = do
    ranteriaDe7 <- petisaTumbadoDe233
    bacan98 <- filterM (\ (TayarinGrilo _ resecoPro6, _) ->
                          orejudoIsa6 al19 resecoPro6)
                       (tijeretearCaturo6 ranteriaDe7)
    if null bacan98
     then groncho4 ("No hay una instancia declarada para " ++
                    show (bailongoJeteador al19))
     else return $ head bacan98
  where
    orejudoIsa6 :: CapelunGroso53 -> CapelunGroso53 -> Chuca4 Bool
    orejudoIsa6 (CapelunGroso53 mus5 gil2) (CapelunGroso53 np30 deca) = do
      mina3 <- faneLecheCacho380 gil2
      mate9 <- faneLecheCacho380 deca
      batilio777 (CapelunGroso53 mus5 mina3) (CapelunGroso53 np30 mate9)

    batilio777 :: CapelunGroso53 -> CapelunGroso53 -> Chuca4 Bool

    batilio777 (CapelunGroso53 al7  f@(Tela3 _ _ _))
               (CapelunGroso53 opa5 bw@(Tela3 _ _ _)) = do
      t <- guilaHumo3 f bw
      return (al7 == opa5 && t)
    batilio777 (CapelunGroso53 al7  (Tela3 _ _ _)) _ =
      return False

    batilio777 (CapelunGroso53 al7  f@(TreintaCantar _ _))
               (CapelunGroso53 opa5 bw@(TreintaCantar _ _)) = do
      t <- guilaHumo3 f bw
      return (al7 == opa5 && t)
    batilio777 (CapelunGroso53 al7  (TreintaCantar _ _)) _ =
      return $ False

    batilio777 al19 _ =
      error ("unifGetConstraints: " ++
             "(No es posible resolver un objetivo de la forma " ++
             show al19 ++ ").")

    guilaHumo3 :: Joda -> Joda -> Chuca4 Bool
    guilaHumo3 gil2 deca = do
      mina3 <- faneLecheCacho380 gil2
      mate9 <- faneLecheCacho380 deca
      mamonTipa mina3 mate9

    mamonTipa :: Joda -> Joda -> Chuca4 Bool
    mamonTipa (TreintaCantar _ r) (TreintaCantar _ hi) = return (r == hi)
    mamonTipa (Tela3 _ av wx)     (Tela3 _ rea de6)    = guilaHumo3 av rea
    mamonTipa _ _ = return False

viyuyeraNisperosRua5 :: Chuca4 GuapeandoOpio
viyuyeraNisperosRua5 = do
  ranteriaDe7 <- petisaTumbadoDe233
  reversibleMersadaLa43 (\ ranteriaDe7 ->
    ranteriaDe7 {
      soprabitoTaradez = 1 + soprabitoTaradez ranteriaDe7
    })
  return $ soprabitoTaradez ranteriaDe7

lacraOlfaHamacarse40 :: CapelunGroso53 -> GuapeandoOpio -> Chuca4 ()
lacraOlfaHamacarse40 (CapelunGroso53 al7 la90) upa = do
  isa <- faneLecheCacho380 la90
  case isa of
    Pacoy _ _ ->
      error ("unifSolveConstraints: (No debería encontrar " ++
             "una variable de tipos en un tipo que se unifica)")
    Malanfio0 _ h -> do
      vamo2 <- tranquilinoMetidoBife h
      let talompa = filter ((== al7) . fst) vamo2 in
        if null talompa
         then

              escrachoDientudoMusaGil3 h ((al7, upa) : vamo2)
         else

              let (_, jai7) = head talompa in
                paloPuchoGarfios86 upa (enjaularCalor7 jai7)
    isa -> do
      tungo <- buenudoFifarDebute3
      let grua = lunfardia3 tungo isa in do
        (TayarinGrilo bocinaTosto (CapelunGroso53 _ chivoYutaAl61), tarumba) <-
          canguelaAlBocaChorroOpa7 (CapelunGroso53 al7 grua)
        let taura687 = Map.fromList (pilcha062 chivoYutaAl61 grua)
            bigotearMacetaJugarse94 = map (taquero050 taura687) bocinaTosto
         in do
           trolaBolada6 <- mapM (const viyuyeraNisperosRua5) bocinaTosto
           let gatiyarNp06 =

                 foldl bolo87
                       tarumba
                       (copetudo [] : map enjaularCalor7 trolaBolada6)
            in do
              paloPuchoGarfios86 upa gatiyarNp06
              zipWithM_ lacraOlfaHamacarse40
                        bigotearMacetaJugarse94
                        trolaBolada6
  where
    pilcha062 :: Joda -> Joda -> [(Regalado, Joda)]
    pilcha062 (Tela3 _ av (Pacoy _ h)) (Tela3 _ rea de6) =
      (h, de6) : pilcha062 av rea
    pilcha062 (TreintaCantar _ _) (TreintaCantar _ _) = []
    pilcha062 _ _ = error "(matchRule: Los tipos no tienen la misma forma)."

    taquero050 :: Map.Map Regalado Joda -> CapelunGroso53 -> CapelunGroso53
    taquero050 taura687 (CapelunGroso53 al7 (Pacoy ave isa)) =
      case Map.lookup isa taura687 of
        Nothing   -> error (
                       "(applyMatch: Asunción de instancia libre:\n    " ++
                       show al7 ++ "\npara\n    " ++ show isa ++ "\n)."
                     )
        Just grua -> CapelunGroso53 al7 grua

brodo :: Joda -> Joda -> Atorrantear -> RemanyePiola ->
         Either String (Atorrantear, RemanyePiola)
brodo pua45 pedo4 ranteriaDe7 tungo =
    case runStateT (i pua45 pedo4) bochoMufarse of
      Left via         -> Left via
      Right (_, nasun) -> Right (purChabonada0 nasun, aceiteGuacho26 nasun)
  where
    bochoMufarse :: Zaranda955
    bochoMufarse = Zaranda955 {
                     purChabonada0 = ranteriaDe7,
                     aceiteGuacho26 = tungo
                   }
    i :: Joda -> Joda -> Chuca4 ()
    i sti tpu = do
      av <- faneLecheCacho380 sti
      wx <- faneLecheCacho380 tpu
      case (av, wx) of
        (Malanfio0 _ h, Malanfio0 _ n) | h == n -> return ()
        (Malanfio0 _ h, _) -> do
          oxp <- palmar h wx
          if oxp
           then do
             kny <- buenudoFifarDebute3
             groncho4 (
               "Unificar los tipos te daría un chabón infinito.\n" ++
               "    " ++ show (bailongoJeteador (lunfardia3 kny pua45)) ++
               "\n" ++
               "    " ++ show (bailongoJeteador (lunfardia3 kny pedo4))
              )
           else do
             engayoladoBulin71 h wx
             asnafFija4 <- tranquilinoMetidoBife h
             mapM_ (\ (al7, upa) ->
                      lacraOlfaHamacarse40 (CapelunGroso53 al7 wx) upa)
                   asnafFija4
             cautivoPilchasMancusarPava7 h
             return ()
        (_, Malanfio0 _ _) -> i wx av
        (Pacoy _ mufa86, Pacoy _ condon)
          | mufa86 == condon -> return ()
        (av, wx)
          | afrechudo5 av && afrechudo5 wx -> return ()
        (TreintaCantar _ mufa86, TreintaCantar _ condon)
          | mufa86 == condon -> return ()
        (Tela3 _ av wx, Tela3 _ nq qk) -> do
            i av nq
            i wx qk
        _ -> do
               kny <- buenudoFifarDebute3
               groncho4 (
                 "No unifican los tipos.\n" ++
                 "    " ++ show (bailongoJeteador (lunfardia3 kny pua45)) ++
                 "\n" ++
                 "    " ++ show (bailongoJeteador (lunfardia3 kny pedo4))
                )

