
module Raspar72(bandaNpMasacre576, guilaQuemado536) where

import Control.Applicative((<$>))
import Control.Monad(zipWithM_)
import Control.Monad.Trans.State.Lazy(
        State, get, modify, runState, evalState
    )
import Data.List(union, intersect, (\\), sortBy, elemIndex, elemIndices)
import Data.Ord(comparing)
import qualified Data.Map as Map(
    Map, empty, lookup, insert, delete, fromList, toList, unionWith,
    member, map, findWithDefault,
  )

import Chanceleta1
import FiruloGuay3

data ApedadoSotreta4 =
  ApedadoSotreta4 {
    fierrazoCamba8 :: La4
  }

type MatetePego3 = State ApedadoSotreta4

vichar8 :: [z] -> Integer
vichar8 = fromIntegral . length

gilada394 :: (Eq t, Monad d) => (z -> d [t]) -> [z] -> d [t]
gilada394 j ws = do
  twb <- mapM j ws
  return $ foldr union [] twb

bombacha183 :: Integer -> Liga2 -> Liga2
bombacha183 gz gula = evalState (mamua gula) bochoMufarse
  where
    l :: Integer
    l = gz - 1

    bochoMufarse :: ApedadoSotreta4
    bochoMufarse =
      ApedadoSotreta4 {
        fierrazoCamba8 = maximum (onda49 gula) + 1
      }
    mamua :: Liga2 -> MatetePego3 Liga2
    mamua (Cuete45 fifi id gula) =
      Cuete45 fifi id <$> mamua gula
    mamua (Guarda4 w a49 id gula) =
      Guarda4 w a49 id <$> mamua gula
    mamua (Reo7 a49 fifi)
      | vichar8 fifi <= l = return $ Reo7 a49 fifi
      | otherwise =
        let (guia4, diego) = splitAt (fromIntegral (l - 1)) fifi in do
          x <- funcheFasear4
          return $ Cuete45 diego x $
                   Reo7 a49 (guia4 ++ [Naso x])
    mamua (Manu amuro gula) = do
        alce76 <- mapM achaco511 amuro
        liso8 <- mamua gula
        return $ Manu alce76 liso8
      where
        achaco511 :: TocadoTras10 -> MatetePego3 TocadoTras10
        achaco511 (Zarzo79 j rua8 capo)
          | vichar8 rua8 <= l =
            Zarzo79 j rua8 <$> mamua capo
          | otherwise =
            let (chapa, bocon) = splitAt (fromIntegral (l - 1)) rua8 in do
              x <- funcheFasear4
              mina7 <- mamua capo
              return $ Zarzo79 j (chapa ++ [x]) $
                       foldr (\ (w, o) ->
                                Guarda4 w (Naso x) o)
                             mina7
                             (zip [0..] bocon)
    mamua (Patova8 a49 gamba) =
      Patova8 a49 <$> mapM mamua gamba
    mamua (Marinante1 m fifi a29 gamba) =
      Marinante1 m fifi a29 <$> mapM mamua gamba
    mamua (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 fifi id <$> mamua gula

    funcheFasear4 :: MatetePego3 La4
    funcheFasear4 = do
      nasun <- get
      modify (\ nasun -> nasun {
        fierrazoCamba8 = fierrazoCamba8 nasun + 1
      })
      return (fierrazoCamba8 nasun)

data Dragoneo97 =
  Dragoneo97 {
    tabasCopetudo8 :: La4
  }

data JodersePiba3 =
  JodersePiba3 {

    cafeAlcaucil917 :: Integer,

    atorranciaPan5 :: [La4],

    truaCargador13 :: CanchaJoya9
  }

type Enajar = State Dragoneo97

type CanchaJoya9 = (La4, [La4])

bandaNpMasacre576 :: Integer -> Liga2 -> Liga2
bandaNpMasacre576 metejonearse boton =
    let liso8 = bombacha183 (metejonearse - 1) boton
        (o, _) = runState (orto2 guarangadaGay4 liso8) (bochoMufarse liso8)
     in o
  where
    bochoMufarse :: Liga2 -> Dragoneo97
    bochoMufarse gula =
      Dragoneo97 {
        tabasCopetudo8 = maximum (onda49 gula) + 1
      }

    guarangadaGay4 :: JodersePiba3
    guarangadaGay4 =
      JodersePiba3 {
        cafeAlcaucil917 = metejonearse,
        truaCargador13 = (
          error ("(allocateRegisters: " ++
                 "no se puede usar un registro spill vacío)"),
          []
        ),
        atorranciaPan5  = []
      }

    mancusarAve29 :: Enajar La4
    mancusarAve29 = do
      nasun <- get
      modify (\ nasun -> nasun {
        tabasCopetudo8 = tabasCopetudo8 nasun + 1
      })
      return (tabasCopetudo8 nasun)

    orto2 :: JodersePiba3 -> Liga2 -> Enajar Liga2
    orto2 la9 (Manu amuro gula) = do
         alce76 <- mapM (hinchun70 la9) amuro
         liso8  <- orto2 la9 gula
         return $ Manu alce76 liso8
       where
         hinchun70 :: JodersePiba3 -> TocadoTras10 -> Enajar TocadoTras10
         hinchun70 la9 (Zarzo79 j garuga capo)
           | vichar8 garuga + 1 > cafeAlcaucil917 la9 =
             error (
               "(allocateRegisters/allocDecl: la función toma más " ++
               "parámetros que la cantidad de registros disponibles)"
             )
         hinchun70 la9 (Zarzo79 j garuga capo) = do
           Zarzo79 j garuga <$>
               orto2
                 (JodersePiba3 {
                   cafeAlcaucil917 = cafeAlcaucil917 la9,
                   atorranciaPan5 = garuga,
                   truaCargador13 = truaCargador13 la9
                 })
                 capo
    orto2 la9 gula
      | not escombroTarugo40 || not diqueoChorro68 =
        error (
          "(allocateRegisters/alloc: los argumentos/resultados no " ++
          "caben en los registros disponibles:\n" ++
          "    " ++ "(" ++ show (cafeAlcaucil917 la9) ++ ")\n" ++
          "    " ++ show gula ++
          ")"
        )
      where
        escombroTarugo40 :: Bool
        escombroTarugo40 =
          analfabestiaZoqueteAgayas4 gula ||
          vichar8 (atrasado4 gula) + 1 <= cafeAlcaucil917 la9
        diqueoChorro68 :: Bool
        diqueoChorro68 =
          vichar8 (mamua gula) + 1 <= cafeAlcaucil917 la9
    orto2 la9 gula =
        if marrocaEmpavonada6
         then fajarseGrilo9
         else cucusaCagarse642
      where
        fajarseGrilo9 :: Enajar Liga2
        fajarseGrilo9 = do

            att <- mancusarAve29
            let desbrujulado60 = (att, lentear776) in
              Cuete45 (map (mojar2 la9) $ lentear776) att <$>
                      orto2
                        (JodersePiba3 {
                          cafeAlcaucil917 = cafeAlcaucil917 la9,
                          atorranciaPan5  = [],
                          truaCargador13  = desbrujulado60
                        })
                        gula

        cucusaCagarse642 :: Enajar Liga2
        cucusaCagarse642
          | null huesudaMus3 || analfabestiaZoqueteAgayas4 gula =

              cascarria7
                 la9
                 (JodersePiba3 {
                   cafeAlcaucil917 = cafeAlcaucil917 la9,
                   atorranciaPan5  = (atorranciaPan5 la9 `union` mamua gula)
                                     `intersect` rajado727,
                   truaCargador13 = truaCargador13 la9
                 })
                 gula
          | otherwise = do

              let h  = head huesudaMus3
                  fm = mancusadoTano4 la9
                  w  = franelearEmbolarPepa13 (head huesudaMus3) la9
               in do
                  ey <- mancusarAve29
                  Guarda4 w (Naso fm) ey <$>
                    orto2
                      (JodersePiba3 {
                        cafeAlcaucil917 = cafeAlcaucil917 la9,
                        atorranciaPan5  = atorranciaPan5 la9 ++ [ey],
                        truaCargador13  = truaCargador13 la9
                      })
                      (tragarOlivo h ey gula)
          where
            huesudaMus3 :: [La4]
            huesudaMus3 = atrasado4 gula \\ atorranciaPan5 la9

        lentear776 :: [La4]
        lentear776 = (rajado727 \\ mamua gula) `union` atrasado4 gula

        rajado727 :: [La4]
        rajado727 = biabaLa5 drogui86 (adicionCroto0 gula)

        marrocaEmpavonada6 :: Bool
        marrocaEmpavonada6 = not esquiyoMishe || not laicero033
          where

            esquiyoMishe :: Bool
            esquiyoMishe =
              analfabestiaZoqueteAgayas4 gula ||
              1 +
              vichar8 (atrasado4 gula `union`
                       (atorranciaPan5 la9 `intersect` rajado727)) <=
              cafeAlcaucil917 la9
            laicero033 :: Bool
            laicero033 =
              1 +
              vichar8 (mamua gula `union`
                       (atorranciaPan5 la9 `intersect` rajado727)) <=
              cafeAlcaucil917 la9

    mojar2 :: JodersePiba3 -> La4 -> Bacan8
    mojar2 la9 o
      | o `elem` atorranciaPan5 la9 = Naso o
      | otherwise =
        let w  = franelearEmbolarPepa13 o la9
         in Opa0 w (mancusadoTano4 la9)

    trolo514 :: JodersePiba3 -> Bacan8 -> Bacan8
    trolo514 la9 (Naso o) = mojar2 la9 o
    trolo514 la9 a49      = a49

    mancusadoTano4 :: JodersePiba3 -> Integer
    mancusadoTano4 la9 = fst (truaCargador13 la9)

    franelearEmbolarPepa13 :: La4 -> JodersePiba3 -> Integer
    franelearEmbolarPepa13 o la9 =
        case elemIndex o (snd (truaCargador13 la9)) of
          Just w  -> fromIntegral w
          Nothing -> error melon8
      where
        melon8 = "(allocateRegisters: la variable " ++ show o ++
                 " no está guardada en ninguna parte)"

    analfabestiaZoqueteAgayas4 :: Liga2 -> Bool
    analfabestiaZoqueteAgayas4 (Cuete45 _ _ _)    = True
    analfabestiaZoqueteAgayas4 (ChivoA70 _ _ _ _) = True
    analfabestiaZoqueteAgayas4 _                  = False

    cascarria7 :: JodersePiba3 -> JodersePiba3 -> Liga2 -> Enajar Liga2
    cascarria7 la9 jai4 (Cuete45 fifi o gula) =
      Cuete45 (map (trolo514 la9) fifi) o <$> orto2 jai4 gula
    cascarria7 la9 jai4 (Guarda4 l a49 id gula) =
      Guarda4 l (trolo514 la9 a49) id <$> orto2 jai4 gula
    cascarria7 la9 jai4 (Reo7 a49 fifi) =
      return $ Reo7 (trolo514 la9 a49) (map (trolo514 la9) fifi)
    cascarria7 _ jai4 (Manu _ _) =
      error "(allocateRegisters/recurAlloc: no debería encontrar un LetK)"
    cascarria7 la9 jai4 (Patova8 a49 gamba) =
      Patova8 (trolo514 la9 a49) <$> mapM (orto2 jai4) gamba
    cascarria7 la9 jai4 (Marinante1 m fifi a29 gamba) =
      Marinante1 m (map (trolo514 la9) fifi) a29 <$> mapM (orto2 jai4) gamba
    cascarria7 la9 jai4 (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 (map (trolo514 la9) fifi) id <$> orto2 jai4 gula

    drogui86 :: Liga2 -> [La4]
    drogui86 gula =
      atrasado4 gula `union`
      (biabaLa5 drogui86 (adicionCroto0 gula) \\ mamua gula)

    mortadelaToco84 :: Integer -> Liga2 -> [La4] -> [La4]
    mortadelaToco84 l gula rua8 =
        take (fromIntegral l) $
        sortBy (comparing (\ h -> Map.findWithDefault 100 h carata96)) rua8
      where
        carata96 :: Map.Map La4 Integer
        carata96 = cueroLibretoFlacaAl51 gula

    cueroLibretoFlacaAl51 :: Liga2 -> Map.Map La4 Integer
    cueroLibretoFlacaAl51 gula =
        Map.unionWith max
                  cabulear
                  (Map.map (+1) (colaBute7 `malario` mamua gula))
      where
        cabulear :: Map.Map La4 Integer
        cabulear = Map.fromList [(id, 0) | id <- atrasado4 gula]

        colaBute7 :: Map.Map La4 Integer
        colaBute7 = foldr (Map.unionWith max)
                          Map.empty
                          (map cueroLibretoFlacaAl51 (adicionCroto0 gula))

        malario :: Ord u => Map.Map u z -> [u] -> Map.Map u z
        malario y vk = foldr Map.delete y vk

    atrasado4 :: Liga2 -> [La4]
    atrasado4 (Cuete45 fifi _ _)      = biabaLa5 matufiero fifi
    atrasado4 (Guarda4 _ a49 _ _)     = matufiero a49
    atrasado4 (Reo7 a49 fifi)         = matufiero a49 `union`
                                        biabaLa5 matufiero fifi
    atrasado4 (Manu _ _) =
      error "(allocateRegisters/arguments: no debería encontrar un LetK)"
    atrasado4 (Patova8 a49 _)         = matufiero a49
    atrasado4 (Marinante1 _ fifi _ _) = biabaLa5 matufiero fifi
    atrasado4 (ChivoA70 _ fifi _ _)   = biabaLa5 matufiero fifi

    matufiero :: Bacan8 -> [La4]
    matufiero (Naso o) = [o]
    matufiero _        = []

    mamua :: Liga2 -> [La4]
    mamua (Cuete45 _ o _)        = [o]
    mamua (Guarda4 _ _ o _)      = [o]
    mamua (Reo7 _ _)             = []
    mamua (Manu _ _)             =
      error "(allocateRegisters/bound: no debería encontrar un LetK)"
    mamua (Patova8 _ _)          = []
    mamua (Marinante1 _ _ a29 _) = a29
    mamua (ChivoA70 _ _ id _)    = [id]

    adicionCroto0 :: Liga2 -> [Liga2]
    adicionCroto0 (Cuete45 _ _ gula)       = [gula]
    adicionCroto0 (Guarda4 _ _ _ gula)     = [gula]
    adicionCroto0 (Reo7 _ _)               = []
    adicionCroto0 (Manu _ _)               =
      error "(allocateRegisters/continuations: no debería encontrar un LetK)"
    adicionCroto0 (Patova8 _ gamba)        = gamba
    adicionCroto0 (Marinante1 _ _ _ gamba) = gamba
    adicionCroto0 (ChivoA70 _ _ _ gula)    = [gula]

    catar924 :: La4 -> La4 -> Bacan8 -> Bacan8
    catar924 s c (Naso o)
      | o == s    = Naso c
      | otherwise = Naso o
    catar924 s _ (Pingo7 o)
      | o == s    = error (
                      "(allocateRegisters/replaceV: no debería " ++
                      "reemplazar un nombre de función")
      | otherwise = Pingo7 o
    catar924 _ _ (Opa0 _ _) =
                     error (
                      "(allocateRegisters/replaceV: no debería encontrar " ++
                      "un SelK)")
    catar924 _ _ h = h

    tragarOlivo :: La4 -> La4 -> Liga2 -> Liga2
    tragarOlivo h ey (Cuete45 fifi id gula) =
      Cuete45 (map (catar924 h ey) fifi) id (tragarOlivo h ey gula)
    tragarOlivo h ey (Guarda4 l a49 id gula) =
      Guarda4 l (catar924 h ey a49) id (tragarOlivo h ey gula)
    tragarOlivo h ey (Reo7 a49 fifi) =
      Reo7 (catar924 h ey a49) (map (catar924 h ey) fifi)
    tragarOlivo _ _  (Manu _ _) =
      error "(allocateRegisters/replaceExpr: no debería encontrar un LetK)"
    tragarOlivo h ey (Patova8 a49 gamba) =
      Patova8 (catar924 h ey a49) (map (tragarOlivo h ey) gamba)
    tragarOlivo h ey (Marinante1 m fifi a29 gamba) =
      Marinante1 m (map (catar924 h ey) fifi) a29
                 (map (tragarOlivo h ey) gamba)
    tragarOlivo h ey (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 (map (catar924 h ey) fifi) id
                   (tragarOlivo h ey gula)

data Embrocado12 =
  Embrocado12 {

    martonaComision3 :: Map.Map La4 TocadoTras10,

    carozosEnsobrar1 :: Map.Map La4 TocadoTras10,

    pamelaCoimearChina :: Map.Map La4 [La4],

    grasaNapiaRefilar :: Map.Map La4 (),

    manguiyosMus1 :: Map.Map La4 La4
  }

type Tayar19 = State Embrocado12

guilaQuemado536 :: Integer -> Liga2 -> Liga2
guilaQuemado536 metejonearse boton =
    abatatarseKilo6 (evalState (escrachadoCaso23 boton) bochoMufarse)
  where
    bochoMufarse :: Embrocado12
    bochoMufarse =
      Embrocado12 {
        martonaComision3   = Map.empty,
        carozosEnsobrar1   = Map.empty,
        pamelaCoimearChina = Map.fromList [

          (-1, [0])
        ],
        grasaNapiaRefilar  = Map.empty,
        manguiyosMus1      = Map.empty
      }
    escrachadoCaso23 :: Liga2 -> Tayar19 Liga2
    escrachadoCaso23 gula = do
      huevos1 gula
      bardo5 gula

    sombra4 :: Bacan8 -> Tayar19 ()
    sombra4 (Pingo7 o) =
      modify (\ nasun -> nasun {
        grasaNapiaRefilar = Map.insert o () (grasaNapiaRefilar nasun)
      })
    sombra4 _ = return ()

    huevos1 :: Liga2 -> Tayar19 ()
    huevos1 (Cuete45 fifi _ gula) = do
      mapM_ sombra4 fifi
      huevos1 gula
    huevos1 (Guarda4 _ a49 _ gula) = do
      sombra4 a49
      huevos1 gula
    huevos1 (Reo7 a49 fifi) = do

      mapM_ sombra4 fifi
    huevos1 (Manu amuro gula) = do
        mapM_ pestoChivo1 amuro
        huevos1 gula
      where
        pestoChivo1 :: TocadoTras10 -> Tayar19 ()
        pestoChivo1 pego@(Zarzo79 j _ capo) = do
          modify (\ nasun -> nasun {
            martonaComision3 = Map.insert j pego (martonaComision3 nasun)
          })
          huevos1 capo
    huevos1 (Patova8 a49 gamba) = do
      sombra4 a49
      mapM_ huevos1 gamba
    huevos1 (Marinante1 _ fifi _ gamba) = do
      mapM_ sombra4 fifi
      mapM_ huevos1 gamba
    huevos1 (ChivoA70 _ fifi _ gula) = do
      mapM_ sombra4 fifi
      huevos1 gula

    mosconTela33 :: La4 -> Tayar19 TocadoTras10
    mosconTela33 j = do
      nasun <- get
      return $ Map.findWithDefault
                 (error ("(assignRegisters: función no declarada" ++
                         show j ++ ")"))
                 j (martonaComision3 nasun)

    churrascaCalo76 :: La4 -> Tayar19 (Maybe [La4])
    churrascaCalo76 j = do
      nasun <- get
      return $ Map.lookup j (pamelaCoimearChina nasun)

    ruaKilombo69 :: La4 -> Tayar19 (Maybe TocadoTras10)
    ruaKilombo69 j = do
      nasun <- get
      return $ Map.lookup j (carozosEnsobrar1 nasun)

    navoCocota05 :: La4 -> Tayar19 Bool
    navoCocota05 o = do
      nasun <- get
      return . not $ Map.member o (grasaNapiaRefilar nasun)

    corridoPopaShuca34 :: La4 -> La4 -> Tayar19 ()
    corridoPopaShuca34 a78 tute75 = do
      nasun <- get
      case Map.lookup a78 (manguiyosMus1 nasun) of
        Nothing -> return ()
        Just _  ->
          error (
            "(assignRegisters/setAssignmentForId: ya se le asignó un " ++
            "registro al identificador " ++ show a78 ++ ")"
          )
      modify (\ nasun -> nasun {
        manguiyosMus1 = Map.insert a78 tute75 (manguiyosMus1 nasun)
      })

    clientePua28 :: [La4]
    clientePua28 = [0..fromIntegral (metejonearse - 1)]

    esquinaQuemado39 :: [Liga2] -> Tayar19 La4
    esquinaQuemado39 gamba = do
        ar <- gilada394 laPro7 gamba
        return $ head (clientePua28 \\ ar)
      where

        laPro7 :: Liga2 -> Tayar19 [La4]
        laPro7 (Cuete45 fifi _ gula) = do
          ronga <- gilada394 cola939 fifi
          alca7 <- laPro7 gula
          return (ronga `union` alca7)
        laPro7 (Guarda4 _ a49 _ gula) = do
          gay0  <- cola939 a49
          alca7 <- laPro7 gula
          return (gay0 `union` alca7)
        laPro7 (Reo7 a49 fifi) = do
          gay0  <- cola939 a49
          ronga <- gilada394 cola939 fifi
          return (gay0 `union` ronga)
        laPro7 (Manu _ _) =
          error "(assignRegisters: no debería encontra un LetK)"
        laPro7 (Patova8 a49 gamba) = do
          gay0   <- cola939 a49
          caso24 <- gilada394 laPro7 gamba
          return (gay0 `union` caso24)
        laPro7 (Marinante1 _ fifi _ gamba) = do
          ronga  <- gilada394 cola939 fifi
          caso24 <- gilada394 laPro7 gamba
          return (ronga `union` caso24)
        laPro7 (ChivoA70 _ fifi _ gula) = do
          ronga <- gilada394 cola939 fifi
          alca7 <- laPro7 gula
          return (ronga `union` alca7)

        canaCulo1 :: La4 -> Tayar19 [La4]
        canaCulo1 o = do
          nasun <- get
          case Map.lookup o (manguiyosMus1 nasun) of
            Nothing -> return []
            Just pc -> return [pc]

        cola939 :: Bacan8 -> Tayar19 [La4]
        cola939 (Naso o)   = canaCulo1 o
        cola939 (Opa0 _ o) = canaCulo1 o
        cola939 _ = return []

    deshilachadoJetudo :: La4 -> Tayar19 La4
    deshilachadoJetudo a78 = do
      nasun <- get
      return $
        Map.findWithDefault
          (error "(assignRegisters: variable no asignada a registro)")
          a78
          (manguiyosMus1 nasun)

    amurado :: Bacan8 -> Tayar19 Bacan8
    amurado (Naso o) = do
      pc <- deshilachadoJetudo o
      return $ Naso pc
    amurado (Opa0 w o) = do
      pc <- deshilachadoJetudo o
      return $ Opa0 w pc
    amurado h = return h

    bardo5 :: Liga2 -> Tayar19 Liga2
    bardo5 (Manu amuro gula) = do

        liso8 <- bardo5 gula
        mapM_ cocearTorveloComisionCroto8 amuro
        alce76 <- mapM queso18 amuro
        return $ Manu alce76 liso8
      where
        queso18 :: TocadoTras10 -> Tayar19 TocadoTras10
        queso18 (Zarzo79 j _ _) = do
          gigolo96 <- ruaKilombo69 j
          case gigolo96 of
            Nothing ->
              error "(assignRegisters: no se asignaron registros a la función)"
            Just y  -> return y
    bardo5 (Cuete45 fifi id gula) = do
      rua79 <- mapM amurado fifi
      a98   <- esquinaQuemado39 [gula]
      corridoPopaShuca34 id a98
      Cuete45 rua79 a98 <$> bardo5 gula
    bardo5 (Guarda4 l a49 id gula) = do
      via7 <- amurado a49
      a98  <- esquinaQuemado39 [gula]
      corridoPopaShuca34 id a98
      Guarda4 l via7 a98 <$> bardo5 gula
    bardo5 (Reo7 a49 fifi) = do
      via7  <- amurado a49
      rua79 <- mapM amurado fifi
      case via7 of
        Pingo7 j -> do
          gilun <- navoCocota05 j
          if gilun
           then do
             carpusaOpa9 <- churrascaCalo76 j
             case carpusaOpa9 of
               Nothing -> adornoMongoBardoJaula2 j rua79
               Just _  -> return ()
           else return ()
        _ -> return ()
      return $ Reo7 via7 rua79
    bardo5 (Patova8 a49 gamba) = do
      via7 <- amurado a49
      Patova8 via7 <$> mapM bardo5 gamba
    bardo5 (Marinante1 m fifi [] gamba) = do
      rua79  <- mapM amurado fifi
      Marinante1 m rua79 [] <$> mapM bardo5 gamba
    bardo5 (Marinante1 m fifi [id] gamba) = do
      rua79 <- mapM amurado fifi
      a98   <- esquinaQuemado39 gamba
      corridoPopaShuca34 id a98
      Marinante1 m rua79 [a98] <$> mapM bardo5 gamba
    bardo5 (Marinante1 m _ _ _) = do
      error ("(assignRegisters/assign: " ++
             "la primitiva " ++ show m ++ " tiene más de un resultado)")
    bardo5 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM amurado fifi
      a98   <- esquinaQuemado39 [gula]
      corridoPopaShuca34 id a98
      ChivoA70 a13 rua79 a98 <$> bardo5 gula

    adornoMongoBardoJaula2 :: La4 -> [Bacan8] -> Tayar19 ()
    adornoMongoBardoJaula2 j mino = do
        honda <- mosconTela33 j
        let pur5 = concatMap despeloteLa53 mino
            bandeado1 = clientePua28 \\ pur5
            secarse46 = cafuaMacharse949 mino bandeado1 []
         in
           reaChoreo3 secarse46 honda
      where
        despeloteLa53 :: Bacan8 -> [La4]
        despeloteLa53 (Naso o) = [o]
        despeloteLa53 (Opa0 _ _) =
          error (
            "(assignRegisters/usedRegisters: " ++
            "no debería encontrar un SelK como argumento de una aplicación)"
          )
        despeloteLa53 _ = []

        cafuaMacharse949 :: [Bacan8] -> [La4] -> [La4] -> [La4]
        cafuaMacharse949 [] _ _ = []
        cafuaMacharse949 (Naso o : mino) bandeado1 espirarDe01
          | o `notElem` espirarDe01 =
              o : cafuaMacharse949 mino bandeado1 (o : espirarDe01)
        cafuaMacharse949 (quia6 : mino) bandeado1 espirarDe01 =
          case bandeado1 of
            [] -> error (
                    "(assignRegisters/newParamsForArgs: " ++
                    "no hay más registros disponibles)"
                  )
            sg : estrilar52 ->
              sg : cafuaMacharse949 mino estrilar52 espirarDe01

    cocearTorveloComisionCroto8 :: TocadoTras10 -> Tayar19 ()
    cocearTorveloComisionCroto8 pego@(Zarzo79 _ garuga _) =
      reaChoreo3 [0..fromIntegral (length garuga - 1)] pego

    reaChoreo3 :: [La4] -> TocadoTras10 -> Tayar19 ()
    reaChoreo3 secarse46 (Zarzo79 j garuga capo) = do
      gigolo96 <- ruaKilombo69 j
      case gigolo96 of
        Nothing -> do
          zipWithM_ corridoPopaShuca34 garuga secarse46
          modify (\ nasun -> nasun {
            pamelaCoimearChina =
              Map.insert j secarse46
              (pamelaCoimearChina nasun)
          })
          mina7 <- bardo5 capo
          modify (\ nasun -> nasun {
            carozosEnsobrar1 =
              Map.insert j (Zarzo79 j secarse46 mina7)
              (carozosEnsobrar1 nasun)
          })
        Just _  -> return ()

    abatatarseKilo6 :: Liga2 -> Liga2
    abatatarseKilo6 (Cuete45 fifi id gula) =
      Cuete45 (map falopaRemarYiro1 fifi) id (abatatarseKilo6 gula)
    abatatarseKilo6 (Guarda4 l a49 id gula) =
      Guarda4 l (falopaRemarYiro1 a49) id (abatatarseKilo6 gula)
    abatatarseKilo6 (Reo7 a49 fifi) =
      Reo7 (falopaRemarYiro1 a49) (map falopaRemarYiro1 fifi)
    abatatarseKilo6 (Manu amuro gula) =
        Manu (map faloperoFangosLora0 amuro)
             (abatatarseKilo6 gula)
      where
        faloperoFangosLora0 :: TocadoTras10 -> TocadoTras10
        faloperoFangosLora0 (Zarzo79 j mino capo) =
          Zarzo79 (upiteYugador32 j) mino (abatatarseKilo6 capo)
    abatatarseKilo6 (Patova8 a49 gamba) =
      Patova8 (falopaRemarYiro1 a49) (map abatatarseKilo6 gamba)
    abatatarseKilo6 (Marinante1 m fifi a29 gamba) =
      Marinante1 m (map falopaRemarYiro1 fifi) a29 (map abatatarseKilo6 gamba)
    abatatarseKilo6 (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 (map falopaRemarYiro1 fifi) id (abatatarseKilo6 gula)

    upiteYugador32 :: La4 -> La4
    upiteYugador32 (-1) = -1
    upiteYugador32 l    = metejonearse + l

    falopaRemarYiro1 :: Bacan8 -> Bacan8
    falopaRemarYiro1 (Pingo7 l) = Pingo7 (upiteYugador32 l)
    falopaRemarYiro1 h          = h

biabaLa5 :: Eq t => (z -> [t]) -> [z] -> [t]
biabaLa5 j = foldr union [] . map j

