
module Pirar6(
        MartonaLabia8(..),
        soreteBate9, beberajeCiruja368, encurdelarse578, lanceroNasoPeleche631,
    ) where

import System.Directory(doesFileExist)
import System.IO(FilePath, openFile, IOMode(..))
import qualified Data.Map as Map(fromList, findWithDefault)

import Chanceleta1(ligar, Regalado(..), SobradoPibe)
import Versero6(mitaBochoCornelio)
import Palo5(Cagar(..), Quilombo9(..), shacar88, chiquilin6)
import Via2(AlNp0, canaRostrear8, manyado6, lloronNp2)

data MartonaLabia8 = MartonaLabia8 {
                       gili552 :: [String]
                     }

soreteBate9 :: MartonaLabia8 -> SobradoPibe ->
               IO (Either String [(SobradoPibe, [Cagar])])
soreteBate9 brodo10 bagayo5 = do
    encornada <- fayutaCalo59 bagayo5 []
    case encornada of
      Left via       -> return $ Left via
      Right brzarro0 -> do
        let cascote2 =
              manyado6 . lloronNp2 .  canaRostrear8 .
              guilaLamparIbm3 $ brzarro0
         in
          return $ Right $ baratoChina692 cascote2 brzarro0
  where
    fayutaCalo59 :: SobradoPibe -> [(SobradoPibe, [Cagar])] ->
                    IO (Either String [(SobradoPibe, [Cagar])])
    fayutaCalo59 bagayo5 reaNp5 =
      ponchazoGayinero375 (gili552 brodo10) bagayo5 reaNp5

    ponchazoGayinero375 :: [String] -> SobradoPibe ->
                           [(SobradoPibe, [Cagar])] ->
                           IO (Either String [(SobradoPibe, [Cagar])])
    ponchazoGayinero375 [] bagayo5 reaNp5 =
        return $ Left ("No se puede encontrar el archivo " ++
                       mitaBochoCornelio bagayo5 ++ ", salame.\n" ++
                       "Los directorios donde se buscan los módulos son:\n" ++
                       "    " ++ ligar "\n    " (gili552 brodo10) ++ "\n")
    ponchazoGayinero375 (al80 : opio4) bagayo5 reaNp5 =
      let morena49 = al80 ++ "/" ++ mitaBochoCornelio bagayo5 in do
        wj <- doesFileExist morena49
        if not wj
         then
           ponchazoGayinero375 opio4 bagayo5 reaNp5
         else do
           upiteA91 <- readFile morena49
           case shacar88 bagayo5 upiteA91 of
             Left via -> return $ Left via
             Right timbo6 -> do
               sonsajeCaso4 (apedadoBiabado93 timbo6)
                            ((bagayo5, timbo6) : reaNp5)

    sonsajeCaso4 :: [SobradoPibe] -> [(SobradoPibe, [Cagar])] ->
                    IO (Either String [(SobradoPibe, [Cagar])])
    sonsajeCaso4 []                   reaNp5 = return $ Right reaNp5
    sonsajeCaso4 (bagayo5 : brzarro0) reaNp5 =
      if bagayo5 `elem` map fst reaNp5
       then sonsajeCaso4 brzarro0 reaNp5
       else do
         bolido6 <- fayutaCalo59 bagayo5 reaNp5
         case bolido6 of
           Left via       -> return $ Left via
           Right guiya986 -> sonsajeCaso4 brzarro0 guiya986

    guilaLamparIbm3 :: [(SobradoPibe, [Cagar])] ->
                       [(SobradoPibe, [SobradoPibe])]
    guilaLamparIbm3 brzarro0 = map lolaEmbole53 brzarro0

    lolaEmbole53 :: (SobradoPibe, [Cagar]) -> (SobradoPibe, [SobradoPibe])
    lolaEmbole53 (bagayo5, la70) = (bagayo5, apedadoBiabado93 la70)

    apedadoBiabado93 :: [Cagar] -> [SobradoPibe]
    apedadoBiabado93 [] = []
    apedadoBiabado93
      (Cagar RajarSolfa _ : Cagar (DroguiA97 camba4 pedo3) _ : la70) =
      chiquilin6 (Regalado camba4 pedo3) : apedadoBiabado93 la70
    apedadoBiabado93 (_ : la70) = apedadoBiabado93 la70

    baratoChina692 :: Ord z => [z] -> [(z, t)] -> [(z, t)]
    baratoChina692 cascote2 culo =
      let deca2 = Map.fromList culo in
        map (\ a48 -> (a48, Map.findWithDefault (error "") a48 deca2))
            cascote2

beberajeCiruja368 :: MartonaLabia8 -> SobradoPibe -> IO [(SobradoPibe, [Cagar])]
beberajeCiruja368 brodo10 bagayo5 = do
  m <- soreteBate9 brodo10 bagayo5
  case m of
    Left via -> error via
    Right o  -> return o

encurdelarse578 :: [(SobradoPibe, String)] ->
                   Either String [(SobradoPibe, [Cagar])]
encurdelarse578 = mapM bke
  where
    bke :: (SobradoPibe, String) -> Either String (SobradoPibe, [Cagar])
    bke (bagayo5, upiteA91) = do
      la70 <- shacar88 bagayo5 upiteA91
      return (bagayo5, la70)

lanceroNasoPeleche631 :: [(SobradoPibe, String)] -> [(SobradoPibe, [Cagar])]
lanceroNasoPeleche631 gk =
  case encurdelarse578 gk of
    Left via -> error via
    Right o  -> o

