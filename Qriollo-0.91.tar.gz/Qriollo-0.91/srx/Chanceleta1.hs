
module Chanceleta1(
        Gu, SobradoPibe, Regalado(..), Mersun99(..), NaifeMita,
        Buzarda91,
        GuapeandoOpio,
        MestizoUpa6(..),
        Canoa5(..),
        AmarretismoPan2(..), FlacaLoro2,
        EnsartarDesprendido(..), CapelunGroso53,
        CocineroJuntaLimado8(..), NadadoraBogaDe6,
        RevirarseQuilomboBocinaA596(..), AchumarseYurnoTurroLa0,
        CreparCotorraCartabon0(..), PoligriyoMatonear,
        DescuidistaEspiche587(..), PintarTrincarA41,
        JirafaGrelaArrebezarse284(..), FumistaGaruarRaviol9,
        Guarda564(..), Joda,
        ChipolaQuemo(..), Mordida,
        MorderRegalado20(..), CasaJeton55,
        AbanicarZapayo32(..), ViarazaHomo,
        Shomeria5(..), Opio,
        BateBolas8(..),

        mormoso1, marcha1, alacranear6, fajado44, chupeteRea0, desgrilar2,
        fiaca9, conchaSobreA31, formativo18, pesto1, bolo87, tano19,
        bagayo12, copetudo, enjaularCalor7,
        vagon7, vichadoresTras, estufado721, sardo9, gruaDe89,
        bochin, blanbetaPifiar, bajon0, batimento2,

        alcaucil, sobre42, encarador21, esquenun, brilllosA56, malcoMacro,
        sanata, fanarChotoRea8, pendejoHumo, naso86, garbia, humedo,
        apaparse, inflar42, lijaDroguiAve6,
        frilo3, tamangosBonete, piantaoAl51, batir6, frioDe56,
        filo04, astiyaLancero6, kukay0, catriela92,

        relojeadoAracaNp63, creparChina, salameIsa0, bailongoJeteador,
        morochaOjete75, ligar, trompaOrtoSolfeo,
    ) where

import Data.List(union)

import A17(
        Gu,
        SobradoPibe,
        Regalado(..),
        Mersun99(..),
        NaifeMita,
        Buzarda91,
        GuapeandoOpio,
        MestizoUpa6(..),
        Canoa5(..),
        AmarretismoPan2(..),
        EnsartarDesprendido(..),
        CocineroJuntaLimado8(..),
        RevirarseQuilomboBocinaA596(..),
        DescuidistaEspiche587(..),
        CreparCotorraCartabon0(..),
        JirafaGrelaArrebezarse284(..),
        Guarda564(..),
        ChipolaQuemo(..),
        MorderRegalado20(..),
        AbanicarZapayo32(..),
        Shomeria5(..),
        relojeadoAracaNp63,
        creparChina,
        salameIsa0,
    )
import Versero6(Versero6(..))

data BateBolas8 = Al
                | LeoneraEscupirA8 Versero6
  deriving (Show, Eq)

type FlacaLoro2 = AmarretismoPan2 BateBolas8
type CapelunGroso53 = EnsartarDesprendido BateBolas8
type NadadoraBogaDe6 = CocineroJuntaLimado8 BateBolas8
type AchumarseYurnoTurroLa0 = RevirarseQuilomboBocinaA596 BateBolas8
type PoligriyoMatonear = CreparCotorraCartabon0 BateBolas8
type PintarTrincarA41 = DescuidistaEspiche587 BateBolas8
type FumistaGaruarRaviol9 = JirafaGrelaArrebezarse284 BateBolas8
type Joda = Guarda564 BateBolas8
type Mordida = ChipolaQuemo BateBolas8
type CasaJeton55 = MorderRegalado20 BateBolas8
type ViarazaHomo = AbanicarZapayo32 BateBolas8
type Opio = Shomeria5 BateBolas8

mormoso1       = Chuchi3       Al
marcha1        = Funyi1        Al
alacranear6    = CraneoMusa    Al
fajado44       = VoviPro       Al
chupeteRea0    = BirraViste    Al
desgrilar2     = Pavadas77     Al
fiaca9         = Mopio         Al
conchaSobreA31 = MateMalcoOpa1 Al
formativo18    = FlacaJodon    Al
pesto1         = Copo5         Al
bolo87         = Mina0         Al
tano19         = Tocar         Al
bagayo12       = Abanico       Al
copetudo       = Cortina       Al
enjaularCalor7 = AcamalaCheDe4 Al
vagon7         = Cuete         Al
vichadoresTras = ExcomunicaA68 Al
estufado721    = CortadoLa9    Al
sardo9         = Mufa2         Al
gruaDe89       = Secar87       Al
bochin         = Pacoy         Al
blanbetaPifiar = TreintaCantar Al
bajon0         = Tela3         Al
batimento2     = Malanfio0     Al

alcaucil       = Chuchi3       . estufadoMosca197
sobre42        = Funyi1        . estufadoMosca197
encarador21    = CraneoMusa    . estufadoMosca197
esquenun       = VoviPro       . estufadoMosca197
brilllosA56    = BirraViste    . estufadoMosca197
malcoMacro     = Pavadas77     . estufadoMosca197
sanata         = Mopio         . estufadoMosca197
fanarChotoRea8 = MateMalcoOpa1 . estufadoMosca197
pendejoHumo    = FlacaJodon    . estufadoMosca197
naso86         = Copo5         . estufadoMosca197
garbia         = Mina0         . estufadoMosca197
humedo         = Tocar         . estufadoMosca197
apaparse       = Abanico       . estufadoMosca197
inflar42       = Cortina       . estufadoMosca197
lijaDroguiAve6 = AcamalaCheDe4 . estufadoMosca197
frilo3         = Cuete         . estufadoMosca197
tamangosBonete = ExcomunicaA68 . estufadoMosca197
piantaoAl51    = CortadoLa9    . estufadoMosca197
batir6         = Mufa2         . estufadoMosca197
frioDe56       = Secar87       . estufadoMosca197
filo04         = Pacoy         . estufadoMosca197
astiyaLancero6 = TreintaCantar . estufadoMosca197
kukay0         = Tela3         . estufadoMosca197
catriela92     = Malanfio0     . estufadoMosca197

estufadoMosca197 :: Versero6 -> BateBolas8
estufadoMosca197 (Versero6 _ "" 0 0) = Al
estufadoMosca197 al0                 = LeoneraEscupirA8 al0

bailongoJeteador :: Functor j => j BateBolas8 -> j BateBolas8
bailongoJeteador = fmap (const Al)

morochaOjete75 :: Regalado -> String
morochaOjete75 (Regalado gk pedo3) = ligar "." (gk ++ [pedo3])

ligar :: String -> [String] -> String
ligar a32 []   = ""
ligar a32 depa = foldr1 (\ o x -> o ++ a32 ++ x) depa

trompaOrtoSolfeo :: Regalado -> Opio -> Opio -> Opio
trompaOrtoSolfeo o x (Mopio ave s)
  | o == s    = x
  | otherwise = Mopio ave s
trompaOrtoSolfeo o x (MateMalcoOpa1 ave r) = MateMalcoOpa1 ave r
trompaOrtoSolfeo o x (FlacaJodon    ave r) = FlacaJodon ave r
trompaOrtoSolfeo o x (Copo5 ave s p)
  | o == s    = Copo5 ave s p
  | otherwise = Copo5 ave s (trompaOrtoSolfeo o x p)
trompaOrtoSolfeo o x (Mina0         ave gp oy) =
  Mina0 ave (trompaOrtoSolfeo o x gp)
            (trompaOrtoSolfeo o x oy)
trompaOrtoSolfeo o x (Tocar ave amuro p) =
    if o `elem` achacoBorrego amuro
     then Tocar ave amuro p
     else Tocar ave (map pirar84 amuro) (trompaOrtoSolfeo o x p)
  where
    achacoBorrego :: [ViarazaHomo] -> [Regalado]
    achacoBorrego [] = []
    achacoBorrego (Chuchi3 _ s _ _ : amuro) = [s] `union` achacoBorrego amuro
    achacoBorrego (_ : amuro)               = achacoBorrego amuro

    pirar84 :: ViarazaHomo -> ViarazaHomo
    pirar84 (Chuchi3 ave s isa ymp) =
      Chuchi3 ave s isa (trompaOrtoSolfeo o x ymp)
    pirar84 pego = pego
trompaOrtoSolfeo o x (Abanico ave ymp lastrar5) =
    Abanico ave (trompaOrtoSolfeo o x ymp)
                (map baboso340 lastrar5)
  where
    baboso340 :: CasaJeton55 -> CasaJeton55
    baboso340 (CasaJeton55 al9 ymp) =
      if o `elem` morder6 al9
       then CasaJeton55 al9 ymp
       else CasaJeton55 al9 (trompaOrtoSolfeo o x ymp)
    morder6 :: Mordida -> [Regalado]
    morder6 (Cuete _ o)              = [o]
    morder6 (ExcomunicaA68 _ _ seco) = foldr union [] (map morder6 seco)
    morder6 (CortadoLa9 _ _)         = []
    morder6 (Mufa2 _)                = []
    morder6 (Secar87 _ seco)         = foldr union [] (map morder6 seco)
trompaOrtoSolfeo o x (Cortina ave nm) =
  Cortina ave (map (trompaOrtoSolfeo o x) nm)
trompaOrtoSolfeo o x (AcamalaCheDe4 ave m) =
  error "Should not meet a placeholder"

