
module ReventarLa9(
        A84, PurretadaMangaGardelListo(..), Malandrino8(..),
        RelacheInfante53(..), Cancherear7(..), Mosca1(..),
        Banderudo0(..), ResecoPosta8(..), MontotoOlivo(..), Grata(..),
        CatreraUpa6(..), gorilaADe94
    ) where

import Chanceleta1

type A84 = Integer

data PurretadaMangaGardelListo =
              Roncar69 Integer
            | RifadoRua5 Integer
            | RefilarRobreca
            | BulinJoya5
            | Desabrochado4
            | Raje4
  deriving (Show, Eq)

data Malandrino8 = CargadorBolsa37 PurretadaMangaGardelListo
                 | NaranjaDandyDequera Mersun99
  deriving (Show, Eq)

data Mosca1 =

              Salame5
            | Falocrata
            | OrejearA75
            | MaranfioForro
            | MenesundaLa94
            | ChanchoGorda
            | ApronteFija7
            | Beberaje2

            | Rejilla

            | JetearRagu1

            | FinirBolasMula3
            | PapelonZapar2
            | TumbaderoChe2
            | AcanalarChala
            | Cachiporra65
            | ChangaTabas5
            | ApoliyoLuca5
            | PacoyLompa51
            | MalcoChimentero9
            | MitaDariqueCana7
            | YuguiyoCulata
            | MopioMaroteA15
            | AmbidextroPua0
            | PuaDesbolePan0
            | FelpudoGil5
            | Afanancio65
            | AgachadaCapo12
            | JiqueroBagayitoPapaA87
            | MusicanteMarcianoRaye
  deriving (Show, Eq, Ord)

data ResecoPosta8 = Agayas3 A84 Grata
  deriving (Show, Eq)

data MontotoOlivo = MontotoOlivo Malandrino8 Grata
  deriving (Show, Eq)

data Cancherear7 = AsuntoCasaA56
                 | RifadoRasca
                 | BorregadaA72
                 | QuiaEnculado8
                 | MironAlce1 String
                 | SeseraChe35
                 | ComilonUpa6
                 | VueloChoto12 Cancherear7
                 | ViudaCotin0 Cancherear7

                 | GarufearIsa8 Cancherear7
  deriving (Show, Eq, Ord)

data RelacheInfante53 = RelacheInfante53
                          MestizoUpa6
                          String
                          [Cancherear7]
                          Cancherear7
  deriving (Show, Eq, Ord)

data Banderudo0 =
     RemosOrejearBuzon661
   | FusiladoPurriaBatirPan7 [PurretadaMangaGardelListo]
  deriving (Show, Eq)

data Grata = Pur5       A84
           | FinirLisa  Mersun99
           | Tute       A84 Grata
           | La57       Grata Grata
           | Cana       [ResecoPosta8] Grata
           | Parir8     Banderudo0 Grata [MontotoOlivo] (Maybe Grata)
           | PibaLa3    [Grata]
           | LomoAl4    Integer Grata
           | RajarCrema Mosca1 [Grata]
           | Grasun87   RelacheInfante53 [Grata]
  deriving (Show, Eq)

data CatreraUpa6 = CatreraUpa6 {
                     hacer2     :: Integer,
                     fecaYurno5 :: Integer
                   }
gorilaADe94 :: Mosca1 -> CatreraUpa6
gorilaADe94 Salame5       = CatreraUpa6 1 1
gorilaADe94 Falocrata     = CatreraUpa6 1 1
gorilaADe94 OrejearA75    = CatreraUpa6 1 1
gorilaADe94 MaranfioForro = CatreraUpa6 2 1
gorilaADe94 MenesundaLa94 = CatreraUpa6 2 1
gorilaADe94 Rejilla       = CatreraUpa6 1 1
gorilaADe94 JetearRagu1   = CatreraUpa6 1 1

gorilaADe94 ChanchoGorda  = CatreraUpa6 2 2
gorilaADe94 ApronteFija7  = CatreraUpa6 2 2

gorilaADe94 FinirBolasMula3  = CatreraUpa6 2 2
gorilaADe94 PapelonZapar2    = CatreraUpa6 2 1
gorilaADe94 TumbaderoChe2    = CatreraUpa6 2 1
gorilaADe94 AcanalarChala    = CatreraUpa6 2 1
gorilaADe94 Cachiporra65     = CatreraUpa6 2 2
gorilaADe94 ChangaTabas5     = CatreraUpa6 2 2
gorilaADe94 ApoliyoLuca5     = CatreraUpa6 2 2
gorilaADe94 PacoyLompa51     = CatreraUpa6 2 2
gorilaADe94 MalcoChimentero9 = CatreraUpa6 2 1
gorilaADe94 MitaDariqueCana7 = CatreraUpa6 2 1
gorilaADe94 YuguiyoCulata    = CatreraUpa6 2 1
gorilaADe94 MopioMaroteA15   = CatreraUpa6 2 1
gorilaADe94 AmbidextroPua0   = CatreraUpa6 2 1
gorilaADe94 PuaDesbolePan0   = CatreraUpa6 1 1

gorilaADe94 FelpudoGil5      = CatreraUpa6 1 1
gorilaADe94 Afanancio65      = CatreraUpa6 1 1
gorilaADe94 AgachadaCapo12   = CatreraUpa6 1 1

gorilaADe94 JiqueroBagayitoPapaA87 = CatreraUpa6 1 1
gorilaADe94 MusicanteMarcianoRaye  = CatreraUpa6 2 1

