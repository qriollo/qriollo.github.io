
import System.IO(stderr, hPutStrLn)
import System.Exit(exitFailure)
import System.Environment(getArgs)
import Control.Monad.Trans.Class(lift)
import qualified System.Console.Haskeline as Li(
        InputT, runInputT, getInputLine, defaultSettings,
        outputStrLn,
    )
import Data.Char(isUpper)
import Data.List((\\), span)
import qualified Data.Map as Map(
        Map, empty, insert, lookup, findWithDefault, member, notMember,
        fromList,
    )

import Palo5(Cagar)
import Chanceleta1(Gu, SobradoPibe, creparChina, NadadoraBogaDe6)
import Versero6(botonAvivatoSalsa92)
import Pirar6(MartonaLabia8(..), beberajeCiruja368, encurdelarse578)
import MersadaPua9(
        morfiSabiola, galanGarron00, rajeBorbonaAceitar0,
        Cache468, Gayola7(..),
    )
import TumbaCoco(torta573)

queso12 :: String
queso12 = "0,91 \"Atorrante\""

garron :: String
garron =
  "____________________________________________________________________________\n\
  \   \\__ \\  \\   ooooooooooooooo   /  / __/\n\
  \      \\ \\  ooo               ooo  / /          ___       _       _ _\n\
  \ _____ | \\o   _____     _____   o/ | _____    / _ \\ _ __(_) ___ | | | ___\n\
  \__    \\ \\o   (     \\   /     )   o/ /    _   | | | | '__| |/ _ \\| | |/ _ \\\n\
  \  \\__  \\o     <(O)> ) ( <(O)>     o/  __/    | |_| | |  | | (_) | | | (_) |\n\
  \     \\__o           / \\           o__/        \\__\\_\\_|  |_|\\___/|_|_|\\___/\n\
  \________o         (_(_)_)         o________\n\
  \     ___o          _____          o___          Qriollo "
                                                          ++ queso12 ++ "\n\
  \  __/  /o         /_____\\         o\\  \\__ \n\
  \_/    / /o         \\___/         o\\ \\    \\_            1810-2016\n\
  \ ____/ | /o          n          o\\ | \\____         Hermandá Qriolla\n\
  \    __/ /  ooo               ooo  \\ \\__\n\
  \ __/   /  /   ooooooooooooooo   \\  \\   \\__\n\
  \______/___|__/___\\___|___/___\\__|___\\_______________________________________\n"

rua43 :: Bool -> IO z
rua43 pur7 = do

  putStr ("Qriollo versión " ++ queso12 ++ "\n")
  putStr ("Uso: qr [opciones] [entrada[.q]]\n")
  putStr ("\nOpciones principales\n")
  putStr ("-i, --chinela : " ++
          "Modo chinela (CHupar, INterpretar, Escupir La sAlida).\n")
  putStr ("-p <nombre>   : " ++
          "Nombre del punto de entrada principal " ++
          al84 EstanciaYapa8 ++ ".\n")
  putStr ("-t, --tipo    : " ++
          "Muestra el tipo del programa, sin ejecutarlo.\n")
  putStr ("--py          : " ++
          "Compila a Python.\n")
  putStr ("--jvm         : " ++
          "Compila a la JVM.\n")
  putStr ("--c           : " ++
          "Compila a C.\n")
  putStr ("-o <archivo>  : " ++
          "Nombre del archivo de salida.\n")
  putStr ("--ruta <dirs> : " ++
          "Directorios donde se buscan los módulos (separados por \":\").\n")
  if pur7
   then do
    putStr ("\nDesinsectación\n")
    putStr ("--al-pedo    : Compilar el programa, sin ejecutarlo.\n")
    putStr ("--facho      : Prohíbe la recursión en estructuras de datos.\n")
    putStr ("--gorra      : " ++
            "Obliga a que se respete la restricción de valores.\n")
    putStr ("--malpensado : Chequea invariantes de las estructuras internas.\n")
    putStr ("\nOpciones válidas sólo si se interpreta (no para compilar)\n")
    putStr ("--trucho  : " ++
            "No convertir clausuras, reservar, ni asignar registros.\n")
    putStr ("--pedorro : " ++
            "No resevar ni asignar registros.\n")
    putStr ("--berreta : " ++
            "No asignar registros.\n")
    putStr ("\nFuncionalidades\n")
    putStr ("--con <Funcionalidad> : Declara presente la funcionalidad.\n")
    putStr ("--sin <Funcionalidad> : Declara ausente la funcionalidad.\n")
    putStr ("\nCharlatán\n")
    putStr ("--mast : Escupe el árbol sintáctico.\n")
    putStr ("--masT : Escupe el árbol sintáctico después del tipado.\n")
    putStr ("--mpre : Escupe la expresión después de precompilar.\n")
    putStr ("--mcps : Escupe la expresión después de convertir a CPS.\n")
    putStr ("--mopt : Escupe la expresión después de optimizada.\n")
    putStr ("--mclo : Escupe la expresión después de clausurada.\n")
    putStr ("--mall : Escupe la expresión después de reservar registros.\n")
    putStr ("--mreg : Escupe la expresión después de asignar registros.\n")
    putStr ("--mval : Escupe el resultado.\n")
    putStr ("\nMejoras\n")
    putStr ("--manija <n> : Cantidad de rondas de optimización " ++
            al84 AtorroFurcaGuinchero200 ++ ".\n")
    putStr ("--lenteja    : " ++
            "Optimiza el tamaño del programa (puede ser más lento).\n")
   else do
    putStr ("--mano        : " ++
            "Muestra todas las opciones disponibles.\n")
  putStr ("\nEjemplos\n")
  putStr ("  qr Fulano    # ejecuta\n")
  putStr ("  qr -i Fulano # modo interactivo\n")
  putStr ("  qr Fulano --py | python -  # ejecuta en Python \n")
  putStr ("  qr Fulano --c -o f.c && gcc -o f f.c -Wall && ./f  # ejecuta en C\n")
  exitFailure

  where
    al84 :: Gayola7 -> String
    al84 a48 = "[=" ++ Map.findWithDefault "" a48 zarandaBrutal0 ++ "]"

zarandaBrutal0 :: Cache468
zarandaBrutal0 = Map.fromList [
    (AtorroFurcaGuinchero200, show 4),
    (EstanciaYapa8, torta573)
  ]

bondiAliviar :: IO Cache468
bondiAliviar = do
    mino <- getArgs
    al4 mino zarandaBrutal0
  where
    al4 :: [String] -> Cache468 -> IO Cache468

    al4 [] brodo10 =
      case Map.lookup Lenteja570 brodo10 of
        Nothing -> case Map.lookup QuilomboEnyante2 brodo10 of
                     Nothing -> rua43 False
                     Just _  -> return brodo10
        Just _  -> return brodo10

    al4 ("--mano" : mino) brodo10 =
      rua43 True

    al4 ("-i" : mino) brodo10 =
        al4 mino (Map.insert QuilomboEnyante2 "" brodo10)
    al4 ("--chinela" : mino) brodo10 =
        al4 mino (Map.insert QuilomboEnyante2 "" brodo10)
    al4 ("-o" : bagayo9 : mino) brodo10 =
        al4 mino (Map.insert LentearPatoIbm1 bagayo9 brodo10)

    al4 ("--py" : mino) brodo10 =
        al4 mino (Map.insert MuleroAlacransar886 "Py" $
                  Map.insert CurdelinNp46 "" brodo10)
    al4 ("--jvm" : mino) brodo10 =
        al4 mino (Map.insert MuleroAlacransar886 "Jvm" $
                  Map.insert CurdelinNp46 "" brodo10)
    al4 ("--c" : mino) brodo10 =
        al4 mino (Map.insert MuleroAlacransar886 "C" $
                  Map.insert CurdelinNp46 "" brodo10)

    al4 ("-p" : negraje6 : mino) brodo10 =
        al4 mino (Map.insert EstanciaYapa8 negraje6 brodo10)

    al4 ("--facho" : mino) brodo10 =
        al4 mino (Map.insert ViolaBifeLienzoLungoDatiles1 "" brodo10)
    al4 ("--gorra" : mino) brodo10 =
        al4 mino (Map.insert MujicaOjetePapearDuraznoRua7 "" brodo10)
    al4 ("--malpensado" : mino) brodo10 =
        al4 mino (Map.insert TuboLisaCotizarseRantifusa02 "" brodo10)

    al4 ("--ruta" : al80 : mino) brodo10 =
        al4 mino (Map.insert Curado692 al80 brodo10)

    al4 ("--al-pedo" : mino) brodo10 =
        al4 mino (Map.insert Alzarse421 "" brodo10)
    al4 ("--trucho" : mino) brodo10 =
        al4 mino (Map.insert CatreraHamacarseFinir072 "" brodo10)
    al4 ("--pedorro" : mino) brodo10 =
        al4 mino (Map.insert CogerCacheria48 "" brodo10)
    al4 ("--berreta" : mino) brodo10 =
        al4 mino (Map.insert LienzosGambetear "" brodo10)

    al4 ("--mast" : mino) brodo10 =
        al4 mino (Map.insert JuntaMasa169 "" brodo10)
    al4 ("--masT" : mino) brodo10 =
        al4 mino (Map.insert CueritoAsuntoJai1 "" brodo10)
    al4 ("--mpre" : mino) brodo10 =
        al4 mino (Map.insert BolazoNpPacoFaloperoBichoLa200 "" brodo10)
    al4 ("--mcps" : mino) brodo10 =
        al4 mino (Map.insert PifiarBolearseAmerrete "" brodo10)
    al4 ("--mopt" : mino) brodo10 =
        al4 mino (Map.insert QuiveveCanoasCotorroAlacran4 "" brodo10)
    al4 ("--mclo" : mino) brodo10 =
        al4 mino (Map.insert JustaValerianoManflora292 "" brodo10)
    al4 ("--mall" : mino) brodo10 =
        al4 mino (Map.insert TarumbaFulaClavarseCasaUpa4 "" brodo10)
    al4 ("--mreg" : mino) brodo10 =
        al4 mino (Map.insert RascunChantaKukayGuitaCalo2 "" brodo10)
    al4 ("--mval" : mino) brodo10 =
        al4 mino (Map.insert ArbolitoLimpio "" brodo10)
    al4 ("-t" : mino) brodo10 =
        al4 mino (Map.insert FiltradoGula1 "" brodo10)
    al4 ("--tipo" : mino) brodo10 =
        al4 mino (Map.insert FiltradoGula1 "" brodo10)

    al4 ("--con" : violero : mino) brodo10 =
      if null violero || not (isUpper (head violero))
       then do
         atorranta (
           "La funcionalidad indicada en --con " ++
           "tiene que empezar con mayúscula.")
         rua43 False
       else
         let guillar4 = words (Map.findWithDefault "" LunfapoesiaCaso5 brodo10)
          in al4 mino (Map.insert LunfapoesiaCaso5
                                  (unwords (violero : guillar4))
                                  brodo10)
    al4 ("--sin" : violero : mino) brodo10 =
      let guillar4 = words (Map.findWithDefault "" LunfapoesiaCaso5 brodo10)
       in al4 mino (Map.insert LunfapoesiaCaso5
                               (unwords (guillar4 \\ [violero]))
                               brodo10)

    al4 ("--manija" : chupar1 : mino) brodo10 =
        al4 mino (Map.insert AtorroFurcaGuinchero200 chupar1 brodo10)
    al4 ("--lenteja" : mino) brodo10 =
        al4 mino (Map.insert ChuparGruaGolpista699 "" brodo10)

    al4 (coco4:mino) brodo10 =
      case Map.lookup Lenteja570 brodo10 of
        Nothing -> al4 mino (Map.insert Lenteja570 coco4 brodo10)
        Just _  -> rua43 False

atorranta :: String -> IO ()
atorranta via = hPutStrLn stderr (
                  "Se te escapó la tortuga.\n" ++
                  "\n" ++
                  via
                )

cuerear4 :: NadadoraBogaDe6 -> IO ()
cuerear4 isa = putStrLn ("    de " ++ show isa)

bocho9 :: String
bocho9 = "qriollo> "

shacamento580 :: Cache468 -> MartonaLabia8
shacamento580 brodo10 =
    MartonaLabia8 {
      gili552 = barato9 ':' $
                Map.findWithDefault "." Curado692 brodo10
    }
  where
    barato9 :: Char -> String -> [String]
    barato9 a32 breca2 =
      case span (/= a32) breca2 of
        (ibm2, [])       -> [ibm2]
        (ibm2, _ : np81) -> ibm2 : barato9 a32 np81

catrera79 :: Cache468 -> String -> IO ()
catrera79 brodo10 cambuseria = do
   brzarro0 <- beberajeCiruja368 (shacamento580 brodo10)
                                 (botonAvivatoSalsa92 cambuseria)
   if Map.member FiltradoGula1 brodo10
    then
      case galanGarron00 brodo10 brzarro0 of
        Left via  -> atorranta via
        Right isa -> cuerear4 isa
    else do
      reaNp5 <- morfiSabiola brodo10 brzarro0
      case reaNp5 of
        Left via -> atorranta via
        Right _ -> return ()

amerreteDique4 :: Cache468 -> String -> IO ()
amerreteDique4 brodo10 cambuseria = do
    brzarro0 <- beberajeCiruja368 (shacamento580 brodo10)
                                  (botonAvivatoSalsa92 cambuseria)
    estaribelChupado3 brodo10 brzarro0

lompasMarcha23 :: SobradoPibe
lompasMarcha23 = ["Chamuyo"]

mosca484 :: String
mosca484 =
    "\
    \:chau           Se va del modo chinela.\n\
    \:mano           Para pedir una mano.\n\
    \:t <expresión>  Muestra el tipo de la expresión.\n"

abocadoJeton808 :: SobradoPibe
abocadoJeton808 = ["<entrada>"]

arrabalGay42 :: Gu
arrabalGay42 = "__"

papearYeca3 :: String
papearYeca3 = "Morir es una costumbre que sabe tener la gente.\n"

estaribelChupado3 :: Cache468 -> [(SobradoPibe, [Cagar])] -> IO ()
estaribelChupado3 brodo10 brzarro0 = do
    putStr garron
    putStr "\n"
    putStr "Estás en modo chinela.\n"
    putStr "Si necesitás una mano poné :mano\n"
    Li.runInputT Li.defaultSettings al03
  where
    al03 :: Li.InputT IO ()
    al03 = do
      nly <- Li.getInputLine bocho9
      case nly of
        Nothing     -> do
          Li.outputStrLn papearYeca3
          return ()
        Just "" -> al03
        Just ":chau" -> do
          Li.outputStrLn papearYeca3
          return ()
        Just ":mano" -> do
          Li.outputStrLn mosca484
          al03
        Just (':':'t':' ':gay4) -> do
          fuloA gay4
          al03
        Just gay4   -> do
          al95 gay4
          al03

    al95 :: String -> Li.InputT IO ()
    al95 gay4 = do
      case ambiguoConventillo032 gay4 of
        Left via -> lift $ atorranta via
        Right arrugarse -> do
          reaNp5 <- lift $ morfiSabiola (hechoVersatil85 arrabalGay42)
                                        arrugarse
          case reaNp5 of
            Left via  -> lift $ atorranta via
            Right a49 -> do
                Li.outputStrLn (rajeBorbonaAceitar0 a49)
                fuloA gay4

    fuloA :: String -> Li.InputT IO ()
    fuloA gay4 = do
      case enyetarAceiteTorta78 gay4 of
        Left via -> lift $ atorranta via
        Right cepillar83 -> do
          case galanGarron00 (hechoVersatil85 arrabalGay42) cepillar83 of
            Left via  -> lift $ atorranta via
            Right isa -> lift $ cuerear4 isa

    ambiguoConventillo032 :: String -> Either String [(SobradoPibe, [Cagar])]
    ambiguoConventillo032 gay4 = do
        chuperia <- encurdelarse578 [(
                      abocadoJeton808,
                      antropofago57 lompasMarcha23 ++
                      pijoteroRoscaLa81 brzarro0 ++
                      "el " ++ arrabalGay42 ++ " es Chamuyo.mostrar (\n\n" ++
                      gay4 ++
                      "\n\n)"
                     )]
        return (brzarro0 ++ chuperia)

    enyetarAceiteTorta78 :: String -> Either String [(SobradoPibe, [Cagar])]
    enyetarAceiteTorta78 gay4 = do
        chuperia <- encurdelarse578 [(
                      abocadoJeton808,
                      antropofago57 lompasMarcha23 ++
                      pijoteroRoscaLa81 brzarro0 ++
                      "el " ++ arrabalGay42 ++ " es\n" ++ gay4
                     )]
        return (brzarro0 ++ chuperia)

    antropofago57 :: SobradoPibe -> String
    antropofago57 np27 = "enchufar " ++ creparChina np27 ++ "\n"

    hechoVersatil85 :: Gu -> Cache468
    hechoVersatil85 negraje6 = Map.insert EstanciaYapa8 negraje6 brodo10

    pijoteroRoscaLa81 :: [(SobradoPibe, [Cagar])] -> String
    pijoteroRoscaLa81 [] = ""
    pijoteroRoscaLa81 fija1
      | np27 == lompasMarcha23 = ""
      | otherwise              = antropofago57 np27
      where (np27, _) = last fija1

main :: IO ()
main = do
    brodo10 <- bondiAliviar
    vb brodo10
  where
    vb :: Cache468 -> IO ()
    vb brodo10
      | (Map.member CatreraHamacarseFinir072 brodo10 ||
         Map.member CogerCacheria48 brodo10 ||
         Map.member LienzosGambetear brodo10) &&
        Map.member CurdelinNp46 brodo10 =

          hPutStrLn stderr (
            "Las opciones --trucho, --pedorro y --berreta\n" ++
            "son incompatibles con la compilación."
          )

    vb brodo10
      | Map.notMember QuilomboEnyante2 brodo10 &&
        Map.member Lenteja570 brodo10 =
          let cambuseria = Map.findWithDefault "" Lenteja570 brodo10
           in catrera79 brodo10 cambuseria

    vb brodo10
      | Map.member QuilomboEnyante2 brodo10 &&
        Map.member Lenteja570 brodo10 =
          let cambuseria = Map.findWithDefault "" Lenteja570 brodo10
           in amerreteDique4 brodo10 cambuseria

    vb brodo10
      | Map.member QuilomboEnyante2 brodo10 &&
        Map.notMember Lenteja570 brodo10 = do
           hocicar <- beberajeCiruja368 (shacamento580 brodo10) lompasMarcha23
           estaribelChupado3 brodo10 hocicar

