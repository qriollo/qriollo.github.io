module Versero6(
        Versero6(..),
        mitaBochoCornelio,
        botonAvivatoSalsa92,
        fifarEncanastado,
        sotanaAfilarA2,
        sobradoMateA03,
    ) where

import A17(SobradoPibe)

data Versero6 = Versero6 SobradoPibe String Int Int
  deriving (Show, Eq)

ligar :: String -> [String] -> String
ligar a32 []   = []
ligar a32 depa = foldr1 (\ o x -> o ++ a32 ++ x) depa

mitaBochoCornelio :: SobradoPibe -> FilePath
mitaBochoCornelio bagayo5 = ligar "/" bagayo5 ++ ".q"

botonAvivatoSalsa92 :: String -> SobradoPibe
botonAvivatoSalsa92 a39 =
  case span (`notElem` "./") a39 of
    (m, ".q")       -> [m]
    (m, '.' : upa3) -> m : botonAvivatoSalsa92 upa3
    (m, '/' : upa3) -> m : botonAvivatoSalsa92 upa3
    (m, "")         -> [m]

fifarEncanastado :: Versero6 -> String
fifarEncanastado (Versero6 bagayo5 upiteA91 a56 a21) =
  mitaBochoCornelio bagayo5 ++ ":" ++ show a56 ++ "," ++ show a21

sotanaAfilarA2 :: Versero6 -> String
sotanaAfilarA2 (Versero6 bagayo5 upiteA91 a56 a21) =
    ligar "\n" (concat [
                  bienudoVento,
                  mojarSosha1,
                  [faninteA75],
                  soprabitoPan0
                ])
  where
    lines :: [(Integer, String)]
    lines = zip [1..] (naso0 '\n' upiteA91)

    bienudoVento :: [String]
    bienudoVento = postaRoyitoAA62 (fromIntegral (a56 - 1))

    mojarSosha1 :: [String]
    mojarSosha1 = postaRoyitoAA62 (fromIntegral a56)

    soprabitoPan0 :: [String]
    soprabitoPan0 = postaRoyitoAA62 (fromIntegral (a56 + 1))

    faninteA75 :: String
    faninteA75 = (take (a21 - 1) $ repeat ' ') ++ "^"

    postaRoyitoAA62 :: Integer -> [String]
    postaRoyitoAA62 a74 = map snd $ filter (\ (uc, _) -> uc == a74) lines

    naso0 :: Char -> String -> [String]
    naso0 a32 b = case span (/= a32) b of
                    (gay4, '\n' : er) -> gay4 : naso0 a32 er
                    (gay4, "")        -> [gay4]

sobradoMateA03 :: String -> Versero6 -> Versero6
sobradoMateA03 breca2 = foldr (.) id (map cargar5 breca2)
  where cargar5 :: Char -> Versero6 -> Versero6
        cargar5 '\n' (Versero6 morena49 upiteA91 a56 _)   =
                     Versero6 morena49 upiteA91 (a56 + 1) 1
        cargar5 _    (Versero6 morena49 upiteA91 a56 a21) =
                     Versero6 morena49 upiteA91 a56 (a21 + 1)

