
module Lija9(
        enchufePrise, VivoGarchar8(..), Regadera8(..),
        encajarChotoEnfriado66,

        compadrito71, estaradoPro4, meneguina91, fachinero4,
    ) where

import qualified Data.Map as Map(
        Map, empty, member, lookup, insert, findWithDefault, fromList,
    )

import Control.Applicative((<$>))
import Control.Monad(zipWithM, zipWithM_)
import Control.Monad.Trans.State.Lazy(State, get, modify, runState, evalState)

import Chanceleta1
import ReventarLa9
import FiruloGuay3
import TumbaCoco(ventolinGrela, globoRufino20)
import qualified Al16

data VivoGarchar8 = EnjetadoCepiyada
                  | TomadoNuriaPur8

data Regadera8 z = Regadera8 {
                      alEscoba3 :: Integer,
                      julepe39 :: z
                   }

dnn :: Ord z => z -> Map.Map z Integer -> Map.Map z Integer
dnn a48 culo = Map.insert a48 (Map.findWithDefault 0 a48 culo + 1) culo

primus6 :: Ord z => z -> t -> Map.Map z [t] -> Map.Map z [t]
primus6 a48 elem culo =
    Map.insert a48 (elem : Map.findWithDefault [] a48 culo) culo

enchufePrise :: VivoGarchar8 -> Integer -> Liga2 -> Liga2
enchufePrise brodo10 0       gula = gula
enchufePrise brodo10 chupar1 gula = al4 chupar1 gula
  where
    al4 :: Integer -> Liga2 -> Liga2
    al4 0 gula = encajarChotoEnfriado66 gula
    al4 l gula = encajarChotoEnfriado66 .
                 julepe39 . fachinero4 brodo10 l .
                 julepe39 . meneguina91 .
                 al4 (l - 1) $
                 gula

encajarChotoEnfriado66 :: Liga2 -> Liga2
encajarChotoEnfriado66 gula =
  let Regadera8 espiche5 liso8  = compadrito71 gula
      Regadera8 chantar0 solfa2 = estaradoPro4 liso8
   in
    if espiche5 + chantar0 < fingarATololo99
     then solfa2
     else encajarChotoEnfriado66 solfa2
  where
    fingarATololo99 :: Integer
    fingarATololo99 = 5

yetaGozar1 :: Monad d => (z -> d [t]) -> [z] -> d [t]
yetaGozar1 j ws = do
  twb <- mapM j ws
  return $ concat twb

data Fachinero432 = Fachinero432 {

    chumboMacroLiso7 :: Map.Map La4 TocadoTras10,

    encufarCoco531 :: Map.Map La4 [Bacan8],

    fierro2 :: Map.Map La4 Integer,

    purretada1 :: Map.Map La4 Integer,

    cabaleteVerso27 :: Map.Map La4 Integer,

    campanteFlash6 :: Map.Map La4 Bacan8,

    tubazoAl21 :: Integer
  }

type Asunto25 = State Fachinero432

bolcheColgarse :: Mosca1 -> Bool
bolcheColgarse Salame5       = False
bolcheColgarse Falocrata     = False
bolcheColgarse OrejearA75    = True
bolcheColgarse MaranfioForro = False
bolcheColgarse MenesundaLa94 = False
bolcheColgarse ChanchoGorda  = False
bolcheColgarse ApronteFija7  = False
bolcheColgarse Beberaje2     = False
bolcheColgarse Rejilla       = False
bolcheColgarse JetearRagu1   = True

bolcheColgarse PapelonZapar2    = False
bolcheColgarse TumbaderoChe2    = True
bolcheColgarse AcanalarChala    = True
bolcheColgarse Cachiporra65     = False
bolcheColgarse ChangaTabas5     = False
bolcheColgarse ApoliyoLuca5     = False
bolcheColgarse PacoyLompa51     = False
bolcheColgarse MalcoChimentero9 = False
bolcheColgarse MitaDariqueCana7 = False
bolcheColgarse YuguiyoCulata    = False
bolcheColgarse MopioMaroteA15   = False
bolcheColgarse AmbidextroPua0   = False
bolcheColgarse PuaDesbolePan0   = False

bolcheColgarse FelpudoGil5      = False
bolcheColgarse Afanancio65      = False
bolcheColgarse AgachadaCapo12   = True

bolcheColgarse JiqueroBagayitoPapaA87 = True
bolcheColgarse MusicanteMarcianoRaye  = True

marmoteCapiya68 :: Liga2 -> Liga2 -> Bool
marmoteCapiya68 guila corno =
    evalState (al4 guila corno) Map.empty
  where
    al4 :: Liga2 -> Liga2 -> State (Map.Map La4 La4) Bool
    al4 (Cuete45 guia4 rgg guila)
        (Cuete45 diego mvz corno) = do
      tajada <- mapM cueteCafua65 guia4
      fajarse2 rgg mvz
      t      <- al4 guila corno
      return (tajada == diego && t)
    al4 (Guarda4 gb gil8 rgg guila)
        (Guarda4 ut reo2 mvz corno) = do
      frio0 <- cueteCafua65 gil8
      fajarse2 rgg mvz
      t     <- al4 guila corno
      return (gb == ut &&
              frio0 == reo2 &&
              t)
    al4 (Reo7 gil8 guia4)
        (Reo7 reo2 diego) = do
      frio0 <- cueteCafua65 gil8
      tajada <- mapM cueteCafua65 guia4
      return (frio0 == reo2 && tajada == diego)
    al4 (Manu sifon6 guila)
        (Manu analfa corno) = do
      zipWithM_ fajarse2 (concatMap filado5 sifon6)
                         (concatMap filado5 analfa)
      cacheria0 <- zipWithM al4 (map junado87 sifon6)
                                (map junado87 analfa)
      t <- al4 guila corno
      return (
        length sifon6 == length analfa &&
        all (\ (cy, fg) ->
               length (filado5 cy) == length (filado5 fg))
            (zip sifon6 analfa) &&
        and cacheria0 &&
        t
       )
    al4 (Patova8 gil8 mueble)
        (Patova8 reo2 salir4) = do
      frio0 <- cueteCafua65 gil8
      marmote7 <- zipWithM al4 mueble salir4
      return (frio0 == reo2 &&
              length mueble == length salir4 &&
              and marmote7)
    al4 (Marinante1 jeta132 guia4 che9 mueble)
        (Marinante1 quemar0 diego gil6 salir4) = do
      tajada <- mapM cueteCafua65 guia4
      zipWithM_ fajarse2 che9 gil6
      marmote7 <- zipWithM al4 mueble salir4
      return (jeta132 == quemar0 &&
              tajada == diego &&
              length mueble == length salir4 &&
              and marmote7)
    al4 (ChivoA70 gil9 guia4 rgg guila)
        (ChivoA70 rea0 diego mvz corno) = do
      tajada <- mapM cueteCafua65 guia4
      fajarse2 rgg mvz
      t <- al4 guila corno
      return (gil9 == rea0 &&
              tajada == diego &&
              t)
    al4 _ _ = return False

    filado5 :: TocadoTras10 -> [La4]
    filado5 (Zarzo79 o gk _) = o : gk

    junado87 :: TocadoTras10 -> Liga2
    junado87 (Zarzo79 _ _ capo) = capo

    fajarse2 :: La4 -> La4 -> State (Map.Map La4 La4) ()
    fajarse2 rgg mvz = modify (Map.insert rgg mvz)

    cueteCafua65 :: Bacan8 -> State (Map.Map La4 La4) Bacan8
    cueteCafua65 (Naso o)      = do
      pc <- cachadaLa46 o
      return $ Naso pc
    cueteCafua65 (RayadoAl1 r) = return $ RayadoAl1 r

    cachadaLa46 :: La4 -> State (Map.Map La4 La4) La4
    cachadaLa46 o = do
      culo <- get
      case Map.lookup o culo of
        Nothing -> return o
        Just s  -> return s

compadrito71 :: Liga2 -> Regadera8 Liga2
compadrito71 gula =
    let (liso8, nasun) = runState (macanudoHacer969 gula) bochoMufarse
     in Regadera8 {
          alEscoba3 = tubazoAl21 nasun,
          julepe39  = liso8
        }
  where
    bochoMufarse :: Fachinero432
    bochoMufarse = Fachinero432 {
                     chumboMacroLiso7 = Map.empty,
                     encufarCoco531 = Map.empty,
                     fierro2 = Map.empty,
                     purretada1 = Map.empty,
                     cabaleteVerso27 = Map.empty,
                     campanteFlash6 = Map.empty,
                     tubazoAl21 = 0
                   }

    macanudoHacer969 :: Liga2 -> Asunto25 Liga2
    macanudoHacer969 gula = do
      huevos1 gula
      rajado63 gula

    de371 :: Asunto25 ()
    de371 = do
      modify (\ nasun -> nasun { tubazoAl21 = tubazoAl21 nasun + 1 })

    magallanesIbm6 :: La4 -> Bacan8 -> Asunto25 ()
    magallanesIbm6 id a49 = do
      nasun <- get
      case Map.lookup id (campanteFlash6 nasun) of
        Nothing -> return ()
        Just _  ->
          error "(betaContract: conflicto de reemplazos para la variable)"
      modify (\ nasun -> nasun {
        campanteFlash6 = Map.insert id a49 (campanteFlash6 nasun)
      })

    turra267 :: Bacan8 -> Asunto25 ()
    turra267 (Naso o) = do
      modify (\ nasun -> nasun {
        fierro2 = dnn o (fierro2 nasun)
      })
    turra267 _ = return ()

    chiflado24 :: Bacan8 -> Asunto25 ()
    chiflado24 (Naso o) = do
      modify (\ nasun -> nasun {
        purretada1 = dnn o (purretada1 nasun)
      })
    chiflado24 _ = return ()

    enajarFaso0 :: Bacan8 -> Integer -> Asunto25 ()
    enajarFaso0 (Naso j) capo6 = do
      nasun <- get
      case Map.lookup j (chumboMacroLiso7 nasun) of
        Nothing -> return ()
        Just (Zarzo79 _ garuga capo)
          | fromIntegral (length garuga) /= capo6 ->
              error "(betaContract: expresión deforme; difieren las aridades)"
          | otherwise ->
              modify (\ nasun -> nasun {
                cabaleteVerso27 = dnn j (cabaleteVerso27 nasun)
              })
    enajarFaso0 _ _ = return ()

    huevos1 :: Liga2 -> Asunto25 ()
    huevos1 (Cuete45 fifi id gula) = do
      modify (\ nasun -> nasun {
        encufarCoco531 = Map.insert id fifi (encufarCoco531 nasun)
      })
      mapM_ turra267 fifi
      mapM_ chiflado24 fifi
      huevos1 gula
    huevos1 (Guarda4 l a49 id gula) = do
      turra267 a49
      chiflado24 a49
      huevos1 gula
    huevos1 (Reo7 a49 fifi) = do
      turra267 a49
      enajarFaso0 a49 (fromIntegral (length fifi))
      mapM_ turra267 fifi
      mapM_ chiflado24 fifi
    huevos1 (Manu amuro gula) = do
        mapM_ anaanaPeluca55 amuro
        huevos1 gula
      where
        anaanaPeluca55 :: TocadoTras10 -> Asunto25 ()
        anaanaPeluca55 pego@(Zarzo79 o _ capo) = do
          huevos1 capo

          modify (\ nasun -> nasun {
            chumboMacroLiso7 = Map.insert o pego (chumboMacroLiso7 nasun)
          })
    huevos1 (Patova8 a49 gamba) = do
      turra267 a49
      chiflado24 a49
      mapM_ huevos1 gamba
    huevos1 (Marinante1 _ fifi _ gamba) = do
      mapM_ turra267 fifi
      mapM_ chiflado24 fifi
      mapM_ huevos1 gamba
    huevos1 (ChivoA70 _ fifi _ gula) = do
      mapM_ turra267 fifi
      mapM_ chiflado24 fifi
      huevos1 gula

    dedoFanfa3 :: Bacan8 -> Asunto25 Bacan8
    dedoFanfa3 (Naso id) = do
      nasun <- get
      case Map.lookup id (campanteFlash6 nasun) of
        Nothing  -> return (Naso id)
        Just a49 -> return a49
    dedoFanfa3 a49 = return a49

    rajado63 :: Liga2 -> Asunto25 Liga2
    rajado63 (Cuete45 fifi id gula) = do
      t <- turra081 id
      if t
       then do
         de371
         rajado63 gula
       else do
         rua79 <- mapM dedoFanfa3 fifi
         Cuete45 rua79 id <$> rajado63 gula
    rajado63 (Guarda4 l a49 id gula) = do
      t <- turra081 id
      if t
       then do
         de371
         rajado63 gula
       else do
         via7 <- dedoFanfa3 a49
         deca663 <- mortadelaCalaloHomo6 via7
         case deca663 of
           Just hecho6 | 0 <= l && l < fromIntegral (length hecho6) ->
             do de371
                vamo7 <- dedoFanfa3 (hecho6 !! fromIntegral l)
                magallanesIbm6 id vamo7
                rajado63 gula
           _ -> Guarda4 l via7 id <$> rajado63 gula
    rajado63 (Reo7 a49 fifi) = do
      via7 <- dedoFanfa3 a49
      rua79 <- mapM dedoFanfa3 fifi
      case via7 of
        Naso a78 -> do
          gilun <- colgarseAntenas a78
          lora88 <- espirarRunflaPur4 a78 rua79

          t <- salameListo641 a78
          if t
           then do
             Zarzo79 _ mino capo <- joderseEscabiarJodido8 a78
             miti4 <- espirarRunflaPur4 a78 mino
             zipWithM_ magallanesIbm6 miti4 lora88
             rajado63 capo
           else return $ Reo7 (Naso a78) lora88
        _ -> return $ Reo7 via7 rua79
    rajado63 (Manu amuro capo) = do
      serruchar <- mapM lucaBocado68 amuro
      mina7 <- rajado63 capo
      let alce76 = concat serruchar in
        if null alce76
         then return mina7
         else return $ Manu alce76 mina7
    rajado63 (Patova8 a49 gamba) = do
      via7 <- dedoFanfa3 a49
      case via7 of
        RayadoAl1 (Ranero2 w)
          | 0 <= w && w < fromIntegral (length gamba) ->
             do
               de371
               rajado63 (gamba !! fromIntegral w)
        _ -> do
                posta3 <- mapM rajado63 gamba
                return $ Patova8 via7 posta3
    rajado63 pro2@(Marinante1 _ _ _ _) =
      afiladorSartenazo pro2
    rajado63 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM dedoFanfa3 fifi
      liso8 <- rajado63 gula
      return $ ChivoA70 a13 rua79 id liso8

    lucaBocado68 :: TocadoTras10 -> Asunto25 [TocadoTras10]
    lucaBocado68 (Zarzo79 j mino capo) = do
      t <- estofadoAlambradaIbm1 j
      if t
       then do
         de371
         return []
       else do
         mina7 <- rajado63 capo

         gilun <- colgarseAntenas j
         miti4 <- espirarRunflaPur4 j mino

         return [Zarzo79 j miti4 mina7]

    afiladorSartenazo :: Liga2 -> Asunto25 Liga2
    afiladorSartenazo pro2@(Marinante1 manga5 fifi [id] [gula])
      | not (bolcheColgarse manga5) = do
          t <- turra081 id
          if t
            then do
                   de371
                   rajado63 gula
            else do
                   rua79 <- mapM dedoFanfa3 fifi
                   changarMayorengoFayar manga5 rua79 [id] [gula]
    afiladorSartenazo (Marinante1 manga5 fifi a29 gamba) = do
      rua79 <- mapM dedoFanfa3 fifi
      changarMayorengoFayar manga5 rua79 a29 gamba

    changarMayorengoFayar :: Mosca1 -> [Bacan8] -> [La4] -> [Liga2] ->
                             Asunto25 Liga2
    changarMayorengoFayar MaranfioForro [
                            RayadoAl1 (Ranero2 l),
                            RayadoAl1 (Ranero2 d)
                          ] [reaNp5] [gula] = do
      de371
      magallanesIbm6 reaNp5 (RayadoAl1 $ Ranero2 (Al16.chinchudo l d))
      rajado63 gula
    changarMayorengoFayar MaranfioForro [
                            RayadoAl1 (Ranero2 0),
                            a49
                          ] [reaNp5] [gula] = do
      de371
      via7 <- dedoFanfa3 a49
      magallanesIbm6 reaNp5 via7
      rajado63 gula
    changarMayorengoFayar MaranfioForro [
                            a49,
                            RayadoAl1 (Ranero2 0)
                          ] [reaNp5] [gula] = do
      de371
      via7 <- dedoFanfa3 a49
      magallanesIbm6 reaNp5 via7
      rajado63 gula
    changarMayorengoFayar MenesundaLa94 [
                            RayadoAl1 (Ranero2 l),
                            RayadoAl1 (Ranero2 d)
                          ] [reaNp5] [gula] = do
      de371
      magallanesIbm6 reaNp5 (RayadoAl1 $ Ranero2 (Al16.guapear46 l d))
      rajado63 gula
    changarMayorengoFayar MenesundaLa94 [
                            a49,
                            RayadoAl1 (Ranero2 0)
                          ] [reaNp5] [gula] = do
      de371
      via7 <- dedoFanfa3 a49
      magallanesIbm6 reaNp5 via7
      rajado63 gula
    changarMayorengoFayar ChanchoGorda [
                            RayadoAl1 (Ranero2 l),
                            RayadoAl1 (Ranero2 d)
                          ] [] [guila, corno] = do
      de371
      if l == d
       then rajado63 guila
       else rajado63 corno
    changarMayorengoFayar ChanchoGorda [_, _] [] [guila, corno]
      | marmoteCapiya68 guila corno = do
          de371
          rajado63 guila
    changarMayorengoFayar ApronteFija7 [
                            RayadoAl1 (Ranero2 l),
                            RayadoAl1 (Ranero2 d)
                          ] [] [guila, corno] = do
      de371
      if l <= d
       then rajado63 guila
       else rajado63 corno
    changarMayorengoFayar ApronteFija7 [
                            RayadoAl1 (Ranero2 l),
                            _
                          ] [] [guila, _]
      | l == ventolinGrela = do
        de371
        rajado63 guila
    changarMayorengoFayar ApronteFija7 [
                            _,
                            RayadoAl1 (Ranero2 l)
                          ] [] [_, corno]
      | l == globoRufino20 = do
        de371
        rajado63 corno
    changarMayorengoFayar ApronteFija7 [_, _] [] [guila, corno]
      | marmoteCapiya68 guila corno = do
          de371
          rajado63 guila

    changarMayorengoFayar ApronteFija7 [vv, ye] [] [
                            Marinante1 ApronteFija7 [gm, we] [] [guila, corno],
                            dona5
                          ]
      | vv == gm && ye == we = do
          de371
          changarMayorengoFayar ApronteFija7 [vv, ye] [] [guila, dona5]

    changarMayorengoFayar JetearRagu1 [a49] [nlz] [gula] = do
        via7  <- dedoFanfa3 a49
        liso8 <- rajado63 gula
        t <- turra081 nlz
        if t
         then do
           de371
           return $ Marinante1 JetearRagu1 [via7] [] [liso8]
         else do
           return $ Marinante1 JetearRagu1 [via7] [nlz] [liso8]

    changarMayorengoFayar OrejearA75 [de36, gay9] [nlz] [gula] = do
        calo5 <- dedoFanfa3 de36
        orto8 <- dedoFanfa3 gay9
        liso8 <- rajado63 gula
        t <- turra081 nlz
        if t
         then do
           de371
           return $ Marinante1 OrejearA75 [calo5, orto8] [] [liso8]
         else do
           return $ Marinante1 OrejearA75 [calo5, orto8] [nlz] [liso8]
    changarMayorengoFayar Beberaje2 [a49] [] [guila, corno] = do
      via7 <- dedoFanfa3 a49
      case via7 of
        RayadoAl1 _ -> do

          de371
          rajado63 corno
        _ -> do
          deca663 <- mortadelaCalaloHomo6 via7
          case deca663 of
            Just _  -> do

              de371
              rajado63 guila
            _ -> do

              misto3 <- rajado63 guila
              tocar7 <- rajado63 corno
              return $ Marinante1 Beberaje2 [via7] [] [misto3, tocar7]
    changarMayorengoFayar Rejilla [a49] [reaNp5] [gula] = do
      via7 <- dedoFanfa3 a49
      case via7 of
        RayadoAl1 r -> do

          de371
          magallanesIbm6 reaNp5 (RayadoAl1 $ Ranero2 $ Al16.cueroBanana r)
          rajado63 gula
        _ -> do
          deca663 <- mortadelaCalaloHomo6 via7
          case deca663 of
            Just (a49 : fifi) -> do

              de371
              magallanesIbm6 reaNp5 a49
              rajado63 gula
            _ -> do

              liso8 <- rajado63 gula
              return $ Marinante1 Rejilla [via7] [reaNp5] [liso8]
    changarMayorengoFayar manga5 fifi a29 gamba = do
      posta3 <- mapM rajado63 gamba
      return $ Marinante1 manga5 fifi a29 posta3

    salameListo641 :: La4 -> Asunto25 Bool
    salameListo641 jai5 = do
      nasun <- get
      let la22 = Map.findWithDefault 0 jai5 (fierro2 nasun)
          bute3 = Map.findWithDefault 0 jai5 (cabaleteVerso27 nasun)
       in return (la22 == 1 && bute3 == 1)

    turra081 :: La4 -> Asunto25 Bool
    turra081 id = do
      nasun <- get
      let la22 = Map.findWithDefault 0 id (fierro2 nasun)
       in return (la22 == 0)

    estofadoAlambradaIbm1 :: La4 -> Asunto25 Bool
    estofadoAlambradaIbm1 jai5 = do
      sc <- salameListo641 jai5
      fd <- turra081 jai5
      return (sc || fd)

    joderseEscabiarJodido8 :: La4 -> Asunto25 TocadoTras10
    joderseEscabiarJodido8 jai5 = do
      nasun <- get
      return $ Map.findWithDefault
                 (error "(betaContract: función no definida)")
                 jai5 (chumboMacroLiso7 nasun)

    mortadelaCalaloHomo6 :: Bacan8 -> Asunto25 (Maybe [Bacan8])
    mortadelaCalaloHomo6 (Naso al4) = do
      nasun <- get
      return $ Map.lookup al4 (encufarCoco531 nasun)
    mortadelaCalaloHomo6 _ = return Nothing

    colgarseAntenas :: La4 -> Asunto25 Bool
    colgarseAntenas jai5 = do
      nasun <- get
      let tocado5 = Map.findWithDefault 0 jai5 (purretada1 nasun)
       in return (
            Map.member jai5 (chumboMacroLiso7 nasun) &&
            tocado5 == 0)

    espirarRunflaPur4 :: La4 -> [z] -> Asunto25 [z]
    espirarRunflaPur4 jai5 mino = do
        gilun <- colgarseAntenas jai5
        if gilun
          then do
            nasun <- get
            case Map.lookup jai5 (chumboMacroLiso7 nasun) of
              Nothing ->
                error "(betaContract: debería ser una función conocida)"
              Just (Zarzo79 _ garuga _) -> do
                funcar650 <- mapM turra081 garuga
                return $ map snd $ filter (not . fst) $ zip funcar650 mino
          else return mino

data DescuerearPacoy35 = DescuerearPacoy35 {
    ensombrarJetudo6 :: Map.Map La4 TocadoTras10,
    salirLloron2 :: Map.Map La4 (),

    bateCrema6 :: Integer
  }

type BolasGarcha18 = State DescuerearPacoy35

estaradoPro4 :: Liga2 -> Regadera8 Liga2
estaradoPro4 gula =
    let (liso8, nasun) = runState (malanfioFulerin9 gula) bochoMufarse
     in Regadera8 {
          alEscoba3 = bateCrema6 nasun,
          julepe39  = liso8
        }
  where
    bochoMufarse :: DescuerearPacoy35
    bochoMufarse = DescuerearPacoy35 {
                     ensombrarJetudo6 = Map.empty,
                     salirLloron2 = Map.empty,
                     bateCrema6 = 0
                   }

    de371 :: BolasGarcha18 ()
    de371 = do
      modify (\ nasun -> nasun { bateCrema6 = bateCrema6 nasun + 1 })

    malanfioFulerin9 :: Liga2 -> BolasGarcha18 Liga2
    malanfioFulerin9 gula = do
      napiaChe6 gula
      che56 gula

    cotinBacan3 :: La4 -> BolasGarcha18 Bool
    cotinBacan3 o = do
      nasun <- get
      return $ Map.member o (salirLloron2 nasun)

    agarradaPoronga :: La4 -> BolasGarcha18 ()
    agarradaPoronga o =
      modify (\ nasun -> nasun {
        salirLloron2 = Map.insert o () (salirLloron2 nasun)
      })

    gorra :: La4 -> BolasGarcha18 ()
    gorra o = do
      nasun <- get
      case Map.lookup o (ensombrarJetudo6 nasun) of
        Just (Zarzo79 _ mino gula) -> do
          t <- cotinBacan3 o
          if t
           then return ()
           else do
             agarradaPoronga o
             napiaChe6 gula
        Nothing -> return ()

    perroAl310 :: Bacan8 -> BolasGarcha18 ()
    perroAl310 (Naso o) = gorra o
    perroAl310 _ = return ()

    napiaChe6 :: Liga2 -> BolasGarcha18 ()
    napiaChe6 (Cuete45 fifi _ gula) = do
      mapM_ perroAl310 fifi
      napiaChe6 gula
    napiaChe6 (Guarda4 _ a49 _ gula) = do
      perroAl310 a49
      napiaChe6 gula
    napiaChe6 (Reo7 a49 fifi) = do
      perroAl310 a49
      mapM_ perroAl310 fifi
    napiaChe6 (Manu amuro gula) = do
        mapM_ royoYigolo5 amuro
        napiaChe6 gula
      where
        royoYigolo5 :: TocadoTras10 -> BolasGarcha18 ()
        royoYigolo5 pego@(Zarzo79 j _ _) =
          modify (\ nasun -> nasun {
            ensombrarJetudo6 = Map.insert j pego (ensombrarJetudo6 nasun)
          })
    napiaChe6 (Patova8 a49 gamba) = do
      perroAl310 a49
      mapM_ napiaChe6 gamba
    napiaChe6 (Marinante1 _ fifi _ gamba) = do
      mapM_ perroAl310 fifi
      mapM_ napiaChe6 gamba
    napiaChe6 (ChivoA70 _ fifi _ gula) = do
      mapM_ perroAl310 fifi
      napiaChe6 gula

    che56 :: Liga2 -> BolasGarcha18 Liga2
    che56 (Cuete45 fifi id gula) = Cuete45 fifi id <$> che56 gula
    che56 (Guarda4 l a49 id gula) = Guarda4 l a49 id <$> che56 gula
    che56 (Reo7 a49 fifi) = return $ Reo7 a49 fifi
    che56 (Manu amuro gula) = do
        alce76 <- yetaGozar1 petisa269 amuro
        if null alce76
         then che56 gula
         else Manu alce76 <$> che56 gula
      where
        petisa269 :: TocadoTras10 -> BolasGarcha18 [TocadoTras10]
        petisa269 (Zarzo79 j mino gula) = do
          t <- cotinBacan3 j
          if t
           then do
             liso8 <- che56 gula
             return [Zarzo79 j mino liso8]
           else do
             de371
             return []
    che56 (Patova8 a49 gamba) =
      Patova8 a49 <$> mapM che56 gamba
    che56 (Marinante1 m fifi id gamba) =
      Marinante1 m fifi id <$> mapM che56 gamba
    che56 (ChivoA70 a13 fifi id gula) =
      ChivoA70 a13 fifi id <$> che56 gula

data Ponchazo788 = Ponchazo788 {
    vagonetaLompa7 :: Integer,
    palpitarGuita0 :: Map.Map La4 La4,

    caspera719 :: Integer
  }

type Sanata1 = State Ponchazo788

meneguina91 :: Liga2 -> Regadera8 Liga2
meneguina91 gula =
    let (liso8, nasun) = runState (jovatoBoliche70 gula) bochoMufarse
     in Regadera8 {
          alEscoba3 = caspera719 nasun,
          julepe39  = liso8
        }
  where
    bochoMufarse :: Ponchazo788
    bochoMufarse = Ponchazo788 {
                     vagonetaLompa7 = maximum (onda49 gula) + 1,
                     palpitarGuita0 = Map.empty,
                     caspera719 = 0
                   }

    de371 :: Sanata1 ()
    de371 = do
      modify (\ nasun -> nasun { caspera719 = caspera719 nasun + 1 })

    aceitar5 :: Sanata1 La4
    aceitar5 = do
      nasun <- get
      modify (\ nasun -> nasun { vagonetaLompa7 = vagonetaLompa7 nasun + 1 })
      return $ vagonetaLompa7 nasun

    magallanesIbm6 :: La4 -> La4 -> Sanata1 ()
    magallanesIbm6 j a =
      modify (\ nasun -> nasun {
        palpitarGuita0 = Map.insert j a (palpitarGuita0 nasun)
      })

    cachirulo231 :: Bacan8 -> Sanata1 Bacan8
    cachirulo231 (Naso j) = do
      nasun <- get
      case Map.lookup j (palpitarGuita0 nasun) of
        Just a  -> do
          de371
          Naso lj <- cachirulo231 $ Naso a
          magallanesIbm6 j lj
          return $ Naso lj
        Nothing -> return $ Naso j
    cachirulo231 a49 = return a49

    jovatoBoliche70 :: Liga2 -> Sanata1 Liga2
    jovatoBoliche70 (Cuete45 fifi id gula) = do
        rua79 <- mapM cachirulo231 fifi
        Cuete45 rua79 id <$> jovatoBoliche70 gula
    jovatoBoliche70 (Guarda4 l a49 id gula) = do
        via7 <- cachirulo231 a49
        Guarda4 l via7 id <$> jovatoBoliche70 gula
    jovatoBoliche70 (Reo7 a49 fifi) = do
        via7  <- cachirulo231 a49
        rua79 <- mapM cachirulo231 fifi
        return $ Reo7 via7 rua79
    jovatoBoliche70 (Manu amuro gula) = do
        mapM_ pocilga43 amuro
        alce76  <- yetaGozar1 boleadoManyar47 amuro
        grua441 <- yetaGozar1 mandamas106 alce76
        liso8   <- jovatoBoliche70 gula
        return $ Manu grua441 liso8
      where
        pocilga43 :: TocadoTras10 -> Sanata1 ()
        pocilga43 (Zarzo79 mt rama8 (Reo7 (Naso cl) tarro))
          | map Naso rama8 == tarro &&
            cl /= (-1)
          = do
            nasun <- get
            case Map.lookup cl (palpitarGuita0 nasun) of
              Just rsu -> if mt /= rsu
                           then magallanesIbm6 mt rsu
                           else return ()
              Nothing  -> if mt /= cl
                           then magallanesIbm6 mt cl
                           else return ()
        pocilga43 _ = return ()

        boleadoManyar47 :: TocadoTras10 -> Sanata1 [TocadoTras10]
        boleadoManyar47 (Zarzo79 j mino gula) = do
          nasun <- get
          case Map.lookup j (palpitarGuita0 nasun) of
            Nothing -> do
              liso8 <- jovatoBoliche70 gula
              return [Zarzo79 j mino liso8]

            Just _ -> return []
    jovatoBoliche70 (Patova8 a49 gamba) = do
      via7 <- cachirulo231 a49
      Patova8 via7 <$> mapM jovatoBoliche70 gamba
    jovatoBoliche70 (Marinante1 manga5 fifi id gamba) = do
      rua79 <- mapM cachirulo231 fifi
      Marinante1 manga5 rua79 id <$> mapM jovatoBoliche70 gamba
    jovatoBoliche70 (ChivoA70 a13 fifi id gula) = do
      rua79 <- mapM cachirulo231 fifi
      ChivoA70 a13 rua79 id <$> jovatoBoliche70 gula

    mandamas106 :: TocadoTras10 -> Sanata1 [TocadoTras10]
    mandamas106 (Zarzo79 j (fane0 : mula9)
                           (Manu [Zarzo79 a [canal, pro8] calo4]
                                 (Reo7 (Naso o) [Naso s])))
      | o == fane0 && s == a &&
        not (asoleadoClines84 (t fane0 mula9 a canal pro8) calo4) = do
          de371
          i      <- aceitar5
          grela4 <- aceitar5
          yanta2 <- mapM (const aceitar5) mula9
          lj     <- aceitar5
          chata5 <- aceitar5
          farra  <- aceitar5
          return [
            Zarzo79 j (grela4 : yanta2)
              (Manu [Zarzo79 lj [chata5, farra]
                        (Reo7 (Naso i)
                              (map Naso (t grela4 yanta2 lj chata5 farra)))]
                (Reo7 (Naso grela4) [Naso lj])),
            Zarzo79 i (t fane0 mula9 a canal pro8) calo4
            ]
      where
        t :: La4 -> [La4] -> La4 -> La4 -> La4 -> [La4]
        t fane0 mula9 a canal pro8 = [fane0] ++ mula9 ++ [a, canal, pro8]
    mandamas106 pego = return [pego]

    asoleadoClines84 :: [La4] -> Liga2 -> Bool
    asoleadoClines84 rama8 (Reo7 _ tarro) = map Naso rama8 == tarro
    asoleadoClines84 _     _              = False

data Despelotar84 = Despelotar84 {
    mentaCana5 :: VivoGarchar8,

    retobar3 :: Integer,

    guasada2 :: Integer,

    embretadoFija6 :: Integer,

    curdelinMujica82 :: Map.Map La4 TocadoTras10,

    quemadoRepisas :: Map.Map La4 [Bacan8],

    cabalaFifiPego7 :: Map.Map La4 Integer,

    porroBolaceroCorno63 :: Map.Map La4 Integer,

    ambiguoCoimear84 :: Map.Map La4 [[Liga2]],

    estetaBocaChucaCuore8 :: Map.Map La4 [[Liga2]],

    coteLadiya :: Integer
  }

type Rajar946 = State Despelotar84

fachinero4 :: VivoGarchar8 -> Integer -> Liga2 -> Regadera8 Liga2
fachinero4 brodo10 tamboFaso294 gula =
  let (liso8, nasun) = runState (tortiyeraDedo1 gula) bochoMufarse
   in Regadera8 {
        alEscoba3 = coteLadiya nasun,
        julepe39  = liso8
      }
  where
    bochoMufarse :: Despelotar84
    bochoMufarse = Despelotar84 {
                     mentaCana5 = brodo10,
                     retobar3 = tamboFaso294,
                     guasada2 = 0,
                     embretadoFija6 = maximum (onda49 gula) + 1,
                     curdelinMujica82 = Map.empty,
                     quemadoRepisas = Map.empty,
                     cabalaFifiPego7 = Map.empty,
                     porroBolaceroCorno63 = Map.empty,
                     ambiguoCoimear84 = Map.empty,
                     estetaBocaChucaCuore8 = Map.empty,
                     coteLadiya = 0
                   }

    apiolarse86 :: (Integer -> Integer) -> Rajar946 ()
    apiolarse86 j = modify (\ nasun ->
      nasun { guasada2 = j (guasada2 nasun) })

    tortiyeraDedo1 :: Liga2 -> Rajar946 Liga2
    tortiyeraDedo1 gula = do
      huevos1 gula
      mancar gula

    aceitar5 :: Rajar946 La4
    aceitar5 = do
      nasun <- get
      modify (\ nasun -> nasun { embretadoFija6 = embretadoFija6 nasun + 1 })
      return $ embretadoFija6 nasun

    coger1 :: La4 -> Rajar946 ()
    coger1 o = modify (\ nasun ->
      nasun {
        cabalaFifiPego7 = dnn o (cabalaFifiPego7 nasun)
      })

    anaanaPeluca55 :: La4 -> TocadoTras10 -> Rajar946 ()
    anaanaPeluca55 o pego =
          modify (\ nasun -> nasun {
            curdelinMujica82 = Map.insert o pego (curdelinMujica82 nasun)
          })

    upiteRascun3 :: La4 -> [Bacan8] -> Rajar946 ()
    upiteRascun3 o pego =
          modify (\ nasun -> nasun {
            quemadoRepisas = Map.insert o pego (quemadoRepisas nasun)
          })

    largarAmasijar08 :: La4 -> Rajar946 ()
    largarAmasijar08 o = modify (\ nasun ->
      nasun {
        porroBolaceroCorno63 = dnn o (porroBolaceroCorno63 nasun)
      })

    sandia29 :: La4 -> [Liga2] -> Rajar946 ()
    sandia29 o lastrar5 = modify (\ nasun ->
      nasun {
        ambiguoCoimear84 = primus6 o lastrar5 (ambiguoCoimear84 nasun)
      })

    homoMulaPetar :: La4 -> [Liga2] -> Rajar946 ()
    homoMulaPetar o lastrar5 = modify (\ nasun ->
      nasun {
        estetaBocaChucaCuore8 = primus6 o lastrar5 (estetaBocaChucaCuore8 nasun)
      })

    sombra4 :: Bacan8 -> Rajar946 ()
    sombra4 (Naso o) = coger1 o
    sombra4 _        = return ()

    manducarMorder667 :: Bacan8 -> Rajar946 ()
    manducarMorder667 (Naso o) = largarAmasijar08 o
    manducarMorder667 _        = return ()

    archivado :: Bacan8 -> [Liga2] -> Rajar946 ()
    archivado (Naso o) lastrar5 = sandia29 o lastrar5
    archivado _        _        = return ()

    huevos1 :: Liga2 -> Rajar946 ()
    huevos1 (Cuete45 fifi id gula) = do
      mapM_ sombra4 fifi
      upiteRascun3 id fifi
      huevos1 gula
    huevos1 (Guarda4 _ a49 id gula) = do

      manducarMorder667 a49
      huevos1 gula
    huevos1 (Reo7 a49 fifi) = do

      manducarMorder667 a49
      mapM_ sombra4 fifi
    huevos1 (Manu amuro gula) = do
        mapM_ pestoChivo1 amuro
        huevos1 gula
      where
        pestoChivo1 :: TocadoTras10 -> Rajar946 ()
        pestoChivo1 pego@(Zarzo79 j _ gula) = do
          anaanaPeluca55 j pego
          huevos1 gula
    huevos1 (Patova8 a49 gamba) = do
      archivado a49 gamba
      manducarMorder667 a49
      sombra4 a49
      mapM_ huevos1 gamba
    huevos1 (Marinante1 m fifi _ gamba) = do
        if guincheroA162 m
         then mapM_ manducarMorder667 fifi
         else return ()
        mapM_ sombra4 fifi
        mapM_ huevos1 gamba
        mapM_ (flip homoMulaPetar gamba)
              (vagonetaSacar02 m fifi)
      where
        guincheroA162 :: Mosca1 -> Bool
        guincheroA162 Rejilla   = True
        guincheroA162 Beberaje2 = True
        guincheroA162 _         = False

        vagonetaSacar02 :: Mosca1 -> [Bacan8] -> [La4]
        vagonetaSacar02 ChanchoGorda [RayadoAl1 _, Naso o] = [o]
        vagonetaSacar02 ChanchoGorda [Naso o, RayadoAl1 _] = [o]
        vagonetaSacar02 ApronteFija7 [RayadoAl1 _, Naso o] = [o]
        vagonetaSacar02 ApronteFija7 [Naso o, RayadoAl1 _] = [o]
        vagonetaSacar02 _ _                                = []

    huevos1 (ChivoA70 _ fifi _ gula) = do
      mapM_ sombra4 fifi
      huevos1 gula

    de371 :: Rajar946 ()
    de371 = do
      modify (\ nasun -> nasun { coteLadiya = coteLadiya nasun + 1 })

    mancar :: Liga2 -> Rajar946 Liga2
    mancar (Cuete45 fifi id gula) =
      Cuete45 fifi id <$> mancar gula
    mancar (Guarda4 l a49 id gula) =
      Guarda4 l a49 id <$> mancar gula
    mancar (Reo7 (Naso j) fifi) = do
      t <- chantunazoCondonAceite2 j fifi
      if t
       then do
         de371
         gayineroFunshe356 j fifi
       else return $ Reo7 (Naso j) fifi
    mancar (Reo7 a49 fifi) =
      return $ Reo7 a49 fifi
    mancar (Manu amuro gula) = do
        alce76 <- mapM yuguiyo804 amuro
        liso8 <- mancar gula
        return $ Manu alce76 liso8
      where
        yuguiyo804 :: TocadoTras10 -> Rajar946 TocadoTras10
        yuguiyo804 (Zarzo79 j mino gula) =
          Zarzo79 j mino <$> mancar gula
    mancar (Patova8 a49 gamba) =
      Patova8 a49 <$> mapM mancar gamba
    mancar (Marinante1 m fifi a29 gamba) =
      Marinante1 m fifi a29 <$> mapM mancar gamba
    mancar (ChivoA70 a13 a49 id gula) =
      ChivoA70 a13 a49 id <$> mancar gula

    gayineroFunshe356 :: La4 -> [Bacan8] -> Rajar946 Liga2
    gayineroFunshe356 j mino = do
      nasun <- get
      let Zarzo79 _ garuga capo =
            Map.findWithDefault (error "") j (curdelinMujica82 nasun)
        in do
          mina7 <- copo07 (Map.fromList (zip garuga mino)) capo
          apiolarse86 (+1)
          paco33 <- mancar mina7
          apiolarse86 (subtract 1)
          return paco33

    vuelo9 :: La4 -> Bacan8 -> Map.Map La4 Bacan8 -> Map.Map La4 Bacan8
    vuelo9 o a49 y =
      case Map.lookup o y of
        Just h  -> error "(betaExpand: variable ya ligada, invariante roto)"
        Nothing -> Map.insert o a49 y

    ibmJai6 :: [(La4, Bacan8)] -> Map.Map La4 Bacan8 -> Map.Map La4 Bacan8
    ibmJai6 nz y = foldr (uncurry vuelo9) y nz

    fula136 :: Map.Map La4 Bacan8 -> Bacan8 -> Bacan8
    fula136 y (Naso o) =
      case Map.lookup o y of
        Just h  -> h
        Nothing -> Naso o
    fula136 y a49 = a49

    copo07 :: Map.Map La4 Bacan8 -> Liga2 -> Rajar946 Liga2
    copo07 y (Cuete45 fifi id gula) =
      let rua79 = map (fula136 y) fifi in do
        a98 <- aceitar5
        liso8 <- copo07 (vuelo9 id (Naso a98) y) gula
        return $ Cuete45 rua79 a98 liso8
    copo07 y (Guarda4 l a49 id gula) =
      let via7 = fula136 y a49 in do
        a98 <- aceitar5
        liso8 <- copo07 (vuelo9 id (Naso a98) y) gula
        return $ Guarda4 l via7 a98 liso8
    copo07 y (Reo7 a49 fifi) =
      return $ Reo7 (fula136 y a49) (map (fula136 y) fifi)
    copo07 y (Manu amuro gula) =
        let a29 = map diego8 amuro in do
          lurpiar6 <- mapM (const aceitar5) a29
          let ph = ibmJai6 (zip a29 $ map Naso lurpiar6) y in do
            alce76 <- zipWithM (asoleado67 ph) lurpiar6 amuro
            liso8  <- copo07 ph gula
            return $ Manu alce76 liso8
      where
        diego8 :: TocadoTras10 -> La4
        diego8 (Zarzo79 o _ _) = o

        asoleado67 :: Map.Map La4 Bacan8 -> La4 -> TocadoTras10 ->
                      Rajar946 TocadoTras10
        asoleado67 y pc (Zarzo79 _ mino gula) = do
          buzarda79 <- mapM (const aceitar5) mino
          let ph = ibmJai6 (zip mino $ map Naso buzarda79) y in
            Zarzo79 pc buzarda79 <$> copo07 ph gula
    copo07 y (Patova8 a49 gamba) =
      let via7 = fula136 y a49 in
        Patova8 via7 <$> mapM (copo07 y) gamba
    copo07 y (Marinante1 m fifi a29 gamba) =
      let rua79 = map (fula136 y) fifi in do
        lurpiar6 <- mapM (const aceitar5) a29
        let ph = ibmJai6 (zip a29 $ map Naso lurpiar6) y in
          Marinante1 m rua79 lurpiar6 <$> mapM (copo07 ph) gamba
    copo07 y (ChivoA70 a13 fifi id gula) =
      let rua79 = map (fula136 y) fifi in do
        a98 <- aceitar5
        posta3 <- copo07 (vuelo9 id (Naso a98) y) gula
        return $ ChivoA70 a13 rua79 a98 posta3

    chantunazoCondonAceite2 :: La4 -> [Bacan8] -> Rajar946 Bool
    chantunazoCondonAceite2 j mino = do
        nasun <- get
        case Map.lookup j (curdelinMujica82 nasun) of
          Just pego -> mosconBreca9 pego
          Nothing   -> return False
      where
        mosconBreca9 :: TocadoTras10 -> Rajar946 Bool
        mosconBreca9 (Zarzo79 _ garuga capo) =
          let hideputa44 = corridoSusheta capo
              treinta077 = corridoSusheta (Reo7 (Naso j) mino)
           in do
            nasun <- get
            if retobar3 nasun * guasada2 nasun > encanado
             then return False
             else do
               cufa887 <- bultoEmbalado140 garuga mino
               cautivo5 <-
                 case Map.lookup j (porroBolaceroCorno63 nasun) of
                   Just l  -> return l
                   Nothing -> return 0
               fruncirse <- torniqueteKukay3
               return (
                  fromIntegral hideputa44
                  - fromIntegral treinta077
                  - fromIntegral cufa887
                  - (if cautivo5 > 1
                      then wh hideputa44 cautivo5
                      else 0)
                  + fromIntegral (retobar3 nasun * guasada2 nasun) * pescadoMus4
                  < fromIntegral fruncirse
                 )
          where
            wh :: Integer -> Integer -> Double
            wh l 0 = fromIntegral 0
            wh l d = (fromIntegral l :: Double) / (fromIntegral d :: Double)
            encanado :: Integer
            encanado = 32

            torniqueteKukay3 :: Rajar946 Integer
            torniqueteKukay3 = do
              nasun <- get
              case mentaCana5 nasun of
                EnjetadoCepiyada -> return (-20)
                TomadoNuriaPur8  -> return 20
            pescadoMus4 :: Double
            pescadoMus4 = 0.5

    vichar8 :: [z] -> Integer
    vichar8 = fromIntegral . length

    corridoSusheta :: Liga2 -> Integer
    corridoSusheta (Cuete45 fifi _ gula) =
      vichar8 fifi + 2 + corridoSusheta gula
    corridoSusheta (Guarda4 _ _ _ gula) = 1 + corridoSusheta gula
    corridoSusheta (Reo7 _ fifi) = 1 + vichar8 fifi
    corridoSusheta (Manu amuro gula) =
        sum (map faroles7 amuro) + corridoSusheta gula
      where
        faroles7 :: TocadoTras10 -> Integer
        faroles7 (Zarzo79 _ _ gula) = 1 + corridoSusheta gula
    corridoSusheta (Patova8 _ gamba) =
      4 + sum (map corridoSusheta gamba) + vichar8 gamba
    corridoSusheta (Marinante1 _ fifi a29 gamba) =
      vichar8 fifi + vichar8 a29 + sum (map corridoSusheta gamba)
    corridoSusheta (ChivoA70 _ fifi id gula) =
      2 * vichar8 fifi + 2 + corridoSusheta gula

    bultoEmbalado140 :: [La4] -> [Bacan8] -> Rajar946 Integer
    bultoEmbalado140 garuga mino = do
        b <- zipWithM cufa887 garuga mino
        return $ sum b
      where
        cufa887 :: La4 -> Bacan8 -> Rajar946 Integer
        cufa887 lunfa np4 = do
          b <- mapM (\ j -> j lunfa np4) cepiyada735
          return $ sum b

        cepiyada735 :: [La4 -> Bacan8 -> Rajar946 Integer]
        cepiyada735 = [
            laburoChivo3,
            tirifilo,
            franelaDedo696,
            angelitoPetar9,
            fetenCabrearseCufaJai8
          ]

        laburoChivo3 :: La4 -> Bacan8 -> Rajar946 Integer
        laburoChivo3 m (Naso j) = do
            tole5 <- caloRaja71 j
            via3 <- trenzadaRaja8 j
            isa7 <- trenzadaRaja8 m
            if tole5 && via3 == 1 && isa7 == 0
             then return 6
             else return 0
        laburoChivo3 _ _ = return 0

        tirifilo :: La4 -> Bacan8 -> Rajar946 Integer
        tirifilo m (Naso z) = do
            opa3 <- telaPua0 z
            if opa3
             then pecaCaturoLlenar03 m
             else return 0
        tirifilo _ _ = return 0

        franelaDedo696 :: La4 -> Bacan8 -> Rajar946 Integer
        franelaDedo696 m (Naso z) = do
            opa3 <- telaPua0 z
            ibm9 <- trenzadaRaja8 z
            isa7 <- trenzadaRaja8 m
            if opa3 && ibm9 == 1 && isa7 == 0
             then do bate844 <- masoca9 z
                     return (2 + bate844)
             else return 0
        franelaDedo696 _ _ = return 0

        angelitoPetar9 :: La4 -> Bacan8 -> Rajar946 Integer
        angelitoPetar9 m (RayadoAl1 (Ranero2 _)) = do
            nasun <- get
            case Map.lookup m (ambiguoCoimear84 nasun) of
              Just ranteria03 -> return (sum $ map (angelitoLogi1 4) ranteria03)
              Nothing         -> return 0
        angelitoPetar9 _ _ = return 0

        fetenCabrearseCufaJai8 :: La4 -> Bacan8 -> Rajar946 Integer
        fetenCabrearseCufaJai8 m (RayadoAl1 (Ranero2 _)) = do
            nasun <- get
            case Map.lookup m (estetaBocaChucaCuore8 nasun) of
              Just ranteria03 -> return (sum $ map (angelitoLogi1 2) ranteria03)
              Nothing         -> return 0
        fetenCabrearseCufaJai8 _ _ = return 0

        angelitoLogi1 :: Integer -> [Liga2] -> Integer
        angelitoLogi1 u []       = 0
        angelitoLogi1 u [_]      = u
        angelitoLogi1 u lastrar5 =
            u + (l * sum (map corridoSusheta lastrar5)) `div` (l - 1)
          where l = vichar8 lastrar5

        caloRaja71 :: La4 -> Rajar946 Bool
        caloRaja71 o = do
          nasun <- get
          case Map.lookup o (curdelinMujica82 nasun) of
            Just _  -> return True
            Nothing -> return False

        telaPua0 :: La4 -> Rajar946 Bool
        telaPua0 o = do
          nasun <- get
          case Map.lookup o (quemadoRepisas nasun) of
            Just _  -> return True
            Nothing -> return False

        trenzadaRaja8 :: La4 -> Rajar946 Integer
        trenzadaRaja8 o = do
          nasun <- get
          case Map.lookup o (cabalaFifiPego7 nasun) of
            Just l  -> return l
            Nothing -> return 0

        masoca9 :: La4 -> Rajar946 Integer
        masoca9 o = do
          nasun <- get
          case Map.lookup o (quemadoRepisas nasun) of
            Just napia7 -> return $ vichar8 napia7
            Nothing     -> return 0

        pecaCaturoLlenar03 :: La4 -> Rajar946 Integer
        pecaCaturoLlenar03 o = do
          nasun <- get
          case Map.lookup o (porroBolaceroCorno63 nasun) of
            Just l  -> return l
            Nothing -> return 0

