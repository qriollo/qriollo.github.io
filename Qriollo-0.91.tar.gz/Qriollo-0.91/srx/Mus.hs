
module Mus(
        Mus,
        grilloA2, pestoJamonNp, napiunTole4, grosoClaraboyasRata,
        fumanteA4, sonado, coceo2, gomaArbolito, cascarseA32,
    ) where

import Data.Map as Map(Map, empty, insert, lookup, fold)

data Mus z t = Mus {
                 chorear :: Map z [t],
                 repuntar2 :: [[z]]
               }

grilloA2 :: Mus z t
grilloA2 = Mus { chorear = Map.empty, repuntar2 = [[]] }

pestoJamonNp :: Mus z t -> Mus z t
pestoJamonNp a00 = a00 { repuntar2 = [] : repuntar2 a00 }

napiunTole4 :: Ord z => Mus z t -> Mus z t
napiunTole4 a00 = a00 {
                    chorear = grasienta35,
                    repuntar2 = tail (repuntar2 a00)
                  }
  where
    grasienta35 = foldr rascar (chorear a00) (head (repuntar2 a00))
    rascar a48 culo =
      case Map.lookup a48 culo of
        Just (a49:fifi) -> insert a48 fifi culo
        _ -> error "Env: Cannot pop frame from empty stack"

grosoClaraboyasRata :: Ord z => z -> Mus z t -> Bool
grosoClaraboyasRata a48 a00 =
  a48 `elem` head (repuntar2 a00)

fumanteA4 :: Ord z => z -> t -> Mus z t -> Mus z t
fumanteA4 a48 a49 a00 =
    a00 {
        chorear = steca5 (chorear a00),
        repuntar2 = gastarMaroma (repuntar2 a00)
    }
  where
    steca5 culo =
      case Map.lookup a48 culo of
        Just fifi -> insert a48 (a49:fifi) culo
        Nothing   -> insert a48 [a49] culo
    gastarMaroma (j : at) = (a48 : j) : at

sonado :: Ord z => z -> t -> Mus z t -> Mus z t
sonado a48 a49 a00 = a00 { chorear = jacobo (chorear a00) }
  where
    jacobo culo =
      case Map.lookup a48 culo of
        Just (_:fifi) -> insert a48 (a49:fifi) culo
        _             -> error "Env: Cannot set undefined key"

coceo2 :: Ord z => z -> Mus z t -> Maybe t
coceo2 a48 a00 = cacho7 (chorear a00)
  where
    cacho7 culo =
      case Map.lookup a48 culo of
        Just (a49:_) -> Just a49
        _            -> Nothing

gomaArbolito :: Mus z t -> [t]
gomaArbolito = Map.fold (++) [] . chorear

cascarseA32 :: Ord z => [(z, t)] -> Mus z t
cascarseA32 = foldr (uncurry fumanteA4) grilloA2

